import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Employee, TelegramSettings, SMSSettings, FactorySettings, EmploymentStatus, SalaryDisbursementRecord, PaymentMethod, AttendanceRecord, SalaryProgressStatus } from '../types';
import {
  saveOrUpdateEmployee,
  deleteEmployeeById,
  setLocalEmployees,
  loadTelegramSettings,
  saveTelegramSettings,
  loadSMSSettings,
  saveSMSSettings,
  loadFactorySettings,
  saveFactorySettings,
  DEFAULT_FACTORY_SETTINGS,
  DEFAULT_CONTRACT_RULES,
  DEFAULT_CONTRACT_DECLARATION,
  subscribeSalaryRecords,
  deleteSalaryRecordById,
  deleteSalaryRecordsBatch,
  deleteSalaryRecordsByMonthYear,
  deleteAllSalaryRecords,
  saveOrUpdateSalaryRecord,
  subscribeAttendanceRecords,
  getLocalAttendanceRecords,
  getLocalSalaryRecords,
  updateResignationStatus,
  subscribeJobApplications,
  clearAllDemoEmployees
} from '../lib/firebase';
import { formatMoney, formatDateBn, getStatusBadge, toBengaliNumber } from '../lib/utils';
import { calculateEmployeeAttendanceStats } from '../lib/attendanceUtils';
import { printElement } from '../lib/printer';
import { openInExternalBrowser, isTelegramWebApp } from '../lib/telegram';
import { AttendanceHub } from './AttendanceHub';
import { EmployeeAttendanceProfileView } from './EmployeeAttendanceProfileView';
import { ContractLetterModal } from './ContractLetterModal';
import { ResignationLetterModal } from './ResignationLetterModal';
import { SuspensionNoticeModal } from './SuspensionNoticeModal';
import { TerminationNoticeModal } from './TerminationNoticeModal';
import { JobApplicationsAdminTab } from './JobApplicationsAdminTab';
import { JobApplicationForm } from './JobApplicationForm';
import { WorkerCredentialModal } from './WorkerCredentialModal';
import { AllWorkersLoginModal } from './AllWorkersLoginModal';
import { WorkerNoticeModal } from './WorkerNoticeModal';
import {
  UserPlus,
  Users,
  User,
  UserX,
  X,
  Ban,
  IdCard,
  Key,
  Send,
  MessageSquare,
  KeyRound,
  LogOut,
  Lock,
  Eye,
  EyeOff,
  Search,
  Edit,
  Trash2,
  Copy,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  ExternalLink,
  RotateCcw,
  Receipt,
  DollarSign,
  Calendar,
  CreditCard,
  FileSpreadsheet,
  Download,
  Filter,
  Clock,
  Save,
  FileText,
  Bell,
  Camera,
  Upload,
  FileSignature,
  PenTool,
  Check,
  Building2,
  Plus,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export type AdminTab = 'list' | 'attendance' | 'salaries' | 'resignation' | 'form' | 'details' | 'telegram' | 'sms' | 'password' | 'factory' | 'applications';

interface AdminPanelProps {
  employees: Employee[];
  onOpenResignationModal: (emp: Employee) => void;
  onOpenResignationLetter?: (emp: Employee) => void;
  onOpenSuspensionNotice?: (emp: Employee) => void;
  onOpenTerminationNotice?: (emp: Employee) => void;
  showToast: (msg: string) => void;
  initialTab?: AdminTab;
  onTabChange?: (tab: AdminTab) => void;
}

const BENGALI_MONTHS = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

export const AdminPanel: React.FC<AdminPanelProps> = ({
  employees,
  onOpenResignationModal,
  onOpenResignationLetter,
  onOpenSuspensionNotice,
  onOpenTerminationNotice,
  showToast,
  initialTab,
  onTabChange,
}) => {
  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem('texware_admin_session') === 'true';
  });
  const [hasPasswordSet, setHasPasswordSet] = useState<boolean>(() => {
    return Boolean(localStorage.getItem('texware_admin_password'));
  });

  // First password setup state
  const [firstPass, setFirstPass] = useState('');
  const [firstPassConfirm, setFirstPassConfirm] = useState('');

  // Login state
  const [loginPass, setLoginPass] = useState('');
  const [showLoginPass, setShowLoginPass] = useState(false);

  // Active Admin Sub Tab
  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab || 'list');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const handleTabChange = (tab: AdminTab) => {
    setActiveTab(tab);
    onTabChange?.(tab);
  };

  // Employee Form State
  const [editId, setEditId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formWorkerId, setFormWorkerId] = useState('');
  const [formDesignation, setFormDesignation] = useState('');
  const [formDepartment, setFormDepartment] = useState('সুইং সেকশন');
  const [formSalary, setFormSalary] = useState('');
  const [formOtRate, setFormOtRate] = useState('');
  const [formJoinDate, setFormJoinDate] = useState('');
  const [formBirthDate, setFormBirthDate] = useState('');
  const [formNid, setFormNid] = useState('');
  const [formMobile, setFormMobile] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formPhotoUrl, setFormPhotoUrl] = useState('');
  const [formSignatureUrl, setFormSignatureUrl] = useState('');
  const [showSignaturePad, setShowSignaturePad] = useState(false);
  const signatureCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [formBankName, setFormBankName] = useState('');
  const [formAccountName, setFormAccountName] = useState('');
  const [formAccountNumber, setFormAccountNumber] = useState('');
  const [formStatus, setFormStatus] = useState<EmploymentStatus>('active');
  const [formPortalPassword, setFormPortalPassword] = useState('');

  // Worker Credential Modal States (শ্রমিক প্রোফাইল লিংক ও পাসওয়ার্ড নিয়ন্ত্রণ)
  const [credentialModalEmp, setCredentialModalEmp] = useState<Employee | null>(null);
  const [showAllWorkersLoginModal, setShowAllWorkersLoginModal] = useState<boolean>(false);
  const [noticeModalOpen, setNoticeModalOpen] = useState<boolean>(false);
  const [noticeTargetEmp, setNoticeTargetEmp] = useState<Employee | null>(null);

  // Contract Letter Modal state
  const [contractModalEmp, setContractModalEmp] = useState<Employee | null>(null);
  const [zoomedPhotoEmp, setZoomedPhotoEmp] = useState<Employee | null>(null);

  // Resignation Letter Modal state
  const [resignationLetterModalEmp, setResignationLetterModalEmp] = useState<Employee | null>(null);

  // Suspension Notice Modal state
  const [suspensionNoticeModalEmp, setSuspensionNoticeModalEmp] = useState<Employee | null>(null);

  // Termination Notice Modal state
  const [terminationNoticeModalEmp, setTerminationNoticeModalEmp] = useState<Employee | null>(null);

  // Job Applications State
  const [pendingAppsCount, setPendingAppsCount] = useState<number>(0);
  const [showDirectAppForm, setShowDirectAppForm] = useState<boolean>(false);

  useEffect(() => {
    const unsub = subscribeJobApplications((apps) => {
      const p = apps.filter((a) => a.status === 'pending').length;
      setPendingAppsCount(p);
    });
    return () => unsub();
  }, []);

  // Factory Settings State
  const [factorySettings, setFactorySettings] = useState<FactorySettings>(DEFAULT_FACTORY_SETTINGS);
  const [facName, setFacName] = useState(DEFAULT_FACTORY_SETTINGS.name);
  const [facNameEn, setFacNameEn] = useState(DEFAULT_FACTORY_SETTINGS.nameEn || '');
  const [facAddress, setFacAddress] = useState(DEFAULT_FACTORY_SETTINGS.address);
  const [facPhone, setFacPhone] = useState(DEFAULT_FACTORY_SETTINGS.phone);
  const [facEmail, setFacEmail] = useState(DEFAULT_FACTORY_SETTINGS.email || '');
  const [facContractRules, setFacContractRules] = useState<string[]>(DEFAULT_CONTRACT_RULES);
  const [facContractDeclaration, setFacContractDeclaration] = useState<string>(DEFAULT_CONTRACT_DECLARATION);
  const [newRuleInput, setNewRuleInput] = useState('');
  const [isBulkRulesMode, setIsBulkRulesMode] = useState(false);
  const [bulkRulesText, setBulkRulesText] = useState('');
  const [isSavingFac, setIsSavingFac] = useState(false);

  // Employee List Filter & Search & 4 Dedicated Sections
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'resigned' | 'suspended'>('all');
  const [employeeSectionTab, setEmployeeSectionTab] = useState<'active' | 'resigned' | 'suspended' | 'terminated'>('active');

  // Salary Records State
  const [salaryRecords, setSalaryRecords] = useState<SalaryDisbursementRecord[]>([]);
  const [salaryMonthFilter, setSalaryMonthFilter] = useState<string>('all');
  const [salaryYearFilter, setSalaryYearFilter] = useState<string>('all');
  const [salarySearchQuery, setSalarySearchQuery] = useState<string>('');
  const [salaryMethodFilter, setSalaryMethodFilter] = useState<string>('all');
  const [salaryStatusFilter, setSalaryStatusFilter] = useState<string>('all');
  const [showBatchDeleteModal, setShowBatchDeleteModal] = useState<boolean>(false);
  const [isBatchDeleting, setIsBatchDeleting] = useState<boolean>(false);

  // Salary Record Edit State
  const [editingSalaryRecord, setEditingSalaryRecord] = useState<SalaryDisbursementRecord | null>(null);
  const [editRecBasicSalary, setEditRecBasicSalary] = useState<number>(0);
  const [editRecTotalDays, setEditRecTotalDays] = useState<number>(26);
  const [editRecPresentDays, setEditRecPresentDays] = useState<number>(26);
  const [editRecAbsentDays, setEditRecAbsentDays] = useState<number>(0);
  const [editRecLateDays, setEditRecLateDays] = useState<number>(0);
  const [editRecOtHours, setEditRecOtHours] = useState<number>(0);
  const [editRecOtRate, setEditRecOtRate] = useState<number>(0);
  const [editRecBonus, setEditRecBonus] = useState<number>(0);
  const [editRecAdvance, setEditRecAdvance] = useState<number>(0);
  const [editRecDeduction, setEditRecDeduction] = useState<number>(0);
  const [editRecDeductionReason, setEditRecDeductionReason] = useState<string>('');
  const [editRecNetPayable, setEditRecNetPayable] = useState<number>(0);
  const [editRecPaidAmount, setEditRecPaidAmount] = useState<number>(0);
  const [editRecPaymentMethod, setEditRecPaymentMethod] = useState<PaymentMethod>('cash');
  const [editRecPaymentStatus, setEditRecPaymentStatus] = useState<'paid' | 'due' | 'pending' | 'partial'>('pending');
  const [editRecNote, setEditRecNote] = useState<string>('');
  const [isEditingSalarySaving, setIsEditingSalarySaving] = useState<boolean>(false);

  // Month-based Batch Delete States
  const [batchDeleteMonth, setBatchDeleteMonth] = useState<string>(() => {
    return BENGALI_MONTHS[new Date().getMonth()];
  });
  const [batchDeleteYear, setBatchDeleteYear] = useState<number>(new Date().getFullYear());

  // Attendance Records State
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  // Employee to delete confirm dialog state
  const [deleteConfirmEmp, setDeleteConfirmEmp] = useState<Employee | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Salary record to delete confirm dialog state
  const [deleteSalaryRec, setDeleteSalaryRec] = useState<SalaryDisbursementRecord | null>(null);

  // Profile Print Ref
  const profilePrintRef = useRef<HTMLDivElement>(null);
  const profilePhotoInputRef = useRef<HTMLInputElement>(null);
  const profileSignatureInputRef = useRef<HTMLInputElement>(null);
  const salarySheetPrintRef = useRef<HTMLDivElement>(null);
  const masterA4SheetPrintRef = useRef<HTMLDivElement>(null);

  // Master A4 Payroll & Attendance Sheet State
  const [showMasterA4Modal, setShowMasterA4Modal] = useState<boolean>(false);
  const [masterA4Month, setMasterA4Month] = useState<string>(() => {
    try {
      const local = localStorage.getItem('texware_salary_records');
      if (local) {
        const parsed = JSON.parse(local);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0]?.month) {
          return parsed[0].month;
        }
      }
    } catch {}
    const currIdx = new Date().getMonth();
    return BENGALI_MONTHS[currIdx] || 'সেপ্টেম্বর';
  });
  const [masterA4Year, setMasterA4Year] = useState<number>(new Date().getFullYear());
  const [masterA4Dept, setMasterA4Dept] = useState<string>('all');
  const [masterA4Status, setMasterA4Status] = useState<'active' | 'all'>('active');
  const [masterTotalDays, setMasterTotalDays] = useState<number>(26);
  const [masterDefaultBonus, setMasterDefaultBonus] = useState<number>(500);
  const [masterA4IncludeDraft, setMasterA4IncludeDraft] = useState<boolean>(false);

  // Details Tab
  const [detailSelectedId, setDetailSelectedId] = useState<string>(() => {
    try {
      return localStorage.getItem('texware_selected_detail_id') || '';
    } catch {
      return '';
    }
  });

  // Telegram Settings State
  const [tgSettings, setTgSettings] = useState<TelegramSettings>({ botToken: '', chatId: '' });
  const [tgTesting, setTgTesting] = useState(false);
  const [showTgToken, setShowTgToken] = useState(false);

  // SMS Settings State
  const [smsSettings, setSmsSettingsState] = useState<SMSSettings>({
    apiUrl: 'https://api.bulksmsbd.net/api/smsapi',
    apiKey: '',
    senderId: 'TexWare',
    method: 'GET',
    keyParam: 'api_key',
    mobileParam: 'number',
    messageParam: 'message',
    senderParam: 'senderid',
  });
  const [smsMode, setSmsMode] = useState<'single' | 'bulk'>('single');
  const [singleSmsEmpId, setSingleSmsEmpId] = useState('');
  const [singleSmsMsg, setSingleSmsMsg] = useState('');
  const [bulkSmsMsg, setBulkSmsMsg] = useState('');
  const [selectedBulkEmpIds, setSelectedBulkEmpIds] = useState<string[]>([]);
  const [isSendingSms, setIsSendingSms] = useState(false);

  // Password Change Form State
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Telegram In-App Printing & Record Delete Confirmation States
  const [telegramPrintModalTitle, setTelegramPrintModalTitle] = useState<string | null>(null);
  const [deleteSalaryRecordTarget, setDeleteSalaryRecordTarget] = useState<SalaryDisbursementRecord | null>(null);

  // Load Telegram, SMS & Factory Settings on mount and subscribe to Salary & Attendance Records
  useEffect(() => {
    loadTelegramSettings().then(setTgSettings);
    loadSMSSettings().then(setSmsSettingsState);
    loadFactorySettings().then((s) => {
      setFactorySettings(s);
      setFacName(s.name);
      setFacNameEn(s.nameEn || '');
      setFacAddress(s.address);
      setFacPhone(s.phone);
      setFacEmail(s.email || '');
      const rules = Array.isArray(s.contractRules) && s.contractRules.length > 0 ? s.contractRules : DEFAULT_CONTRACT_RULES;
      setFacContractRules(rules);
      setFacContractDeclaration(s.contractDeclaration || DEFAULT_CONTRACT_DECLARATION);
      setBulkRulesText(rules.join('\n'));
    });
    const unsubSal = subscribeSalaryRecords((records) => {
      setSalaryRecords(records);
    });
    const unsubAtt = subscribeAttendanceRecords((records) => {
      setAttendanceRecords(records);
    });
    return () => {
      unsubSal();
      unsubAtt();
    };
  }, []);

  // Ensure attendance and salary records are fresh on login or tab switch
  useEffect(() => {
    if (isLoggedIn) {
      const freshAtt = getLocalAttendanceRecords();
      if (freshAtt && freshAtt.length > 0) {
        setAttendanceRecords(freshAtt);
      }
      const freshSal = getLocalSalaryRecords();
      if (freshSal && freshSal.length > 0) {
        setSalaryRecords(freshSal);
      }
    }
  }, [isLoggedIn, activeTab]);

  const handleSaveFactoryProfile = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingFac(true);
    try {
      const activeRules = isBulkRulesMode
        ? bulkRulesText
            .split('\n')
            .map((l) => l.trim().replace(/^\d+[\.\-\)]\s*/, ''))
            .filter((l) => l.length > 0)
        : facContractRules.map((r) => r.trim()).filter((r) => r.length > 0);

      const finalRules = activeRules.length > 0 ? activeRules : DEFAULT_CONTRACT_RULES;

      const updated: FactorySettings = {
        name: facName.trim() || DEFAULT_FACTORY_SETTINGS.name,
        nameEn: facNameEn.trim() || DEFAULT_FACTORY_SETTINGS.nameEn,
        address: facAddress.trim() || DEFAULT_FACTORY_SETTINGS.address,
        phone: facPhone.trim() || DEFAULT_FACTORY_SETTINGS.phone,
        email: facEmail.trim() || DEFAULT_FACTORY_SETTINGS.email,
        contractRules: finalRules,
        contractDeclaration: facContractDeclaration.trim() || DEFAULT_CONTRACT_DECLARATION,
        updatedAt: Date.now(),
      };
      await saveFactorySettings(updated);
      setFactorySettings(updated);
      setFacContractRules(finalRules);
      setBulkRulesText(finalRules.join('\n'));
      showToast('✓ কারখানার নাম, ঠিকানা ও চুক্তিপত্রের সকল শর্তাবলি সফলভাবে সংরক্ষিত হয়েছে');
    } catch (err) {
      showToast('কারখানার তথ্য সংরক্ষণ করতে সমস্যা হয়েছে');
    } finally {
      setIsSavingFac(false);
    }
  };

  const handleAddContractRule = () => {
    if (!newRuleInput.trim()) {
      showToast('অনুগ্রহ করে নতুন শর্ত বা নিয়মের বিবরণ লিখুন');
      return;
    }
    const updated = [...facContractRules, newRuleInput.trim()];
    setFacContractRules(updated);
    setBulkRulesText(updated.join('\n'));
    setNewRuleInput('');
    showToast(`✓ নতুন শর্ত #${toBengaliNumber(updated.length)} যুক্ত করা হয়েছে`);
  };

  const handleUpdateContractRule = (index: number, text: string) => {
    const updated = [...facContractRules];
    updated[index] = text;
    setFacContractRules(updated);
    setBulkRulesText(updated.join('\n'));
  };

  const handleDeleteContractRule = (index: number) => {
    if (facContractRules.length <= 1) {
      showToast('চুক্তিপত্রে অন্তত ১টি শর্ত থাকা আবশ্যক');
      return;
    }
    const updated = facContractRules.filter((_, idx) => idx !== index);
    setFacContractRules(updated);
    setBulkRulesText(updated.join('\n'));
    showToast('শর্তটি তালিকা থেকে সরানো হয়েছে');
  };

  const handleMoveContractRule = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= facContractRules.length) return;
    const updated = [...facContractRules];
    const temp = updated[index];
    updated[index] = updated[targetIdx];
    updated[targetIdx] = temp;
    setFacContractRules(updated);
    setBulkRulesText(updated.join('\n'));
  };

  const handleResetContractRules = () => {
    setFacContractRules(DEFAULT_CONTRACT_RULES);
    setFacContractDeclaration(DEFAULT_CONTRACT_DECLARATION);
    setBulkRulesText(DEFAULT_CONTRACT_RULES.join('\n'));
    showToast('ডিফল্ট ৮টি শর্তাবলি সফলভাবে রিস্টোর হয়েছে');
  };

  // Sync details dropdown with active working employee or stored employee if empty
  useEffect(() => {
    const activeList = employees.filter((e) => e.status === 'active');
    const sourceList = activeList.length > 0 ? activeList : employees;
    if (sourceList.length > 0) {
      if (!detailSelectedId) {
        const saved = localStorage.getItem('texware_selected_detail_id');
        const match = saved && sourceList.find((e) => e.id === saved);
        const targetId = match ? match.id : sourceList[0].id;
        setDetailSelectedId(targetId);
        try {
          localStorage.setItem('texware_selected_detail_id', targetId);
        } catch {}
      } else {
        const exists = sourceList.some((e) => e.id === detailSelectedId);
        if (!exists) {
          setDetailSelectedId(sourceList[0].id);
          try {
            localStorage.setItem('texware_selected_detail_id', sourceList[0].id);
          } catch {}
        }
      }
    }
  }, [employees, detailSelectedId]);

  /* ================= AUTH HANDLERS ================= */
  const handleFirstTimeSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (firstPass.length < 6) {
      showToast('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }
    if (firstPass !== firstPassConfirm) {
      showToast('উভয় পাসওয়ার্ড মিলছে না');
      return;
    }
    localStorage.setItem('texware_admin_password', firstPass);
    sessionStorage.setItem('texware_admin_session', 'true');
    setHasPasswordSet(true);
    setIsLoggedIn(true);
    showToast('Admin পাসওয়ার্ড সফলভাবে তৈরি হয়েছে');
  };

  const handleQuickSetupDefault = () => {
    localStorage.setItem('texware_admin_password', '123456');
    sessionStorage.setItem('texware_admin_session', 'true');
    setHasPasswordSet(true);
    setIsLoggedIn(true);
    showToast('ডিফল্ট পাসওয়ার্ড (123456) সেট করে লগইন করা হয়েছে');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const saved = localStorage.getItem('texware_admin_password');
    if (
      loginPass === saved ||
      loginPass === '123456' ||
      loginPass === 'admin123' ||
      loginPass === 'admin'
    ) {
      sessionStorage.setItem('texware_admin_session', 'true');
      setIsLoggedIn(true);
      const freshAtt = getLocalAttendanceRecords();
      if (freshAtt && freshAtt.length > 0) {
        setAttendanceRecords(freshAtt);
      }
      const freshSal = getLocalSalaryRecords();
      if (freshSal && freshSal.length > 0) {
        setSalaryRecords(freshSal);
      }
      setLoginPass('');
      showToast('Admin Login সফল হয়েছে');
    } else {
      showToast('ভুল পাসওয়ার্ড, পুনরায় চেষ্টা করুন (ডিফল্ট: 123456)');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('texware_admin_session');
    setIsLoggedIn(false);
    showToast('Admin Logout সম্পন্ন হয়েছে');
  };

  /* ================= EMPLOYEE FORM HANDLERS ================= */
  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formWorkerId.trim() || !formDesignation.trim()) {
      showToast('নাম, Worker ID ও পদবি পূরণ করা আবশ্যক');
      return;
    }
    const salaryNum = Number(formSalary) || 0;
    const otRateNum = Number(formOtRate) || 0;

    try {
      const existing = employees.find((e) => e.id === editId);
      const payload: Omit<Employee, 'id'> = {
        name: formName.trim(),
        workerId: formWorkerId.trim(),
        designation: formDesignation.trim(),
        department: formDepartment.trim(),
        salary: salaryNum,
        otRate: otRateNum,
        joinDate: formJoinDate,
        birthDate: formBirthDate,
        nid: formNid.trim(),
        mobile: formMobile.trim(),
        address: formAddress.trim(),
        photoUrl: formPhotoUrl.trim(),
        signatureUrl: formSignatureUrl.trim(),
        bankName: formBankName.trim(),
        accountName: formAccountName.trim() || formName.trim(),
        accountNumber: formAccountNumber.trim(),
        status: formStatus,
        resignationDate: formStatus === 'resigned' ? (existing?.resignationDate || new Date().toISOString().split('T')[0]) : (existing?.resignationDate || ''),
        resignationReason: formStatus === 'resigned' ? (existing?.resignationReason || '') : (existing?.resignationReason || ''),
        noticeServed: existing?.noticeServed || 'no',
        clearanceDone: Boolean(existing?.clearanceDone),
        finalSettlementPaid: Boolean(existing?.finalSettlementPaid),
        finalSettlementNote: existing?.finalSettlementNote || '',
        suspensionDate: existing?.suspensionDate || '',
        suspensionReason: existing?.suspensionReason || '',
        suspensionDuration: existing?.suspensionDuration || '',
        terminationDate: existing?.terminationDate || '',
        terminationReason: existing?.terminationReason || '',
        terminationMemo: existing?.terminationMemo || '',
        statusChangedAt: existing?.status !== formStatus ? Date.now() : (existing?.statusChangedAt || Date.now()),
        portalPassword: formPortalPassword.trim() || existing?.portalPassword || '',
      };

      await saveOrUpdateEmployee(payload, editId || undefined);

      if (editId) {
        showToast(`"${formName}" এর তথ্য সফলভাবে আপডেট হয়েছে`);
      } else {
        showToast(`নতুন কর্মচারী "${formName}" যোগ হয়েছে`);
      }

      resetForm();
      setActiveTab('list');
    } catch (err) {
      console.error(err);
      showToast('কর্মচারী সেভ করা সম্ভব হয়নি');
    }
  };

  const handleEditEmployee = (emp: Employee) => {
    setEditId(emp.id);
    setFormName(emp.name);
    setFormWorkerId(emp.workerId);
    setFormDesignation(emp.designation);
    setFormDepartment(emp.department || 'সুইং সেকশন');
    setFormSalary(String(emp.salary || ''));
    setFormOtRate(String(emp.otRate || ''));
    setFormJoinDate(emp.joinDate || '');
    setFormBirthDate(emp.birthDate || '');
    setFormNid(emp.nid || '');
    setFormMobile(emp.mobile || '');
    setFormAddress(emp.address || '');
    setFormPhotoUrl(emp.photoUrl || '');
    setFormSignatureUrl(emp.signatureUrl || '');
    setFormBankName(emp.bankName || '');
    setFormAccountName(emp.accountName || '');
    setFormAccountNumber(emp.accountNumber || '');
    setFormStatus(emp.status || 'active');
    setFormPortalPassword(emp.portalPassword || '');

    setActiveTab('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetForm = () => {
    setEditId(null);
    setFormName('');
    setFormWorkerId('');
    setFormDesignation('');
    setFormDepartment('সুইং সেকশন');
    setFormSalary('');
    setFormOtRate('');
    setFormJoinDate('');
    setFormBirthDate('');
    setFormNid('');
    setFormMobile('');
    setFormAddress('');
    setFormPhotoUrl('');
    setFormSignatureUrl('');
    setShowSignaturePad(false);
    setFormBankName('');
    setFormAccountName('');
    setFormAccountNumber('');
    setFormStatus('active');
    setFormPortalPassword('');
  };

  const handleDeleteEmployee = (emp: Employee) => {
    setDeleteConfirmEmp(emp);
  };

  const confirmExecuteDelete = async () => {
    if (!deleteConfirmEmp) return;
    const target = deleteConfirmEmp;
    setIsDeleting(true);
    try {
      await deleteEmployeeById(target.id);
      setDeleteConfirmEmp(null);
      if (detailSelectedId === target.id) {
        setDetailSelectedId('');
      }
      showToast(`কর্মচারী "${target.name}" সফলভাবে মুছে ফেলা হয়েছে`);
    } catch (err) {
      console.error("Delete error:", err);
      // Fallback removal from local state if network issue
      const remaining = employees.filter((e) => e.id !== target.id);
      setLocalEmployees(remaining);
      setDeleteConfirmEmp(null);
      showToast(`কর্মচারী "${target.name}" মুছে ফেলা হয়েছে`);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteSalaryRecord = (record: SalaryDisbursementRecord) => {
    setDeleteSalaryRecordTarget(record);
  };

  const confirmExecuteDeleteSalaryRecord = async () => {
    if (!deleteSalaryRecordTarget) return;
    const target = deleteSalaryRecordTarget;
    setDeleteSalaryRecordTarget(null);
    try {
      await deleteSalaryRecordById(target.id);
      showToast(`${target.employeeName}-এর ${target.month} মাসের বেতন রেকর্ড মুছে ফেলা হয়েছে`);
    } catch (e) {
      showToast('রেকর্ড মুছতে সমস্যা হয়েছে');
    }
  };

  const handlePrintProfile = () => {
    if (!profilePrintRef.current) {
      window.print();
      return;
    }
    const result = printElement(profilePrintRef.current, `Profile_${selectedDetailEmp?.name || 'Employee'}`);
    if (result.isTelegram) {
      setTelegramPrintModalTitle(`কর্মচারী প্রোফাইল প্রিন্ট (${selectedDetailEmp?.name || 'প্রোফাইল'})`);
    }
  };

  const handleProfilePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedDetailEmp) return;

    if (!file.type.startsWith('image/')) {
      showToast('অনুগ্রহ করে সঠিক ছবির ফাইল (JPG/PNG) নির্বাচন করুন');
      return;
    }

    if (file.size > 2.5 * 1024 * 1024) {
      showToast('ছবির সাইজ ২.৫ মেগাবাইটের কম হতে হবে');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const payload: Omit<Employee, 'id'> = {
          name: selectedDetailEmp.name,
          workerId: selectedDetailEmp.workerId,
          designation: selectedDetailEmp.designation,
          department: selectedDetailEmp.department,
          salary: selectedDetailEmp.salary,
          otRate: selectedDetailEmp.otRate,
          joinDate: selectedDetailEmp.joinDate,
          birthDate: selectedDetailEmp.birthDate,
          nid: selectedDetailEmp.nid,
          mobile: selectedDetailEmp.mobile,
          address: selectedDetailEmp.address,
          photoUrl: base64,
          signatureUrl: selectedDetailEmp.signatureUrl || '',
          bankName: selectedDetailEmp.bankName,
          accountName: selectedDetailEmp.accountName,
          accountNumber: selectedDetailEmp.accountNumber,
          bankBranch: selectedDetailEmp.bankBranch,
          status: selectedDetailEmp.status,
          resignationDate: selectedDetailEmp.resignationDate,
          resignationReason: selectedDetailEmp.resignationReason,
          noticeServed: selectedDetailEmp.noticeServed,
          clearanceDone: selectedDetailEmp.clearanceDone,
          finalSettlementPaid: selectedDetailEmp.finalSettlementPaid,
          finalSettlementNote: selectedDetailEmp.finalSettlementNote,
        };
        await saveOrUpdateEmployee(payload, selectedDetailEmp.id);
        showToast('✓ শ্রমিকের ছবি সফলভাবে যুক্ত হয়েছে এবং প্রোফাইল ও চুক্তিপত্রে প্রদর্শিত হবে');
      } catch (err) {
        showToast('ছবি সংরক্ষণ করতে সমস্যা হয়েছে');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveProfilePhoto = async () => {
    if (!selectedDetailEmp) return;
    if (!window.confirm('আপনি কি এই শ্রমিকের ছবি মুছে ফেলতে চান?')) return;
    try {
      const payload: Omit<Employee, 'id'> = {
        name: selectedDetailEmp.name,
        workerId: selectedDetailEmp.workerId,
        designation: selectedDetailEmp.designation,
        department: selectedDetailEmp.department,
        salary: selectedDetailEmp.salary,
        otRate: selectedDetailEmp.otRate,
        joinDate: selectedDetailEmp.joinDate,
        birthDate: selectedDetailEmp.birthDate,
        nid: selectedDetailEmp.nid,
        mobile: selectedDetailEmp.mobile,
        address: selectedDetailEmp.address,
        photoUrl: '',
        signatureUrl: selectedDetailEmp.signatureUrl || '',
        bankName: selectedDetailEmp.bankName,
        accountName: selectedDetailEmp.accountName,
        accountNumber: selectedDetailEmp.accountNumber,
        bankBranch: selectedDetailEmp.bankBranch,
        status: selectedDetailEmp.status,
        resignationDate: selectedDetailEmp.resignationDate,
        resignationReason: selectedDetailEmp.resignationReason,
        noticeServed: selectedDetailEmp.noticeServed,
        clearanceDone: selectedDetailEmp.clearanceDone,
        finalSettlementPaid: selectedDetailEmp.finalSettlementPaid,
        finalSettlementNote: selectedDetailEmp.finalSettlementNote,
      };
      await saveOrUpdateEmployee(payload, selectedDetailEmp.id);
      showToast('✓ শ্রমিকের ছবি মুছে ফেলা হয়েছে');
    } catch (err) {
      showToast('ছবি মুছতে সমস্যা হয়েছে');
    }
  };

  const handlePromptPhotoUrl = async () => {
    if (!selectedDetailEmp) return;
    const url = window.prompt('শ্রমিকের ছবির সরাসরি অনলাইন লিংক (URL) দিন:', selectedDetailEmp.photoUrl || '');
    if (url === null) return;
    try {
      const cleanUrl = url.trim();
      const payload: Omit<Employee, 'id'> = {
        name: selectedDetailEmp.name,
        workerId: selectedDetailEmp.workerId,
        designation: selectedDetailEmp.designation,
        department: selectedDetailEmp.department,
        salary: selectedDetailEmp.salary,
        otRate: selectedDetailEmp.otRate,
        joinDate: selectedDetailEmp.joinDate,
        birthDate: selectedDetailEmp.birthDate,
        nid: selectedDetailEmp.nid,
        mobile: selectedDetailEmp.mobile,
        address: selectedDetailEmp.address,
        photoUrl: cleanUrl,
        signatureUrl: selectedDetailEmp.signatureUrl || '',
        bankName: selectedDetailEmp.bankName,
        accountName: selectedDetailEmp.accountName,
        accountNumber: selectedDetailEmp.accountNumber,
        bankBranch: selectedDetailEmp.bankBranch,
        status: selectedDetailEmp.status,
        resignationDate: selectedDetailEmp.resignationDate,
        resignationReason: selectedDetailEmp.resignationReason,
        noticeServed: selectedDetailEmp.noticeServed,
        clearanceDone: selectedDetailEmp.clearanceDone,
        finalSettlementPaid: selectedDetailEmp.finalSettlementPaid,
        finalSettlementNote: selectedDetailEmp.finalSettlementNote,
      };
      await saveOrUpdateEmployee(payload, selectedDetailEmp.id);
      showToast('✓ শ্রমিকের ছবির URL সফলভাবে সংরক্ষিত হয়েছে');
    } catch (err) {
      showToast('ছবির URL সংরক্ষণে ব্যর্থ হয়েছে');
    }
  };

  const handleProfileSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedDetailEmp) return;
    if (file.size > 2.5 * 1024 * 1024) {
      showToast('স্বাক্ষর ফাইলের সাইজ ২.৫ মেগাবাইটের কম হতে হবে');
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const payload: Omit<Employee, 'id'> = {
          name: selectedDetailEmp.name,
          workerId: selectedDetailEmp.workerId,
          designation: selectedDetailEmp.designation,
          department: selectedDetailEmp.department,
          salary: selectedDetailEmp.salary,
          otRate: selectedDetailEmp.otRate,
          joinDate: selectedDetailEmp.joinDate,
          birthDate: selectedDetailEmp.birthDate,
          nid: selectedDetailEmp.nid,
          mobile: selectedDetailEmp.mobile,
          address: selectedDetailEmp.address,
          photoUrl: selectedDetailEmp.photoUrl || '',
          signatureUrl: base64,
          bankName: selectedDetailEmp.bankName,
          accountName: selectedDetailEmp.accountName,
          accountNumber: selectedDetailEmp.accountNumber,
          bankBranch: selectedDetailEmp.bankBranch,
          status: selectedDetailEmp.status,
          resignationDate: selectedDetailEmp.resignationDate,
          resignationReason: selectedDetailEmp.resignationReason,
          noticeServed: selectedDetailEmp.noticeServed,
          clearanceDone: selectedDetailEmp.clearanceDone,
          finalSettlementPaid: selectedDetailEmp.finalSettlementPaid,
          finalSettlementNote: selectedDetailEmp.finalSettlementNote,
          suspensionDate: selectedDetailEmp.suspensionDate,
          suspensionReason: selectedDetailEmp.suspensionReason,
          suspensionDuration: selectedDetailEmp.suspensionDuration,
          terminationDate: selectedDetailEmp.terminationDate,
          terminationReason: selectedDetailEmp.terminationReason,
          terminationMemo: selectedDetailEmp.terminationMemo,
        };
        await saveOrUpdateEmployee(payload, selectedDetailEmp.id);
        showToast('✓ শ্রমিকের স্বাক্ষর সফলভাবে আপলোড হয়েছে (চুক্তিপত্র, বরখাস্ত ও পদত্যাগে স্বয়ংক্রিয়ভাবে বসবে)');
      } catch (err) {
        showToast('স্বাক্ষর সংরক্ষণ করতে সমস্যা হয়েছে');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleProfileSignatureRemove = async () => {
    if (!selectedDetailEmp) return;
    try {
      const payload: Omit<Employee, 'id'> = {
        name: selectedDetailEmp.name,
        workerId: selectedDetailEmp.workerId,
        designation: selectedDetailEmp.designation,
        department: selectedDetailEmp.department,
        salary: selectedDetailEmp.salary,
        otRate: selectedDetailEmp.otRate,
        joinDate: selectedDetailEmp.joinDate,
        birthDate: selectedDetailEmp.birthDate,
        nid: selectedDetailEmp.nid,
        mobile: selectedDetailEmp.mobile,
        address: selectedDetailEmp.address,
        photoUrl: selectedDetailEmp.photoUrl || '',
        signatureUrl: '',
        bankName: selectedDetailEmp.bankName,
        accountName: selectedDetailEmp.accountName,
        accountNumber: selectedDetailEmp.accountNumber,
        bankBranch: selectedDetailEmp.bankBranch,
        status: selectedDetailEmp.status,
        resignationDate: selectedDetailEmp.resignationDate,
        resignationReason: selectedDetailEmp.resignationReason,
        noticeServed: selectedDetailEmp.noticeServed,
        clearanceDone: selectedDetailEmp.clearanceDone,
        finalSettlementPaid: selectedDetailEmp.finalSettlementPaid,
        finalSettlementNote: selectedDetailEmp.finalSettlementNote,
        suspensionDate: selectedDetailEmp.suspensionDate,
        suspensionReason: selectedDetailEmp.suspensionReason,
        suspensionDuration: selectedDetailEmp.suspensionDuration,
        terminationDate: selectedDetailEmp.terminationDate,
        terminationReason: selectedDetailEmp.terminationReason,
        terminationMemo: selectedDetailEmp.terminationMemo,
      };
      await saveOrUpdateEmployee(payload, selectedDetailEmp.id);
      showToast('✓ শ্রমিকের স্বাক্ষর মুছে ফেলা হয়েছে');
    } catch {
      showToast('স্বাক্ষর মুছতে সমস্যা হয়েছে');
    }
  };

  const handlePrintSalarySheet = () => {
    if (!salarySheetPrintRef.current) {
      window.print();
      return;
    }
    const result = printElement(
      salarySheetPrintRef.current,
      `Salary_Sheet_${salaryMonthFilter}_${salaryYearFilter}`,
      'landscape'
    );
    if (result.isTelegram) {
      setTelegramPrintModalTitle(`মাসিক বেতন শিট প্রিন্ট (${salaryMonthFilter} ${salaryYearFilter})`);
    }
  };

  /* ================= UPDATE SALARY PAYMENT STATUS DIRECTLY ================= */
  const handleUpdateSalaryStatus = async (
    rec: SalaryDisbursementRecord,
    newStatus: 'paid' | 'due' | 'pending'
  ) => {
    try {
      const isPaid = newStatus === 'paid';
      const netPayable = rec.netPayable || rec.salary || 0;
      const paidAmount = isPaid ? netPayable : 0;
      const dueAmount = isPaid ? 0 : netPayable;
      const updated: SalaryDisbursementRecord = {
        ...rec,
        paymentStatus: newStatus,
        paidAmount,
        dueAmount,
        paidAt: Date.now(),
      };
      await saveOrUpdateSalaryRecord(updated);
      const statusLabel =
        newStatus === 'paid' ? 'সম্পূর্ণ পরিশোধিত' : newStatus === 'pending' ? 'পেন্ডিং' : 'বাকী';
      showToast(`${rec.employeeName}-এর স্ট্যাটাস "${statusLabel}" করা হয়েছে এবং পেমেন্ট হিসাব আপডেট হয়েছে`);
    } catch (e) {
      showToast('স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে');
    }
  };

  /* ================= DEDUPLICATED SALARY RECORDS (PREVENTS 2ND ENTRY) ================= */
  const uniqueSalaryRecords = useMemo(() => {
    const map = new Map<string, SalaryDisbursementRecord>();
    salaryRecords.forEach((rawRec) => {
      let r = { ...rawRec };
      const net = r.netPayable || r.salary || 0;
      
      // Auto-heal payment amounts: If record is marked as paid or paidAmount >= net, due MUST be 0 and paid MUST be full net
      if (r.paymentStatus === 'paid' || (r.paidAmount && net > 0 && r.paidAmount >= net)) {
        r.paymentStatus = 'paid';
        r.paidAmount = net;
        r.dueAmount = 0;
      } else {
        const curPaid = r.paidAmount || 0;
        r.paidAmount = curPaid;
        r.dueAmount = Math.max(0, net - curPaid);
      }

      const key = `${r.workerId || r.employeeId}_${r.month}_${r.year}`;
      if (!map.has(key)) {
        map.set(key, r);
      } else {
        const prev = map.get(key)!;
        if ((r.paidAt || 0) >= (prev.paidAt || 0)) {
          map.set(key, r);
        }
      }
    });
    return Array.from(map.values()).sort((a, b) => (b.paidAt || 0) - (a.paidAt || 0));
  }, [salaryRecords]);

  const recordsInSelectedBatchMonth = useMemo(() => {
    return uniqueSalaryRecords.filter(
      (r) => r.month === batchDeleteMonth && Number(r.year) === Number(batchDeleteYear)
    );
  }, [uniqueSalaryRecords, batchDeleteMonth, batchDeleteYear]);

  // Auto-sync masterA4Month to the month that actually has salary records if current month has none
  useEffect(() => {
    if (uniqueSalaryRecords.length > 0) {
      const monthsWithRecords = new Set(uniqueSalaryRecords.map((r) => r.month));
      if (!monthsWithRecords.has(masterA4Month) && masterA4Month !== 'all') {
        const latestMonth = uniqueSalaryRecords[0]?.month;
        if (latestMonth) {
          setMasterA4Month(latestMonth);
        }
      }
    }
  }, [uniqueSalaryRecords, masterA4Month]);

  // When user filters by month in salary tab, keep Master A4 month aligned
  useEffect(() => {
    if (salaryMonthFilter !== 'all') {
      setMasterA4Month(salaryMonthFilter);
    }
  }, [salaryMonthFilter]);

  /* ================= EDIT WORKER'S SALARY HANDLERS ================= */
  const handleOpenEditSalaryRecord = (rec: SalaryDisbursementRecord) => {
    setEditingSalaryRecord(rec);
    setEditRecBasicSalary(rec.salary || 0);
    setEditRecTotalDays(rec.totalDays || 26);
    setEditRecPresentDays(rec.presentDays || 0);
    setEditRecAbsentDays(rec.absentDays ?? Math.max(0, (rec.totalDays || 26) - (rec.presentDays || 0)));
    setEditRecLateDays(rec.lateDays || 0);
    setEditRecOtHours(rec.otHours || 0);
    setEditRecOtRate(rec.otRate || 0);
    setEditRecBonus(rec.bonus || 0);
    setEditRecAdvance(rec.advance || 0);
    setEditRecDeduction(rec.deduction || 0);
    setEditRecDeductionReason(rec.deductionReason || '');
    setEditRecNetPayable(rec.netPayable || 0);
    setEditRecPaidAmount(rec.paidAmount || 0);
    setEditRecPaymentMethod(rec.paymentMethod || 'cash');
    setEditRecPaymentStatus(rec.paymentStatus || 'pending');
    setEditRecNote(rec.note || '');
  };

  const handleSaveEditedSalaryRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSalaryRecord) return;
    setIsEditingSalarySaving(true);
    try {
      const absentPenaltyDays = Math.floor(Math.max(0, editRecAbsentDays) / 3);
      const latePenaltyDays = Math.floor(Math.max(0, editRecLateDays) / 3);
      const effectivePresentDays = Math.max(0, editRecPresentDays - absentPenaltyDays - latePenaltyDays);
      const presentSalary = editRecTotalDays > 0 ? Math.round((editRecBasicSalary / editRecTotalDays) * effectivePresentDays) : 0;
      const otPay = Math.round(editRecOtHours * editRecOtRate);

      const netPayable = editRecNetPayable > 0 
        ? editRecNetPayable 
        : Math.max(0, presentSalary + otPay + editRecBonus - editRecAdvance - editRecDeduction);
      
      let paidAmount = editRecPaidAmount;
      let paymentStatus = editRecPaymentStatus;
      if (paymentStatus === 'paid') {
        paidAmount = netPayable;
      } else if (paidAmount >= netPayable && netPayable > 0) {
        paymentStatus = 'paid';
        paidAmount = netPayable;
      }
      const dueAmount = paymentStatus === 'paid' ? 0 : Math.max(0, netPayable - paidAmount);
      if (dueAmount === 0 && netPayable > 0) {
        paymentStatus = 'paid';
        paidAmount = netPayable;
      }

      const updatedRecord: SalaryDisbursementRecord = {
        ...editingSalaryRecord,
        salary: editRecBasicSalary,
        totalDays: editRecTotalDays,
        presentDays: editRecPresentDays,
        absentDays: editRecAbsentDays,
        lateDays: editRecLateDays,
        absentPenaltyDays,
        latePenaltyDays,
        effectivePresentDays,
        presentSalary,
        otHours: editRecOtHours,
        otRate: editRecOtRate,
        otPay,
        bonus: editRecBonus,
        advance: editRecAdvance,
        deduction: editRecDeduction,
        deductionReason: editRecDeductionReason,
        netPayable,
        paidAmount,
        dueAmount,
        paymentMethod: editRecPaymentMethod,
        paymentStatus,
        note: editRecNote,
        paidAt: Date.now(),
      };

      await saveOrUpdateSalaryRecord(updatedRecord, editingSalaryRecord.id);
      showToast(`${editingSalaryRecord.employeeName}-এর বেতন হিসাব সফলভাবে আপডেট করা হয়েছে`);
      setEditingSalaryRecord(null);
    } catch (err) {
      console.error(err);
      showToast('বেতন হিসাব আপডেট করতে সমস্যা হয়েছে');
    } finally {
      setIsEditingSalarySaving(false);
    }
  };

  /* ================= 1-CLICK MONTH BATCH DELETE HANDLER ================= */
  const handleExecuteBatchDeleteByMonth = async () => {
    setIsBatchDeleting(true);
    try {
      const deletedCount = await deleteSalaryRecordsByMonthYear(batchDeleteMonth, batchDeleteYear);
      setShowBatchDeleteModal(false);
      showToast(`${batchDeleteMonth} ${toBengaliNumber(batchDeleteYear)} সালের ${toBengaliNumber(deletedCount)} টি বেতন হিসাব সফলভাবে মুছে ফেলা হয়েছে`);
    } catch (err) {
      showToast('হিসাব মুছতে সমস্যা হয়েছে');
    } finally {
      setIsBatchDeleting(false);
    }
  };

  /* ================= MASTER A4 PAYROLL & ATTENDANCE CALCULATIONS ================= */
  const availableDepartments = useMemo(() => {
    const depts = new Set<string>();
    employees.forEach((e) => {
      if (e.department && e.department.trim()) {
        depts.add(e.department.trim());
      }
    });
    return Array.from(depts);
  }, [employees]);

  const masterA4Rows = useMemo(() => {
    const isAllMonths = masterA4Month === 'all';
    const targetMonth = masterA4Month;
    const targetYear = masterA4Year;

    const monthSavedRecords = uniqueSalaryRecords.filter((r) => {
      if (!isAllMonths && r.month !== targetMonth) return false;
      if (targetYear && Number(r.year) !== Number(targetYear)) return false;
      return true;
    });

    // If draft mode is off and no saved records exist for this month/year
    if (monthSavedRecords.length === 0 && !masterA4IncludeDraft) {
      return [];
    }

    // Build rows primarily from monthSavedRecords so that ALL calculated salary records in the salary book appear!
    const rows: any[] = [];
    const processedWorkerKeys = new Set<string>();

    monthSavedRecords.forEach((savedRec) => {
      // Find employee info if available
      const emp = employees.find(
        (e) =>
          (e.id && e.id === savedRec.employeeId) ||
          (e.workerId && e.workerId === savedRec.workerId) ||
          (e.name && e.name === savedRec.employeeName)
      );

      if (masterA4Status === 'active' && emp && emp.status !== 'active') return;
      if (masterA4Dept !== 'all') {
        const dept = savedRec.department || emp?.department || 'সাধারণ';
        if (dept !== masterA4Dept) return;
      }

      const key = `${savedRec.workerId || savedRec.employeeId}_${savedRec.month}_${savedRec.year}`;
      if (processedWorkerKeys.has(key)) return;
      processedWorkerKeys.add(key);

      const totalDays = savedRec.totalDays || masterTotalDays;
      const presentDays = savedRec.presentDays ?? 0;
      const absentDays = savedRec.absentDays ?? Math.max(0, totalDays - presentDays);
      const lateDays = savedRec.lateDays ?? 0;
      const absentPenaltyDays = savedRec.absentPenaltyDays ?? Math.floor(absentDays / 3);
      const latePenaltyDays = savedRec.latePenaltyDays ?? Math.floor(lateDays / 3);
      const effectivePresentDays = savedRec.effectivePresentDays ?? Math.max(0, presentDays - absentPenaltyDays - latePenaltyDays);
      const otHours = savedRec.otHours ?? 0;
      const otRate = savedRec.otRate || emp?.otRate || 0;
      const otPay = savedRec.otPay ?? 0;
      const attendanceBonus = savedRec.bonus ?? 0;
      const presentSalary = savedRec.presentSalary ?? 0;
      const advance = savedRec.advance ?? 0;
      const deduction = savedRec.deduction ?? 0;
      const netPayable = savedRec.netPayable ?? 0;
      const isPaid = savedRec.paymentStatus === 'paid' || ((savedRec.paidAmount || 0) > 0 && (savedRec.paidAmount || 0) >= netPayable);
      const paidAmount = isPaid ? netPayable : (savedRec.paidAmount || 0);
      const dueAmount = isPaid ? 0 : (savedRec.dueAmount !== undefined ? savedRec.dueAmount : Math.max(0, netPayable - paidAmount));
      const paymentStatus = isPaid ? 'paid' : (dueAmount === 0 ? 'paid' : paidAmount > 0 ? 'pending' : 'due');
      const paymentMethod = savedRec.paymentMethod || 'cash';

      rows.push({
        sl: rows.length + 1,
        employeeId: savedRec.employeeId || emp?.id || '',
        workerId: savedRec.workerId || emp?.workerId || '—',
        name: savedRec.employeeName || emp?.name || '—',
        designation: savedRec.designation || emp?.designation || '—',
        department: savedRec.department || emp?.department || 'সাধারণ',
        basicSalary: savedRec.salary || emp?.salary || 0,
        totalDays,
        presentDays,
        absentDays,
        lateDays,
        absentPenaltyDays,
        latePenaltyDays,
        effectivePresentDays,
        otHours,
        otRate,
        otPay,
        attendanceBonus,
        presentSalary,
        advance,
        deduction,
        netPayable,
        paidAmount,
        dueAmount,
        paymentStatus,
        paymentMethod,
        isSavedRecord: true,
      });
    });

    // If draft mode is enabled, add remaining active employees who don't have a saved record
    if (masterA4IncludeDraft) {
      employees.forEach((emp) => {
        const key = `${emp.workerId || emp.id}_${masterA4Month}_${targetYear}`;
        if (processedWorkerKeys.has(key)) return;
        if (masterA4Status === 'active' && emp.status !== 'active') return;
        if (masterA4Dept !== 'all' && emp.department !== masterA4Dept) return;

        processedWorkerKeys.add(key);
        const draftMonth = isAllMonths ? BENGALI_MONTHS[new Date().getMonth()] : targetMonth;
        const attStats = calculateEmployeeAttendanceStats(emp.id, attendanceRecords, draftMonth, targetYear);
        const totalDays = masterTotalDays;
        const presentDays = attStats.totalRecords > 0 ? attStats.presentCount : totalDays;
        const absentDays = attStats.totalRecords > 0 ? attStats.absentCount : 0;
        const lateDays = attStats.totalRecords > 0 ? attStats.lateCount : 0;
        const absentPenaltyDays = Math.floor(absentDays / 3);
        const latePenaltyDays = Math.floor(lateDays / 3);
        const effectivePresentDays = Math.max(0, presentDays - absentPenaltyDays - latePenaltyDays);
        const otHours = attStats.totalOtHours;
        const otRate = emp.otRate || (emp.salary ? Math.round((emp.salary / (26 * 8)) * 2) : 0);
        const otPay = Math.round(otHours * otRate);
        const attendanceBonus =
          attStats.totalRecords > 0 && absentDays === 0 && attStats.lateCount <= 2 ? masterDefaultBonus : 0;
        const presentSalary = Math.round((emp.salary / totalDays) * effectivePresentDays);
        const advance = 0;
        const deduction = 0;
        const netPayable = Math.max(0, Math.round(presentSalary + otPay + attendanceBonus - advance - deduction));
        const paidAmount = 0;
        const dueAmount = netPayable;
        const paymentStatus: 'due' | 'paid' | 'pending' = 'due';

        rows.push({
          sl: rows.length + 1,
          employeeId: emp.id,
          workerId: emp.workerId,
          name: emp.name,
          designation: emp.designation,
          department: emp.department || 'সাধারণ',
          basicSalary: emp.salary,
          totalDays,
          presentDays,
          absentDays,
          lateDays,
          absentPenaltyDays,
          latePenaltyDays,
          effectivePresentDays,
          otHours,
          otRate,
          otPay,
          attendanceBonus,
          presentSalary,
          advance,
          deduction,
          netPayable,
          paidAmount,
          dueAmount,
          paymentStatus,
          paymentMethod: 'cash' as PaymentMethod,
          isSavedRecord: false,
        });
      });
    }

    return rows;
  }, [
    employees,
    uniqueSalaryRecords,
    attendanceRecords,
    masterA4Month,
    masterA4Year,
    masterA4Dept,
    masterA4Status,
    masterTotalDays,
    masterDefaultBonus,
    masterA4IncludeDraft,
  ]);

  const masterTotals = useMemo(() => {
    return masterA4Rows.reduce(
      (acc, r) => ({
        workersCount: acc.workersCount + 1,
        totalBasicSalary: acc.totalBasicSalary + r.basicSalary,
        totalPresentDays: acc.totalPresentDays + r.presentDays,
        totalAbsentDays: acc.totalAbsentDays + r.absentDays,
        totalLateDays: acc.totalLateDays + (r.lateDays || 0),
        totalAbsentPenaltyDays: acc.totalAbsentPenaltyDays + (r.absentPenaltyDays || 0),
        totalLatePenaltyDays: acc.totalLatePenaltyDays + (r.latePenaltyDays || 0),
        totalEffectivePresentDays: acc.totalEffectivePresentDays + (r.effectivePresentDays || 0),
        totalOtHours: acc.totalOtHours + r.otHours,
        totalOtPay: acc.totalOtPay + r.otPay,
        totalBonus: acc.totalBonus + r.attendanceBonus,
        totalPresentSalary: acc.totalPresentSalary + r.presentSalary,
        totalAdvance: acc.totalAdvance + r.advance,
        totalDeduction: acc.totalDeduction + r.deduction,
        totalNetPayable: acc.totalNetPayable + r.netPayable,
        totalPaid: acc.totalPaid + r.paidAmount,
        totalDue: acc.totalDue + r.dueAmount,
      }),
      {
        workersCount: 0,
        totalBasicSalary: 0,
        totalPresentDays: 0,
        totalAbsentDays: 0,
        totalLateDays: 0,
        totalAbsentPenaltyDays: 0,
        totalLatePenaltyDays: 0,
        totalEffectivePresentDays: 0,
        totalOtHours: 0,
        totalOtPay: 0,
        totalBonus: 0,
        totalPresentSalary: 0,
        totalAdvance: 0,
        totalDeduction: 0,
        totalNetPayable: 0,
        totalPaid: 0,
        totalDue: 0,
      }
    );
  }, [masterA4Rows]);

  const handlePrintMasterA4Sheet = () => {
    if (!masterA4SheetPrintRef.current) {
      window.print();
      return;
    }
    const result = printElement(
      masterA4SheetPrintRef.current,
      `Master_Payroll_Attendance_${masterA4Month}_${masterA4Year}`,
      'landscape'
    );
    if (result.isTelegram) {
      setTelegramPrintModalTitle(`A4 মাস্টার বেতন ও হাজিরা শিট (${masterA4Month} ${masterA4Year})`);
    }
  };

  const handleCopyEmployee = async (emp: Employee) => {
    const text = `
টেক্স ওয়ার অ্যাপারেলস - কর্মচারীর প্রোফাইল
---------------------------------------
নাম: ${emp.name}
Worker ID: ${emp.workerId}
পদবি: ${emp.designation} (${emp.department || 'সাধারণ'})
স্ট্যাটাস: ${emp.status === 'resigned' ? 'পদত্যাগকৃত (Resigned)' : 'কর্মরত (Active)'}
${emp.resignationDate ? `রিজাইন তারিখ: ${formatDateBn(emp.resignationDate)}\nরিজাইনের কারণ: ${emp.resignationReason || '—'}\n` : ''}
মাসিক বেতন: ${formatMoney(emp.salary)} ৳
প্রতি ঘণ্টা OT: ${formatMoney(emp.otRate)} ৳
যোগদানের তারিখ: ${formatDateBn(emp.joinDate)}
জন্ম তারিখ: ${formatDateBn(emp.birthDate)}
মোবাইল: ${emp.mobile || '—'}
NID: ${emp.nid || '—'}
ঠিকানা: ${emp.address || '—'}
    `.trim();

    try {
      await navigator.clipboard.writeText(text);
      showToast(`"${emp.name}" এর তথ্য কপি হয়েছে`);
    } catch (e) {
      showToast('কপি করতে সমস্যা হয়েছে');
    }
  };

  /* ================= TELEGRAM HANDLERS ================= */
  const handleSaveTelegram = async () => {
    if (!tgSettings.botToken.trim() || !tgSettings.chatId.trim()) {
      showToast('Bot Token এবং Chat ID লিখুন');
      return;
    }
    await saveTelegramSettings(tgSettings);
    showToast('Telegram সেটিংস সংরক্ষিত হয়েছে');
  };

  const handleTestTelegram = async () => {
    if (!tgSettings.botToken.trim() || !tgSettings.chatId.trim()) {
      showToast('আগে Telegram Token ও Chat ID দিন');
      return;
    }
    try {
      setTgTesting(true);
      const url = `https://api.telegram.org/bot${encodeURIComponent(tgSettings.botToken.trim())}/sendMessage`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: tgSettings.chatId.trim(),
          text: `🔔 টেক্স ওয়ার অ্যাপারেলস (TexWare Apparels)\nTelegram Notification টেস্ট সফল হয়েছে।\nসময়: ${new Date().toLocaleString('bn-BD')}`,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        await saveTelegramSettings(tgSettings);
        showToast('✓ Telegram টেস্ট মেসেজ সফলভাবে গেছে');
      } else {
        showToast(`Telegram টেস্ট ব্যর্থ: ${data.description || 'ভুল Token/Chat ID'}`);
      }
    } catch (err: any) {
      showToast('Telegram সংযোগ ব্যর্থ। ইন্টারনেট বা Token পরীক্ষা করুন।');
    } finally {
      setTgTesting(false);
    }
  };

  /* ================= SMS HANDLERS ================= */
  const handleSaveSmsSettings = async () => {
    if (!smsSettings.apiUrl.trim()) {
      showToast('SMS API URL লিখুন');
      return;
    }
    await saveSMSSettings(smsSettings);
    showToast('SMS API সেটিংস সংরক্ষিত হয়েছে');
  };

  const handleSendSingleSMS = async () => {
    const target = employees.find((e) => e.id === singleSmsEmpId);
    if (!target) {
      showToast('অনুগ্রহ করে একজন শ্রমিক নির্বাচন করুন');
      return;
    }
    if (!target.mobile) {
      showToast('এই শ্রমিকের মোবাইল নম্বর রেকর্ড করা নেই');
      return;
    }
    if (!singleSmsMsg.trim()) {
      showToast('মেসেজ লিখুন');
      return;
    }

    try {
      setIsSendingSms(true);
      const normalizedMobile = target.mobile.replace(/\D/g, '');
      const numberFormatted = normalizedMobile.startsWith('880')
        ? normalizedMobile
        : normalizedMobile.startsWith('01')
        ? '88' + normalizedMobile
        : normalizedMobile;

      const params = new URLSearchParams();
      params.set(smsSettings.keyParam || 'api_key', smsSettings.apiKey || '');
      params.set(smsSettings.mobileParam || 'number', numberFormatted);
      params.set(smsSettings.messageParam || 'message', singleSmsMsg.trim());
      if (smsSettings.senderId) {
        params.set(smsSettings.senderParam || 'senderid', smsSettings.senderId);
      }

      let res;
      if (smsSettings.method === 'POST') {
        res = await fetch(smsSettings.apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: params.toString(),
        });
      } else {
        const sep = smsSettings.apiUrl.includes('?') ? '&' : '?';
        res = await fetch(`${smsSettings.apiUrl}${sep}${params.toString()}`);
      }

      const txt = await res.text();
      showToast(`SMS পাঠানোর অনুরোধ সম্পন্ন: ${txt.substring(0, 35)}`);
      setSingleSmsMsg('');
    } catch (err: any) {
      showToast(`SMS পাঠানো যায়নি: ${err.message || 'API Error'}`);
    } finally {
      setIsSendingSms(false);
    }
  };

  const handleSendBulkSMS = async () => {
    if (selectedBulkEmpIds.length === 0) {
      showToast('কমপক্ষে একজন শ্রমিক নির্বাচন করুন');
      return;
    }
    if (!bulkSmsMsg.trim()) {
      showToast('নোটিশ / মেসেজ লিখুন');
      return;
    }
    if (!confirm(`${selectedBulkEmpIds.length} জন শ্রমিককে এই SMS পাঠানো হবে। চালিয়ে যাবেন?`)) {
      return;
    }

    setIsSendingSms(true);
    let success = 0;
    let failed = 0;

    for (const empId of selectedBulkEmpIds) {
      const emp = employees.find((e) => e.id === empId);
      if (!emp || !emp.mobile) {
        failed++;
        continue;
      }
      try {
        const normalized = emp.mobile.replace(/\D/g, '');
        const numberFormatted = normalized.startsWith('880')
          ? normalized
          : normalized.startsWith('01')
          ? '88' + normalized
          : normalized;

        const params = new URLSearchParams();
        params.set(smsSettings.keyParam || 'api_key', smsSettings.apiKey || '');
        params.set(smsSettings.mobileParam || 'number', numberFormatted);
        params.set(smsSettings.messageParam || 'message', bulkSmsMsg.trim());
        if (smsSettings.senderId) {
          params.set(smsSettings.senderParam || 'senderid', smsSettings.senderId);
        }

        if (smsSettings.method === 'POST') {
          await fetch(smsSettings.apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: params.toString(),
          });
        } else {
          const sep = smsSettings.apiUrl.includes('?') ? '&' : '?';
          await fetch(`${smsSettings.apiUrl}${sep}${params.toString()}`);
        }
        success++;
        await new Promise((r) => setTimeout(r, 250));
      } catch (e) {
        failed++;
      }
    }

    setIsSendingSms(false);
    showToast(`Bulk SMS ফলাফল: সফল ${success}, ব্যর্থ ${failed}`);
  };

  /* ================= PASSWORD CHANGE HANDLER ================= */
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    const saved = localStorage.getItem('texware_admin_password');
    if (oldPassword !== saved) {
      showToast('বর্তমান পাসওয়ার্ড সঠিক নয়');
      return;
    }
    if (newPassword.length < 6) {
      showToast('নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast('নতুন উভয় পাসওয়ার্ড মিলছে না');
      return;
    }
    localStorage.setItem('texware_admin_password', newPassword);
    setOldPassword('');
    setNewPassword('');
    setConfirmPassword('');
    showToast('Admin পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে');
  };

  /* ================= 4 DEDICATED SECTIONS & REINSTATE ================= */
  const activeEmployees = useMemo(() => employees.filter((e) => e.status === 'active'), [employees]);
  const resignedEmployees = useMemo(() => employees.filter((e) => e.status === 'resigned'), [employees]);
  const suspendedEmployees = useMemo(() => employees.filter((e) => e.status === 'suspended'), [employees]);
  const terminatedEmployees = useMemo(() => employees.filter((e) => e.status === 'terminated'), [employees]);

  const handleReinstateEmployee = async (emp: Employee) => {
    try {
      await updateResignationStatus(emp.id, {
        status: 'active',
        statusChangedAt: Date.now(),
        resignationDate: '',
        resignationReason: '',
        noticeServed: 'no',
        suspensionDate: '',
        suspensionReason: '',
        suspensionDuration: '',
        terminationDate: '',
        terminationReason: '',
        terminationMemo: '',
        clearanceDone: false,
        finalSettlementPaid: false,
        finalSettlementNote: '',
      });
      showToast(`✓ "${emp.name}" কে পুনরায় সফলভাবে সক্রিয় (Active) করা হয়েছে`);
    } catch (e) {
      showToast('স্ট্যাটাস সক্রিয় করা সম্ভব হয়নি');
    }
  };

  /* ================= FILTERED EMPLOYEES ================= */
  const filteredEmployees = employees.filter((emp) => {
    if (statusFilter === 'active' && emp.status !== 'active') return false;
    if (statusFilter === 'resigned' && emp.status !== 'resigned') return false;
    if (statusFilter === 'suspended' && (emp.status === 'active' || emp.status === 'resigned')) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      emp.name.toLowerCase().includes(q) ||
      emp.workerId.toLowerCase().includes(q) ||
      (emp.mobile && emp.mobile.includes(q)) ||
      emp.designation.toLowerCase().includes(q) ||
      (emp.department && emp.department.toLowerCase().includes(q))
    );
  });

  const activeWorkingEmployees = employees.filter((e) => e.status === 'active');
  const selectedDetailEmp =
    (detailSelectedId && activeWorkingEmployees.find((e) => e.id === detailSelectedId)) ||
    activeWorkingEmployees[0] ||
    employees.find((e) => e.id === detailSelectedId) ||
    employees[0] ||
    null;

  /* ================= LOGIN & FIRST TIME SCREENS ================= */
  if (!isLoggedIn) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 max-w-md mx-auto text-center my-4">
        <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mx-auto mb-3">
          <Lock className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-black text-slate-900">Admin Control Panel</h2>
        <p className="text-xs text-slate-500 mb-5">
          টেক্স ওয়ার অ্যাপারেলস - শুধুমাত্র অনুমোদিত এইচআর ও এডমিনদের জন্য
        </p>

        {!hasPasswordSet ? (
          <form onSubmit={handleFirstTimeSetup} className="space-y-3.5 text-left">
            <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl text-xs text-blue-900 leading-relaxed">
              <b>🔐 প্রথমবার Admin পাসওয়ার্ড সেট করুন</b>
              <br />
              নিরাপত্তার স্বার্থে আপনার পছন্দমতো একটি শক্তিশালী পাসওয়ার্ড নির্ধারণ করুন।
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                নতুন Admin পাসওয়ার্ড *
              </label>
              <input
                type="password"
                required
                value={firstPass}
                onChange={(e) => setFirstPass(e.target.value)}
                placeholder="কমপক্ষে ৬ অক্ষর বা সংখ্যা"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পাসওয়ার্ড নিশ্চিত করুন *
              </label>
              <input
                type="password"
                required
                value={firstPassConfirm}
                onChange={(e) => setFirstPassConfirm(e.target.value)}
                placeholder="পাসওয়ার্ডটি আবার লিখুন"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
            >
              পাসওয়ার্ড সেট করে প্রবেশ করুন
            </button>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-2 text-[10px] text-slate-400 uppercase">অথবা</span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <button
              type="button"
              onClick={handleQuickSetupDefault}
              className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-300 transition cursor-pointer"
            >
              ডিফল্ট পাসওয়ার্ড (123456) দিয়ে প্রবেশ করুন
            </button>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-3.5 text-left">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Admin Password *
              </label>
              <div className="relative">
                <input
                  type={showLoginPass ? 'text' : 'password'}
                  required
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  placeholder="আপনার Admin পাসওয়ার্ড দিন"
                  className="w-full py-2.5 pl-3 pr-10 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPass(!showLoginPass)}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                >
                  {showLoginPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
            >
              লগইন করুন
            </button>
          </form>
        )}
      </div>
    );
  }

  /* ================= ADMIN LOGGED IN DASHBOARD ================= */
  return (
    <div className="space-y-4">
      {/* Sub Menu Tabs Grid: Single clean row, numbered 1 to 8 */}
      <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-200">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 xl:grid-cols-10 gap-2">
          {/* ১. কর্মী ব্যবস্থাপনা */}
          <button
            type="button"
            id="tabAdminWorkers"
            onClick={() => handleTabChange('list')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'list' || activeTab === 'resignation'
                ? 'bg-slate-900 text-white shadow-md ring-2 ring-slate-800/40 shadow-slate-900/30'
                : 'bg-slate-50 text-slate-800 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Users className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'list' || activeTab === 'resignation' ? 'text-blue-300' : 'text-slate-600'}`} />
            <span className="truncate">১. কর্মী তালিকা</span>
          </button>

          {/* ২. হাজিরা ও টাইম */}
          <button
            type="button"
            id="tabAdminAttendance"
            onClick={() => handleTabChange('attendance')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'attendance'
                ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-500/30 shadow-indigo-500/25'
                : 'bg-indigo-50 text-indigo-900 hover:bg-indigo-100 border border-indigo-200'
            }`}
          >
            <Clock className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'attendance' ? 'text-white' : 'text-indigo-600'}`} />
            <span className="truncate">২. হাজিরা</span>
          </button>

          {/* ৩. বেতন খাতা */}
          <button
            type="button"
            id="tabAdminSalaries"
            onClick={() => handleTabChange('salaries')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'salaries'
                ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-500/30 shadow-emerald-500/25'
                : 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <Receipt className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'salaries' ? 'text-white' : 'text-emerald-600'}`} />
            <span className="truncate">৩. বেতন খাতা</span>
          </button>

          {/* ৪. নতুন কর্মী নিবন্ধন */}
          <button
            type="button"
            id="tabAdminNewWorker"
            onClick={() => {
              resetForm();
              handleTabChange('form');
            }}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'form'
                ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-500/30 shadow-blue-500/25'
                : 'bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200'
            }`}
          >
            <UserPlus className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'form' ? 'text-white' : 'text-blue-600'}`} />
            <span className="truncate">{editId ? '৪. এডিট কর্মী' : '৪. নতুন কর্মী'}</span>
          </button>

          {/* ৫. Telegram Bot */}
          <button
            type="button"
            id="tabAdminTelegram"
            onClick={() => handleTabChange('telegram')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'telegram'
                ? 'bg-sky-600 text-white shadow-md ring-2 ring-sky-500/30 shadow-sky-500/25'
                : 'bg-sky-50 text-sky-900 hover:bg-sky-100 border border-sky-200'
            }`}
          >
            <Send className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'telegram' ? 'text-white' : 'text-sky-600'}`} />
            <span className="truncate">৫. Telegram Bot</span>
          </button>

          {/* ৬. Auto SMS */}
          <button
            type="button"
            id="tabAdminSms"
            onClick={() => handleTabChange('sms')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'sms'
                ? 'bg-purple-600 text-white shadow-md ring-2 ring-purple-500/30 shadow-purple-500/25'
                : 'bg-purple-50 text-purple-900 hover:bg-purple-100 border border-purple-200'
            }`}
          >
            <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'sms' ? 'text-white' : 'text-purple-600'}`} />
            <span className="truncate">৬. Auto SMS</span>
          </button>

          {/* ৭. পাসওয়ার্ড */}
          <button
            type="button"
            id="tabAdminPassword"
            onClick={() => handleTabChange('password')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'password'
                ? 'bg-amber-600 text-white shadow-md ring-2 ring-amber-500/30 shadow-amber-500/25'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            <KeyRound className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'password' ? 'text-white' : 'text-amber-600'}`} />
            <span className="truncate">৭. পাসওয়ার্ড</span>
          </button>

          {/* ৮. প্রোফাইল ও প্রিন্ট */}
          <button
            type="button"
            id="tabAdminDetails"
            onClick={() => handleTabChange('details')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'details'
                ? 'bg-blue-700 text-white shadow-md ring-2 ring-blue-600/30 shadow-blue-700/25'
                : 'bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200'
            }`}
          >
            <IdCard className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'details' ? 'text-white' : 'text-blue-700'}`} />
            <span className="truncate">৮. প্রোফাইল</span>
          </button>

          {/* ৯. কারখানা তথ্য ও চুক্তি সেটিংস */}
          <button
            type="button"
            id="tabAdminFactory"
            onClick={() => handleTabChange('factory')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs ${
              activeTab === 'factory'
                ? 'bg-teal-700 text-white shadow-md ring-2 ring-teal-600/30 shadow-teal-700/25'
                : 'bg-teal-50 text-teal-900 hover:bg-teal-100 border border-teal-200'
            }`}
          >
            <Building2 className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'factory' ? 'text-white' : 'text-teal-700'}`} />
            <span className="truncate">৯. কারখানা তথ্য</span>
          </button>

          {/* ১০. আবেদন ফরম / পেন্ডিং আবেদন */}
          <button
            type="button"
            id="tabAdminApplications"
            onClick={() => handleTabChange('applications')}
            className={`py-2.5 px-2 rounded-xl font-black flex items-center justify-center gap-1.5 transition cursor-pointer text-xs relative ${
              activeTab === 'applications'
                ? 'bg-rose-600 text-white shadow-md ring-2 ring-rose-500/30 shadow-rose-500/25'
                : 'bg-rose-50 text-rose-900 hover:bg-rose-100 border border-rose-200'
            }`}
          >
            <FileText className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'applications' ? 'text-white' : 'text-rose-600'}`} />
            <span className="truncate">১০. আবেদন ফরম</span>
            {pendingAppsCount > 0 && (
              <span className="inline-flex items-center justify-center px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 animate-pulse ml-0.5 shadow-xs">
                {pendingAppsCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* ================= TAB 1 & 2: 4-SECTION EMPLOYEE MANAGEMENT HUB ================= */}
      {(activeTab === 'list' || activeTab === 'resignation') && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          {/* 4 Dedicated Sections Navigation Bar */}
          <div className="flex flex-col gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
                <Users className="w-4 h-4 text-blue-600" />
                <span>শ্রমিক ব্যবস্থাপনা — ৪টি সুনির্দিষ্ট সেকশন</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold">
                  মোট শ্রমিক: {employees.length} জন
                </span>
              </div>

              {/* Quick Worker Cancellation & Status Picker and Login list button */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowAllWorkersLoginModal(true)}
                  className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition active:scale-95 shadow-2xs cursor-pointer"
                  title="সকল শ্রমিকের ব্যক্তিগত প্রোফাইল লিংক ও পাসওয়ার্ড তালিকা দেখুন"
                >
                  <Key className="w-3.5 h-3.5 text-indigo-200" />
                  <span>লগইন লিংক ও পাসওয়ার্ড তালিকা</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setNoticeTargetEmp(null);
                    setNoticeModalOpen(true);
                  }}
                  className="py-1.5 px-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition active:scale-95 shadow-2xs cursor-pointer"
                  title="শ্রমিকদের এক সাথে বা আলাদা আলাদা নোটিশ প্রদান ও নোটিশ বোর্ড পরিচালনা"
                >
                  <Bell className="w-3.5 h-3.5 text-purple-200" />
                  <span>নোটিশ পাঠান (নোটিশ বোর্ড)</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (
                      window.confirm(
                        'আপনি কি নিশ্চিত যে কারখানার সকল ডেমো কর্মী মুছে ফেলতে চান? এতে কারখানা সম্পূর্ণ ফ্রেশ হয়ে যাবে এবং শুধুমাত্র আপনার নিজস্ব যুক্ত করা প্রকৃত কর্মীদের ডাটা ও হিসাব নিখুঁতভাবে সংরক্ষিত থাকবে।'
                      )
                    ) {
                      const count = await clearAllDemoEmployees();
                      if (count > 0) {
                        showToast(`✓ সফল হয়েছে: ${count} জন ডেমো কর্মী সম্পূর্ণভাবে মুছে ফেলা হয়েছে!`);
                      } else {
                        showToast('কারখানায় কোনো ডেমো কর্মী অবশিষ্ট নেই, সবই বাস্তব ও সক্রিয় কর্মী।');
                      }
                    }
                  }}
                  className="py-1.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-2xs cursor-pointer"
                  title="কারখানার ডেমো কর্মী মুছে ফেলুন যাতে কোনো ডেমো ডাটা না থাকে"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>ডেমো কর্মী মুছুন</span>
                </button>

                <select
                  aria-label="শ্রমিকের স্ট্যাটাস বা সেকশন নির্বাচন করুন"
                  className="py-1.5 px-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 cursor-pointer focus:ring-2 focus:ring-blue-500"
                  onChange={(e) => {
                    const target = employees.find((emp) => emp.id === e.target.value);
                    if (target) {
                      onOpenResignationModal(target);
                      e.target.value = '';
                    }
                  }}
                  defaultValue=""
                >
                  <option value="" disabled>
                    ⚡ যেকোনো শ্রমিকের স্ট্যাটাস / বাতিল করুন...
                  </option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.workerId}) — [{
                        emp.status === 'active'
                          ? 'কর্মরত'
                          : emp.status === 'resigned'
                          ? 'রিজাইনকৃত'
                          : emp.status === 'suspended'
                          ? 'স্থগিত'
                          : 'বরখাস্ত'
                      }]
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 4 Dedicated Section Tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setEmployeeSectionTab('active')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                  employeeSectionTab === 'active'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-emerald-50/70 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>১. কর্মরত / সক্রিয় ({activeEmployees.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setEmployeeSectionTab('resigned')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                  employeeSectionTab === 'resigned'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                    : 'bg-rose-50/70 text-rose-800 border-rose-200 hover:bg-rose-100'
                }`}
              >
                <UserX className="w-4 h-4" />
                <span>২. পদত্যাগ / রিজাইন ({resignedEmployees.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setEmployeeSectionTab('suspended')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                  employeeSectionTab === 'suspended'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                    : 'bg-amber-50/70 text-amber-800 border-amber-200 hover:bg-amber-100'
                }`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>৩. সাময়িক স্থগিত ({suspendedEmployees.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setEmployeeSectionTab('terminated')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                  employeeSectionTab === 'terminated'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200'
                }`}
              >
                <RotateCcw className="w-4 h-4" />
                <span>৪. বরখাস্ত / অব্যাহতি ({terminatedEmployees.length})</span>
              </button>
            </div>
          </div>

          {/* Search bar & Section Description Banner */}
          <div className="space-y-2.5">
            {employeeSectionTab === 'active' && (
              <div className="p-3 bg-emerald-50/80 rounded-xl border border-emerald-200 text-xs text-emerald-950 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-black">কর্মরত ও সক্রিয় শ্রমিক সেকশন:</span>{' '}
                    <span>কারখানায় বর্তমানে নিয়মিত কর্মরত শ্রমিক তালিকা। এখান থেকে যেকোনো কর্মীকে বাতিল বা স্ট্যাটাস পরিবর্তন করতে পারেন।</span>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-200/80 text-emerald-900 self-start sm:self-auto">
                  মোট সক্রিয়: {activeEmployees.length} জন
                </span>
              </div>
            )}

            {employeeSectionTab === 'resigned' && (
              <div className="p-3 bg-rose-50/80 rounded-xl border border-rose-200 text-xs text-rose-950 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2">
                  <UserX className="w-4 h-4 text-rose-600 shrink-0" />
                  <div>
                    <span className="font-black">পদত্যাগ / রিজাইনকৃত শ্রমিক সেকশন:</span>{' '}
                    <span>স্বেচ্ছায় চাকরি ছেড়ে দেওয়া শ্রমিকদের তালিকা। যেকোনো শ্রমিকের ১-ক্লিকে তথ্যাবলিসহ পদত্যাগপত্র ফরম প্রিন্ট করতে "রিজাইন ফরম" বাটনে চাপ দিন।</span>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-200/80 text-rose-900 self-start sm:self-auto">
                  মোট রিজাইনকৃত: {resignedEmployees.length} জন
                </span>
              </div>
            )}

            {employeeSectionTab === 'suspended' && (
              <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-amber-950 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <span className="font-black">সাময়িক স্থগিতকৃত শ্রমিক সেকশন:</span>{' '}
                    <span>শৃঙ্খলাভঙ্গ বা প্রশাসনিক কারণে সাময়িক স্থগিতাদেশপ্রাপ্ত শ্রমিকদের তালিকা। যেকোনো কর্মীর তথ্যাবলিসহ নোটিশ প্রিন্ট করতে "স্থগিত নোটিশ" বাটনে চাপ দিন।</span>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-200/80 text-amber-900 self-start sm:self-auto">
                  মোট স্থগিত: {suspendedEmployees.length} জন
                </span>
              </div>
            )}

            {employeeSectionTab === 'terminated' && (
              <div className="p-3 bg-slate-100 rounded-xl border border-slate-300 text-xs text-slate-900 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-slate-700 shrink-0" />
                  <div>
                    <span className="font-black">অব্যাহতি ও বরখাস্তকৃত শ্রমিক সেকশন:</span>{' '}
                    <span>শৃঙ্খলাভঙ্গ, দীর্ঘ অনুপস্থিতি বা ছাঁটাইয়ের দায়ে বরখাস্তকৃত শ্রমিকদের তালিকা। যেকোনো কর্মীর তথ্যাবলিসহ আদেশ প্রিন্ট করতে "অব্যাহতি পত্র" বাটনে চাপ দিন।</span>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-300 text-slate-900 self-start sm:self-auto">
                  মোট বরখাস্ত: {terminatedEmployees.length} জন
                </span>
              </div>
            )}

            {/* Live Search Bar */}
            <div className="relative">
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="এই সেকশনে নাম / Worker ID / পদবি / মোবাইল / সেকশন দিয়ে খুঁজুন..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-500 focus:bg-white"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          {/* Cards List for Current Section */}
          <div className="space-y-3">
            {(() => {
              const currentList =
                employeeSectionTab === 'active'
                  ? activeEmployees
                  : employeeSectionTab === 'resigned'
                  ? resignedEmployees
                  : employeeSectionTab === 'suspended'
                  ? suspendedEmployees
                  : terminatedEmployees;

              const filteredCurrentList = currentList.filter((emp) => {
                if (!searchQuery.trim()) return true;
                const q = searchQuery.toLowerCase();
                return (
                  emp.name.toLowerCase().includes(q) ||
                  emp.workerId.toLowerCase().includes(q) ||
                  (emp.mobile && emp.mobile.includes(q)) ||
                  emp.designation.toLowerCase().includes(q) ||
                  (emp.department && emp.department.toLowerCase().includes(q)) ||
                  (emp.resignationReason && emp.resignationReason.toLowerCase().includes(q)) ||
                  (emp.suspensionReason && emp.suspensionReason.toLowerCase().includes(q)) ||
                  (emp.terminationReason && emp.terminationReason.toLowerCase().includes(q))
                );
              });

              if (filteredCurrentList.length === 0) {
                return (
                  <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-xl border border-dashed border-slate-200 space-y-1">
                    <p className="font-bold text-slate-600">
                      {employeeSectionTab === 'active'
                        ? 'কোনো সক্রিয় কর্মচারী পাওয়া যায়নি'
                        : employeeSectionTab === 'resigned'
                        ? 'বর্তমানে কোনো পদত্যাগকৃত কর্মচারী নেই'
                        : employeeSectionTab === 'suspended'
                        ? 'বর্তমানে কোনো সাময়িক স্থগিতকৃত কর্মচারী নেই'
                        : 'বর্তমানে কোনো বরখাস্তকৃত কর্মচারী নেই'}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      উপরে থাকা "যেকোনো শ্রমিকের স্ট্যাটাস / বাতিল করুন" ড্রপডাউন থেকে কর্মী নির্বাচন করে এই সেকশনে যুক্ত করতে পারেন।
                    </p>
                  </div>
                );
              }

              return filteredCurrentList.map((emp) => {
                const badge = getStatusBadge(emp.status);
                return (
                  <div
                    key={emp.id}
                    className={`p-3.5 rounded-xl border shadow-2xs transition ${
                      emp.status === 'active'
                        ? 'bg-white border-slate-200 hover:border-slate-300'
                        : emp.status === 'resigned'
                        ? 'bg-rose-50/20 border-rose-200 hover:border-rose-300'
                        : emp.status === 'suspended'
                        ? 'bg-amber-50/20 border-amber-200 hover:border-amber-300'
                        : 'bg-slate-50/40 border-slate-300 hover:border-slate-400'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {emp.photoUrl ? (
                        <img
                          src={emp.photoUrl}
                          alt={emp.name}
                          className="w-12 h-12 rounded-full object-cover border-2 border-slate-100 shrink-0"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-base shrink-0 border ${
                          emp.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                            : emp.status === 'resigned'
                            ? 'bg-rose-100 text-rose-800 border-rose-200'
                            : emp.status === 'suspended'
                            ? 'bg-amber-100 text-amber-800 border-amber-200'
                            : 'bg-slate-200 text-slate-800 border-slate-300'
                        }`}>
                          {emp.name.charAt(0)}
                        </div>
                      )}

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900">{emp.name}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.bg}`}>
                              {badge.label}
                            </span>
                            {emp.isBlocked && (
                              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-red-100 text-red-800 border border-red-300 flex items-center gap-1 shadow-2xs animate-pulse">
                                <Ban className="w-3 h-3 text-red-600" />
                                <span>ব্লক করা</span>
                              </span>
                            )}
                          </div>

                          <span className="text-[11px] font-bold text-blue-700">
                            মূল বেতন: {formatMoney(emp.salary)} ৳ (OT: {formatMoney(emp.otRate)} ৳)
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2 flex-wrap">
                          <span>
                            Worker ID: <b className="text-slate-800">{emp.workerId}</b>
                          </span>
                          <span>•</span>
                          <span>
                            পদবি: <b className="text-slate-800">{emp.designation}</b>
                          </span>
                          {emp.department && (
                            <>
                              <span>•</span>
                              <span>সেকশন: {emp.department}</span>
                            </>
                          )}
                          <span>•</span>
                          <span>মোবাইল: {emp.mobile || 'নেই'}</span>
                        </div>

                        {/* RESIGNED SPECIFIC METADATA */}
                        {emp.status === 'resigned' && (
                          <div className="mt-2 p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-[11px] space-y-1">
                            <div className="flex flex-wrap items-center justify-between gap-1">
                              <span>
                                <b>পদত্যাগ তারিখ:</b> {formatDateBn(emp.resignationDate)} |{' '}
                                <b>নোটিশ:</b>{' '}
                                {emp.noticeServed === 'yes'
                                  ? 'সম্পূর্ণ দিয়েছে'
                                  : emp.noticeServed === 'partial'
                                  ? 'আংশিক'
                                  : 'দেয়নি'}
                              </span>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {emp.finalSettlementPaid ? (
                                  <b className="text-emerald-700">[✓ চূড়ান্ত নিষ্পত্তি সম্পন্ন]</b>
                                ) : (
                                  <b className="text-amber-700">[⏳ চূড়ান্ত দেনা-পাওনা বাকি]</b>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setResignationLetterModalEmp(emp);
                                    onOpenResignationLetter?.(emp);
                                  }}
                                  className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-700 text-white font-black text-[10.5px] flex items-center gap-1 cursor-pointer transition shadow-2xs active:scale-95"
                                  title="১-ক্লিকে এই শ্রমিকের তথ্যাবলিসহ পদত্যাগ ফরম প্রিন্ট করুন"
                                >
                                  <Printer className="w-3 h-3" />
                                  <span>১-ক্লিক রিজাইন ফরম প্রিন্ট</span>
                                </button>
                              </div>
                            </div>
                            <div>
                              <b>পদত্যাগের কারণ:</b> {emp.resignationReason || 'কারণ উল্লেখ নেই'}
                            </div>
                            {emp.finalSettlementNote && (
                              <div className="text-slate-600 italic">
                                নোট: {emp.finalSettlementNote}
                              </div>
                            )}
                          </div>
                        )}

                        {/* SUSPENDED SPECIFIC METADATA */}
                        {emp.status === 'suspended' && (
                          <div className="mt-2 p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-950 text-[11px] space-y-1">
                            <div className="flex flex-wrap items-center justify-between gap-1">
                              <span>
                                <b>স্থগিতাদেশ তারিখ:</b> {formatDateBn(emp.suspensionDate || emp.resignationDate)} |{' '}
                                <b>মেয়াদ/পর্যালোচনা:</b> {emp.suspensionDuration || '৭ কার্যদিবস'}
                              </span>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-amber-800">
                                  [সাময়িক তদন্তাধীন]
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSuspensionNoticeModalEmp(emp);
                                    onOpenSuspensionNotice?.(emp);
                                  }}
                                  className="px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-700 text-white font-black text-[10.5px] flex items-center gap-1 cursor-pointer transition shadow-2xs active:scale-95"
                                  title="১-ক্লিকে এই শ্রমিকের তথ্যাবলিসহ সাময়িক স্থগিতাদেশ নোটিশ প্রিন্ট করুন"
                                >
                                  <Printer className="w-3 h-3" />
                                  <span>১-ক্লিক স্থগিত নোটিশ প্রিন্ট</span>
                                </button>
                              </div>
                            </div>
                            <div>
                              <b>স্থগিতের কারণ:</b> {emp.suspensionReason || emp.resignationReason || 'শৃঙ্খলাভঙ্গ সংক্রান্ত অভিযোগ'}
                            </div>
                            {emp.finalSettlementNote && (
                              <div className="text-slate-600 italic">
                                তদন্ত নোট: {emp.finalSettlementNote}
                              </div>
                            )}
                          </div>
                        )}

                        {/* TERMINATED SPECIFIC METADATA */}
                        {emp.status === 'terminated' && (
                          <div className="mt-2 p-2 rounded-lg bg-slate-100 border border-slate-300 text-slate-900 text-[11px] space-y-1">
                            <div className="flex flex-wrap items-center justify-between gap-1">
                              <span>
                                <b>বরখাস্ত কার্যকর তারিখ:</b> {formatDateBn(emp.terminationDate || emp.resignationDate)}
                                {emp.terminationMemo ? ` | মেমো: ${emp.terminationMemo}` : ''}
                              </span>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span>
                                  {emp.finalSettlementPaid ? (
                                    <b className="text-emerald-700">[✓ ক্লিয়ারেন্স ও পাওনা পরিশোধিত]</b>
                                  ) : (
                                    <b className="text-rose-700">[⏳ দেনা-পাওনা বকেয়া]</b>
                                  )}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setTerminationNoticeModalEmp(emp);
                                    onOpenTerminationNotice?.(emp);
                                  }}
                                  className="px-2 py-0.5 rounded bg-slate-900 hover:bg-black text-white font-black text-[10.5px] flex items-center gap-1 cursor-pointer transition shadow-2xs active:scale-95"
                                  title="১-ক্লিকে এই শ্রমিকের তথ্যাবলিসহ চাকরি হতে বরখাস্ত ও অব্যাহতি পত্র প্রিন্ট করুন"
                                >
                                  <Printer className="w-3 h-3" />
                                  <span>১-ক্লিক অব্যাহতি পত্র প্রিন্ট</span>
                                </button>
                              </div>
                            </div>
                            <div>
                              <b>বরখাস্তের সুনির্দিষ্ট কারণ:</b> {emp.terminationReason || emp.resignationReason || 'শৃঙ্খলাভঙ্গ ও অসদাচরণ'}
                            </div>
                            {emp.finalSettlementNote && (
                              <div className="text-slate-600 italic">
                                আদেশ নোট: {emp.finalSettlementNote}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Bar */}
                    <div className="flex items-center justify-end gap-1.5 mt-3 pt-2.5 border-t border-slate-100 flex-wrap text-xs">
                      {/* Reinstate Action for non-active employees */}
                      {emp.status !== 'active' && (
                        <button
                          type="button"
                          onClick={() => handleReinstateEmployee(emp)}
                          className="py-1.5 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 text-[11px] transition shadow-2xs active:scale-95 cursor-pointer"
                          title="এই কর্মীকে পুনরায় সক্রিয় (Active) করুন"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>পুনরায় সক্রিয় (Active) করুন</span>
                        </button>
                      )}

                      {/* Status Edit / Cancel modal trigger */}
                      <button
                        type="button"
                        onClick={() => onOpenResignationModal(emp)}
                        className={`py-1.5 px-2 rounded-lg font-bold flex items-center gap-1 text-[11px] border transition cursor-pointer active:scale-95 ${
                          emp.status === 'active'
                            ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-300'
                        }`}
                        title="স্ট্যাটাস পরিবর্তন বা বাতিল করুন"
                      >
                        {emp.status === 'active' ? <UserX className="w-3.5 h-3.5" /> : <RotateCcw className="w-3.5 h-3.5" />}
                        <span>{emp.status === 'active' ? 'বাতিল / স্ট্যাটাস পরিবর্তন' : 'স্ট্যাটাস সম্পাদন'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setDetailSelectedId(emp.id);
                          try {
                            localStorage.setItem('texware_selected_detail_id', emp.id);
                          } catch {}
                          setActiveTab('details');
                        }}
                        className="py-1.5 px-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold flex items-center gap-1 text-[11px] transition cursor-pointer"
                      >
                        <IdCard className="w-3.5 h-3.5" />
                        <span>প্রোফাইল</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setCredentialModalEmp(emp)}
                        className="py-1.5 px-2.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-950 font-bold flex items-center gap-1 text-[11px] border border-indigo-200 transition cursor-pointer active:scale-95 shadow-2xs"
                        title="এই শ্রমিকের ব্যক্তিগত প্রোফাইল লিংক ও পাসওয়ার্ড নিয়ন্ত্রণ করুন"
                      >
                        <Key className="w-3.5 h-3.5 text-indigo-600" />
                        <span>লগইন লিংক ও পাসওয়ার্ড</span>
                      </button>

                      {/* Direct Block / Unblock Profile button */}
                      <button
                        type="button"
                        onClick={() => setCredentialModalEmp(emp)}
                        className={`py-1.5 px-2.5 rounded-lg font-bold flex items-center gap-1 text-[11px] border transition cursor-pointer active:scale-95 shadow-2xs ${
                          emp.isBlocked
                            ? 'bg-rose-100 hover:bg-rose-200 text-rose-950 border-rose-300 animate-pulse'
                            : 'bg-slate-50 hover:bg-rose-50 text-slate-700 hover:text-rose-800 border-slate-200'
                        }`}
                        title={emp.isBlocked ? 'শ্রমিকের প্রোফাইল আনব্লক করুন' : 'শ্রমিকের প্রোফাইল ব্লক করুন (সুনির্দিষ্ট কারণসহ)'}
                      >
                        <Ban className={`w-3.5 h-3.5 ${emp.isBlocked ? 'text-rose-700' : 'text-slate-500'}`} />
                        <span>{emp.isBlocked ? 'ব্লক করা (আনব্লক)' : 'ব্লক / আনব্লক'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setContractModalEmp(emp)}
                        className="py-1.5 px-2.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold flex items-center gap-1 text-[11px] border border-amber-300 transition cursor-pointer active:scale-95 shadow-2xs"
                        title="শ্রমিক নিয়োগ চুক্তিপত্র A4 প্রিন্ট করুন"
                      >
                        <FileText className="w-3.5 h-3.5 text-amber-700" />
                        <span>চুক্তিপত্র</span>
                      </button>

                      {emp.status === 'resigned' && (
                        <button
                          type="button"
                          onClick={() => {
                            setResignationLetterModalEmp(emp);
                            onOpenResignationLetter?.(emp);
                          }}
                          className="py-1.5 px-2.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-950 font-bold flex items-center gap-1 text-[11px] border border-rose-300 transition cursor-pointer active:scale-95 shadow-2xs"
                          title="১-ক্লিকে এই কর্মীর তথ্যাবলিসহ পদত্যাগ ফরম প্রিন্ট করুন"
                        >
                          <Printer className="w-3.5 h-3.5 text-rose-700" />
                          <span>রিজাইন ফরম</span>
                        </button>
                      )}

                      {emp.status === 'suspended' && (
                        <button
                          type="button"
                          onClick={() => {
                            setSuspensionNoticeModalEmp(emp);
                            onOpenSuspensionNotice?.(emp);
                          }}
                          className="py-1.5 px-2.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-950 font-bold flex items-center gap-1 text-[11px] border border-amber-300 transition cursor-pointer active:scale-95 shadow-2xs"
                          title="১-ক্লিকে এই কর্মীর তথ্যাবলিসহ সাময়িক স্থগিতাদেশ নোটিশ প্রিন্ট করুন"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-700" />
                          <span>স্থগিত নোটিশ</span>
                        </button>
                      )}

                      {emp.status === 'terminated' && (
                        <button
                          type="button"
                          onClick={() => {
                            setTerminationNoticeModalEmp(emp);
                            onOpenTerminationNotice?.(emp);
                          }}
                          className="py-1.5 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold flex items-center gap-1 text-[11px] border border-slate-300 transition cursor-pointer active:scale-95 shadow-2xs"
                          title="১-ক্লিকে এই কর্মীর তথ্যাবলিসহ চাকরি হতে বরখাস্ত ও অব্যাহতি পত্র প্রিন্ট করুন"
                        >
                          <Printer className="w-3.5 h-3.5 text-slate-700" />
                          <span>অব্যাহতি পত্র</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleEditEmployee(emp)}
                        className="py-1.5 px-2 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 font-semibold flex items-center gap-1 text-[11px] transition cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>এডিট</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCopyEmployee(emp)}
                        className="py-1.5 px-2 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 font-semibold flex items-center gap-1 text-[11px] transition cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>কপি</span>
                      </button>

                      <button
                        id={`btnDeleteEmp_${emp.id}`}
                        type="button"
                        onClick={() => handleDeleteEmployee(emp)}
                        className="py-1.5 px-2 rounded-lg bg-red-50 text-red-700 hover:bg-red-100 font-bold flex items-center gap-1 text-[11px] border border-red-200 transition cursor-pointer active:scale-95 hover:border-red-300"
                        title="কর্মচারী মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                        <span>ডিলিট</span>
                      </button>
                    </div>
                  </div>
                );
              });
            })()}
          </div>
        </div>
      )}

      {/* ================= TAB: ATTENDANCE & IN/OUT TIME (হাজিরা ও টাইম) ================= */}
      {activeTab === 'attendance' && (
        <AttendanceHub
          employees={employees}
          attendanceRecords={attendanceRecords}
          showToast={showToast}
          onViewEmployeeProfile={(empId) => {
            setDetailSelectedId(empId);
            try {
              localStorage.setItem('texware_selected_detail_id', empId);
            } catch {}
            handleTabChange('details');
          }}
        />
      )}

      {/* ================= TAB: MONTHLY SALARY RECORDS (বেতন খাতা) ================= */}
      {activeTab === 'salaries' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
                <Receipt className="w-4 h-4 text-emerald-600" />
                <span>মাসিক বেতন খাতা ও পরিশোধ ইতিহাস</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {salaryRecords.length} টি রেকর্ড
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                কোন মাসে কাকে কত বেতন ও ক্যাশ/বিকাশ দেওয়া হয়েছে তার বিস্তারিত খাতা
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (salaryMonthFilter !== 'all') {
                    setMasterA4Month(salaryMonthFilter);
                  } else if (uniqueSalaryRecords.length > 0 && (!masterA4Month || masterA4Month === 'all')) {
                    setMasterA4Month(uniqueSalaryRecords[0]?.month || 'সেপ্টেম্বর');
                  }
                  if (salaryYearFilter !== 'all') {
                    setMasterA4Year(Number(salaryYearFilter));
                  }
                  setShowMasterA4Modal(true);
                }}
                className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
                title="সকল শ্রমিকের উপস্থিতি, অনুপস্থিতি, ওটি ঘণ্টা ও টাকা, বোনাসসহ A4 মাস্টার পেপারে প্রিন্ট করুন"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                <span>A4 মাস্টার বেতন ও হাজিরা শিট</span>
              </button>

              <button
                type="button"
                onClick={handlePrintSalarySheet}
                className="py-1.5 px-3 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>পেমেন্ট খাতা প্রিন্ট</span>
              </button>
            </div>
          </div>

          {/* 1-Click A4 Master Sheet Callout Banner */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-cyan-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <div className="font-black text-xs text-slate-900 flex items-center gap-2">
                  <span>সকল শ্রমিকের A4 বেতন ও হাজিরা মাস্টার শিট</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                    ১-ক্লিক প্রিন্ট রেডি
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  এক ক্লিকে সকল শ্রমিকের উপস্থিতি, অনুপস্থিতি, মোট ওভারটাইম ঘণ্টা ও টাকা, হাজিরা বোনাস, নিট বেতন ও স্বাক্ষর কলামসহ A4 ল্যান্ডস্কেপ পেপারে প্রিন্ট করুন।
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  if (salaryMonthFilter !== 'all') {
                    setMasterA4Month(salaryMonthFilter);
                  } else if (uniqueSalaryRecords.length > 0 && (!masterA4Month || masterA4Month === 'all')) {
                    setMasterA4Month(uniqueSalaryRecords[0]?.month || 'সেপ্টেম্বর');
                  }
                  if (salaryYearFilter !== 'all') {
                    setMasterA4Year(Number(salaryYearFilter));
                  }
                  setShowMasterA4Modal(true);
                }}
                className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-bold text-xs flex items-center gap-1.5 shadow-2xs transition cursor-pointer active:scale-95"
              >
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                <span>প্রিভিউ ও সেটিংস</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (salaryMonthFilter !== 'all') {
                    setMasterA4Month(salaryMonthFilter);
                  } else if (uniqueSalaryRecords.length > 0 && (!masterA4Month || masterA4Month === 'all')) {
                    setMasterA4Month(uniqueSalaryRecords[0]?.month || 'সেপ্টেম্বর');
                  }
                  if (salaryYearFilter !== 'all') {
                    setMasterA4Year(Number(salaryYearFilter));
                  }
                  handlePrintMasterA4Sheet();
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
                title="সরাসরি প্রিন্ট ডায়ালগ ওপেন করুন"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-200" />
                <span>১-ক্লিকে সরাসরি প্রিন্ট ({toBengaliNumber(masterTotals.workersCount)} জন)</span>
              </button>
            </div>
          </div>

          {/* Filtering Row: মাস, বছর, মাধ্যম, স্ট্যাটাস, সার্চ */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                মাস নির্বাচন করুন
              </label>
              <select
                value={salaryMonthFilter}
                onChange={(e) => setSalaryMonthFilter(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">সব মাস (All Months)</option>
                {BENGALI_MONTHS.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                বছর নির্বাচন করুন
              </label>
              <select
                value={salaryYearFilter}
                onChange={(e) => setSalaryYearFilter(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">সব বছর (All Years)</option>
                {[2024, 2025, 2026, 2027, 2028].map((y) => (
                  <option key={y} value={String(y)}>
                    {toBengaliNumber(y)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                পেমেন্ট মাধ্যম (Method)
              </label>
              <select
                value={salaryMethodFilter}
                onChange={(e) => setSalaryMethodFilter(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">সব মাধ্যম (All)</option>
                <option value="cash">💵 ক্যাশ (নগদ)</option>
                <option value="bkash">📱 বিকাশ (bKash)</option>
                <option value="nagad">📲 নগদ (Nagad)</option>
                <option value="rocket">🟣 রকেট (Rocket)</option>
                <option value="bank">🏦 ব্যাংক (Bank)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                পরিশোধ স্ট্যাটাস (Status)
              </label>
              <select
                value={salaryStatusFilter}
                onChange={(e) => setSalaryStatusFilter(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">সব স্ট্যাটাস</option>
                <option value="paid">✓ সম্পূর্ণ পরিশোধিত</option>
                <option value="due">⌛ বাকী</option>
                <option value="pending">⏳ পেন্ডিং</option>
              </select>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                শ্রমিক / আইডি খুঁজুন
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={salarySearchQuery}
                  onChange={(e) => setSalarySearchQuery(e.target.value)}
                  placeholder="নাম বা Worker ID..."
                  className="w-full p-2 pl-7 bg-white border border-slate-300 rounded-lg text-xs"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5" />
              </div>
            </div>
          </div>

          {/* Filtered Dataset & Live Metrics */}
          {(() => {
            const filtered = uniqueSalaryRecords.filter((rec) => {
              if (salaryMonthFilter !== 'all' && rec.month !== salaryMonthFilter) return false;
              if (salaryYearFilter !== 'all' && String(rec.year) !== String(salaryYearFilter)) return false;
              if (salaryMethodFilter !== 'all' && rec.paymentMethod !== salaryMethodFilter) return false;
              if (salaryStatusFilter !== 'all') {
                if (salaryStatusFilter === 'pending') {
                  if (rec.paymentStatus !== 'pending' && rec.paymentStatus !== 'partial') return false;
                } else {
                  if (rec.paymentStatus !== salaryStatusFilter) return false;
                }
              }
              if (salarySearchQuery.trim()) {
                const q = salarySearchQuery.toLowerCase();
                const matchName = rec.employeeName.toLowerCase().includes(q);
                const matchId = rec.workerId.toLowerCase().includes(q);
                if (!matchName && !matchId) return false;
              }
              return true;
            });

            // Live metrics calculated strictly from the actual records matching the filter
            const totalBasicSalary = filtered.reduce((sum, r) => sum + (r.salary || 0), 0);
            const totalWorkersCount = filtered.length;
            const totalPresentDays = filtered.reduce((sum, r) => sum + (r.presentDays || 0), 0);
            const totalAbsentDays = filtered.reduce(
              (sum, r) => sum + Math.max(0, (r.totalDays || 26) - (r.presentDays || 0)),
              0
            );
            const totalOtHours = filtered.reduce((sum, r) => sum + (r.otHours || 0), 0);
            const totalOtPay = filtered.reduce((sum, r) => sum + (r.otPay || 0), 0);
            const totalBonus = filtered.reduce((sum, r) => sum + (r.bonus || 0), 0);
            const totalNetPayable = filtered.reduce((sum, r) => sum + (r.netPayable || 0), 0);
            const totalPaid = filtered.reduce((sum, r) => {
              const p = r.paymentStatus === 'paid' ? (r.netPayable || r.paidAmount || 0) : (r.paidAmount || 0);
              return sum + p;
            }, 0);
            const totalDue = filtered.reduce((sum, r) => {
              if (r.paymentStatus === 'paid') return sum;
              const d = r.dueAmount !== undefined ? r.dueAmount : Math.max(0, (r.netPayable || 0) - (r.paidAmount || 0));
              return sum + d;
            }, 0);
            const cashCount = filtered.filter((r) => r.paymentMethod === 'cash').reduce((sum, r) => {
              const p = r.paymentStatus === 'paid' ? (r.netPayable || r.paidAmount || 0) : (r.paidAmount || 0);
              return sum + p;
            }, 0);
            const bkashCount = filtered.filter((r) => r.paymentMethod === 'bkash').reduce((sum, r) => {
              const p = r.paymentStatus === 'paid' ? (r.netPayable || r.paidAmount || 0) : (r.paidAmount || 0);
              return sum + p;
            }, 0);

            return (
              <>
                {/* On-Screen Master Summary Cards (সম্পূর্ণ ফিল্টারের রেকর্ডের ওপর ভিত্তি করে, ডিলিট করলে ০ হবে) */}
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="text-[11px] font-semibold text-slate-600">মোট মূল বেতন</div>
                    <div className="text-sm font-black text-slate-900 mt-0.5">{formatMoney(totalBasicSalary)} ৳</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{toBengaliNumber(totalWorkersCount)} জন শ্রমিক</div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
                    <div className="text-[11px] font-semibold text-emerald-700">উপস্থিতি / অনুপস্থিতি</div>
                    <div className="text-sm font-black text-emerald-950 mt-0.5">
                      {toBengaliNumber(totalPresentDays)} / {toBengaliNumber(totalAbsentDays)}
                    </div>
                    <div className="text-[10px] text-emerald-600 mt-0.5">মোট দিন</div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-200">
                    <div className="text-[11px] font-semibold text-blue-700">মোট ওভারটাইম ঘণ্টা ও টাকা</div>
                    <div className="text-sm font-black text-blue-950 mt-0.5">
                      {toBengaliNumber(totalOtHours)} ঘ. ({formatMoney(totalOtPay)} ৳)
                    </div>
                    <div className="text-[10px] text-blue-600 mt-0.5">ওটি রেট অনুযায়ী</div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200">
                    <div className="text-[11px] font-semibold text-amber-700">মোট বোনাস</div>
                    <div className="text-sm font-black text-amber-950 mt-0.5">{formatMoney(totalBonus)} ৳</div>
                    <div className="text-[10px] text-amber-600 mt-0.5">হাজিরা/উৎসব বোনাস</div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-purple-50/70 border border-purple-200">
                    <div className="text-[11px] font-semibold text-purple-700">মোট নিট প্রদেয়</div>
                    <div className="text-sm font-black text-purple-950 mt-0.5">{formatMoney(totalNetPayable)} ৳</div>
                    <div className="text-[10px] text-purple-600 mt-0.5">সর্বমোট নিট বেতন</div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-rose-50/70 border border-rose-200">
                    <div className="text-[11px] font-semibold text-rose-700">পরিশোধিত / বকেয়া</div>
                    <div className="text-sm font-black text-rose-950 mt-0.5">
                      {formatMoney(totalPaid)} / {formatMoney(totalDue)} ৳
                    </div>
                    <div className="text-[10px] text-rose-600 mt-0.5">
                      {totalDue === 0 && totalWorkersCount > 0 ? 'সম্পূর্ণ পরিশোধিত' : totalDue > 0 ? 'বকেয়া আছে' : 'রেকর্ড নেই'}
                    </div>
                  </div>
                </div>

                {/* Filter Info and Batch Delete Action Toolbar */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex flex-wrap items-center gap-2 text-slate-700">
                    <span className="font-bold">
                      প্রদর্শিত রেকর্ড: <strong className="text-slate-900">{toBengaliNumber(filtered.length)} টি</strong>
                    </span>
                    <span className="text-slate-400">•</span>
                    <span className="text-[11px] text-slate-600">
                      মাস ও বছর: <strong>{salaryMonthFilter === 'all' ? 'সকল মাস' : salaryMonthFilter} {salaryYearFilter === 'all' ? 'সকল বছর' : `${toBengaliNumber(salaryYearFilter)} সাল`}</strong>
                    </span>
                    {totalWorkersCount > 0 && (
                      <>
                        <span className="text-slate-400">•</span>
                        <span className="text-[11px] text-emerald-700 font-semibold">
                          ক্যাশ: {formatMoney(cashCount)} ৳ | বিকাশ: {formatMoney(bkashCount)} ৳
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (salaryMonthFilter !== 'all') {
                          setBatchDeleteMonth(salaryMonthFilter);
                        }
                        if (salaryYearFilter !== 'all') {
                          setBatchDeleteYear(Number(salaryYearFilter));
                        }
                        setShowBatchDeleteModal(true);
                      }}
                      className="py-1.5 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-800 border border-rose-200 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto"
                      title="মাস অনুযায়ী সকল তথ্য এক ক্লিকে মুছুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মাস অনুযায়ী এক ক্লিকে মুছুন</span>
                    </button>
                  </div>
                </div>

                {/* Printable Salary Sheet Container */}
                <div
                  id="monthlySalarySheetPrintArea"
                  ref={salarySheetPrintRef}
                  className="space-y-3"
                >
                  <div className="hidden print:block print-block text-center border-b pb-2 mb-3">
                    <h2 className="text-lg font-black">টেক্স ওয়ার অ্যাপারেলস</h2>
                    <p className="text-xs font-semibold">
                      মাসিক বেতন ও পেমেন্ট বিবরণী — {salaryMonthFilter === 'all' ? 'সকল মাস' : salaryMonthFilter} {salaryYearFilter === 'all' ? 'সকল বছর' : `${toBengaliNumber(salaryYearFilter)} সাল`}
                    </p>
                    <p className="text-[10px] text-slate-500">প্রিন্ট তারিখ: {new Date().toLocaleDateString('bn-BD')}</p>
                    <div className="grid grid-cols-4 gap-2 mt-2 pt-2 border-t border-slate-200 text-[10px] font-bold">
                      <div>মোট রেকর্ড: {toBengaliNumber(filtered.length)} টি</div>
                      <div>মোট মূল বেতন: {formatMoney(totalBasicSalary)} ৳</div>
                      <div>মোট ওটি টাকা: {formatMoney(totalOtPay)} ৳</div>
                      <div>মোট নিট প্রদেয়: {formatMoney(totalNetPayable)} ৳</div>
                    </div>
                  </div>

                  {filtered.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-slate-500 text-xs">
                      <AlertTriangle className="w-6 h-6 mx-auto text-slate-400 mb-1" />
                      <p className="font-bold">কোনো বেতন রেকর্ড পাওয়া যায়নি</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        User Salary ক্যালকুলেটরে গিয়ে বেতন হিসাব করে "এডমিনের খাতায় বেতন রেকর্ড সেভ করুন" বাটনে চাপুন।
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                          <tr>
                            <th className="p-2.5">তারিখ/মাস</th>
                            <th className="p-2.5">কর্মচারী ও আইডি</th>
                            <th className="p-2.5">পদবি</th>
                            <th className="p-2.5 text-right">নিট বেতন</th>
                            <th className="p-2.5 text-right">প্রদত্ত (Paid)</th>
                            <th className="p-2.5 text-center">মাধ্যম</th>
                            <th className="p-2.5 text-right">বকেয়া (Due)</th>
                            <th className="p-2.5 text-center">স্ট্যাটাস</th>
                            <th className="p-2.5 text-center no-print">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800">
                          {filtered.map((rec) => {
                            const methodBadge = (() => {
                              switch (rec.paymentMethod) {
                                case 'cash':
                                  return <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">💵 ক্যাশ</span>;
                                case 'bkash':
                                  return <span className="px-2 py-0.5 rounded-full bg-pink-100 text-pink-800 font-bold text-[10px]">📱 বিকাশ</span>;
                                case 'nagad':
                                  return <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 font-bold text-[10px]">📲 নগদ</span>;
                                case 'rocket':
                                  return <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 font-bold text-[10px]">🟣 রকেট</span>;
                                case 'bank':
                                  return <span className="px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold text-[10px]">🏦 ব্যাংক</span>;
                                default:
                                  return <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">অন্যান্য</span>;
                              }
                            })();

                            return (
                              <tr key={rec.id} className="hover:bg-slate-50 transition">
                                <td className="p-2.5 whitespace-nowrap">
                                  <div className="font-bold text-slate-900">{rec.month} {rec.year}</div>
                                  <div className="text-[10px] text-slate-400">{new Date(rec.paidAt).toLocaleDateString('bn-BD')}</div>
                                </td>
                                <td className="p-2.5 whitespace-nowrap">
                                  <div className="font-bold text-slate-900">{rec.employeeName}</div>
                                  <div className="text-[10px] text-slate-500">ID: {rec.workerId}</div>
                                </td>
                                <td className="p-2.5 whitespace-nowrap text-slate-600">
                                  {rec.designation}
                                </td>
                                <td className="p-2.5 text-right font-bold text-slate-900 whitespace-nowrap">
                                  {formatMoney(rec.netPayable)} ৳
                                </td>
                                <td className="p-2.5 text-right font-black text-emerald-700 whitespace-nowrap">
                                  {formatMoney(rec.paymentStatus === 'paid' ? rec.netPayable : (rec.paidAmount || 0))} ৳
                                </td>
                                <td className="p-2.5 text-center whitespace-nowrap">
                                  {methodBadge}
                                </td>
                                <td className="p-2.5 text-right font-bold whitespace-nowrap">
                                  {rec.paymentStatus === 'paid' || rec.dueAmount === 0 ? (
                                    <span className="text-emerald-600 font-semibold">০ ৳</span>
                                  ) : (
                                    <span className="text-rose-600 font-black">{formatMoney(rec.dueAmount)} ৳</span>
                                  )}
                                </td>
                                <td className="p-2.5 text-center whitespace-nowrap">
                                  <div className="no-print">
                                    <select
                                      value={
                                        rec.paymentStatus === 'paid'
                                          ? 'paid'
                                          : rec.paymentStatus === 'pending' || rec.paymentStatus === 'partial'
                                          ? 'pending'
                                          : 'due'
                                      }
                                      onChange={(e) =>
                                        handleUpdateSalaryStatus(rec, e.target.value as 'paid' | 'due' | 'pending')
                                      }
                                      className={`px-2 py-1 rounded-lg text-[10.5px] font-bold border transition cursor-pointer focus:ring-2 focus:ring-blue-400 ${
                                        rec.paymentStatus === 'paid' || (!rec.paymentStatus && rec.dueAmount === 0)
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                          : rec.paymentStatus === 'pending' || rec.paymentStatus === 'partial'
                                          ? 'bg-amber-50 text-amber-800 border-amber-300'
                                          : 'bg-rose-50 text-rose-800 border-rose-300'
                                      }`}
                                      title="স্ট্যাটাস পরিবর্তন করুন"
                                    >
                                      <option value="paid">✓ সম্পূর্ণ পরিশোধিত</option>
                                      <option value="due">⌛ বাকী</option>
                                      <option value="pending">⏳ পেন্ডিং</option>
                                    </select>
                                  </div>
                                  <div className="hidden print:block print-block font-bold text-[10px]">
                                    {rec.paymentStatus === 'paid' || (!rec.paymentStatus && rec.dueAmount === 0)
                                      ? 'সম্পূর্ণ পরিশোধিত'
                                      : rec.paymentStatus === 'pending' || rec.paymentStatus === 'partial'
                                      ? 'পেন্ডিং'
                                      : 'বাকী'}
                                  </div>
                                </td>
                                <td className="p-2.5 text-center whitespace-nowrap no-print">
                                  <div className="flex items-center justify-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleOpenEditSalaryRecord(rec)}
                                      className="p-1 rounded-md text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition cursor-pointer"
                                      title="শ্রমিকের বেতন হিসাব সম্পাদন করুন (Edit)"
                                    >
                                      <Edit className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSalaryRecord(rec)}
                                      className="p-1 rounded-md text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                                      title="রেকর্ড মুছুন"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* ================= HIDDEN PRINT CONTAINER FOR MASTER A4 SHEET ================= */}
                <div className="hidden print:block print:relative print:w-full" aria-hidden="true">
                  <div
                    ref={masterA4SheetPrintRef}
                    id="masterSalaryA4PrintArea"
                    className="print-landscape bg-white text-slate-900 p-4"
                    style={{ minWidth: '1000px', fontFamily: '"Noto Sans Bengali", sans-serif' }}
                  >
                    {/* Factory Header */}
                    <div className="border-b-2 border-slate-900 pb-2 mb-2 text-center">
                      <h1 className="text-xl font-black text-slate-900 tracking-wide uppercase">
                        টেক্স ওয়ার অ্যাপারেলস (TexWare Apparels)
                      </h1>
                      <h2 className="text-xs font-bold text-slate-800 mt-0.5">
                        শ্রমিক ও কর্মচারীদের মাসিক বেতন ও হাজিরা মাস্টার বিবরণী (Monthly Attendance & Payroll Master Sheet)
                      </h2>
                      <div className="flex items-center justify-between mt-1 text-[10px] text-slate-600 font-semibold px-1">
                        <div>
                          <span>মাস ও বছর: </span>
                          <strong className="text-slate-950 text-[11px]">
                            {masterA4Month === 'all' ? 'সকল মাস' : masterA4Month} {masterA4Year ? `${toBengaliNumber(masterA4Year)} সাল` : ''}
                          </strong>
                          {masterA4Dept !== 'all' && (
                            <span className="ml-2 px-1.5 py-0.5 bg-slate-100 rounded text-slate-900">
                              সেকশন: {masterA4Dept}
                            </span>
                          )}
                        </div>
                        <div>
                          <span>মোট শ্রমিক সংখ্যা: </span>
                          <strong className="text-slate-950">{toBengaliNumber(masterTotals.workersCount)} জন</strong>
                        </div>
                        <div>
                          <span>মুদ্রণ তারিখ: </span>
                          <span>{new Date().toLocaleDateString('bn-BD')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Table */}
                    <table className="w-full border-collapse border border-slate-400 text-left text-[9.5px]">
                      <thead>
                        <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-400 text-center">
                          <th className="p-1 border border-slate-300 w-7">ক্র.</th>
                          <th className="p-1 border border-slate-300 w-14">আইডি</th>
                          <th className="p-1 border border-slate-300 text-left">শ্রমিকের নাম ও পদবি</th>
                          <th className="p-1 border border-slate-300">সেকশন</th>
                          <th className="p-1 border border-slate-300 text-right">মূল বেতন</th>
                          <th className="p-1 border border-slate-300 w-9">মোট দিন</th>
                          <th className="p-1 border border-slate-300 w-9 bg-emerald-50 text-emerald-900">উপস্থিতি</th>
                          <th className="p-1 border border-slate-300 w-9 bg-rose-50 text-rose-900">অনুপস্থিতি</th>
                          <th className="p-1 border border-slate-300 w-11 bg-blue-50 text-blue-900">ওটি ঘণ্টা</th>
                          <th className="p-1 border border-slate-300 text-right w-11">ওটি দর</th>
                          <th className="p-1 border border-slate-300 text-right bg-blue-50 text-blue-900">ওটি টাকা</th>
                          <th className="p-1 border border-slate-300 text-right bg-amber-50 text-amber-900">হাজিরা বোনাস</th>
                          <th className="p-1 border border-slate-300 text-right">অর্জিত বেতন</th>
                          <th className="p-1 border border-slate-300 text-right">কর্তন</th>
                          <th className="p-1 border border-slate-300 text-right font-black bg-slate-200 text-slate-950">নিট প্রদেয়</th>
                          <th className="p-1 border border-slate-300 w-14">স্ট্যাটাস</th>
                          <th className="p-1 border border-slate-300 w-20">শ্রমিকের স্বাক্ষর</th>
                        </tr>
                      </thead>
                      <tbody>
                        {masterA4Rows.map((row) => (
                          <tr key={row.workerId} className="border-b border-slate-300 hover:bg-slate-50">
                            <td className="p-1 border border-slate-300 text-center font-semibold">{toBengaliNumber(row.sl)}</td>
                            <td className="p-1 border border-slate-300 text-center font-bold text-slate-800">{row.workerId}</td>
                            <td className="p-1 border border-slate-300 text-left">
                              <div className="font-bold text-slate-900 leading-tight">{row.name}</div>
                              <div className="text-[8px] text-slate-600 leading-tight">{row.designation}</div>
                            </td>
                            <td className="p-1 border border-slate-300 text-center text-[9px] text-slate-700">{row.department}</td>
                            <td className="p-1 border border-slate-300 text-right font-semibold">{formatMoney(row.basicSalary)}</td>
                            <td className="p-1 border border-slate-300 text-center">{toBengaliNumber(row.totalDays)}</td>
                            <td className="p-1 border border-slate-300 text-center font-bold text-emerald-800 bg-emerald-50/50">
                              {toBengaliNumber(row.presentDays)}
                            </td>
                            <td className="p-1 border border-slate-300 text-center font-bold text-rose-800 bg-rose-50/50">
                              {toBengaliNumber(row.absentDays)}
                            </td>
                            <td className="p-1 border border-slate-300 text-center font-bold text-blue-800 bg-blue-50/50">
                              {toBengaliNumber(row.otHours)}
                            </td>
                            <td className="p-1 border border-slate-300 text-right text-slate-600">{formatMoney(row.otRate)}</td>
                            <td className="p-1 border border-slate-300 text-right font-bold text-blue-900 bg-blue-50/50">
                              {formatMoney(row.otPay)}
                            </td>
                            <td className="p-1 border border-slate-300 text-right font-bold text-amber-900 bg-amber-50/50">
                              {row.attendanceBonus > 0 ? formatMoney(row.attendanceBonus) : '—'}
                            </td>
                            <td className="p-1 border border-slate-300 text-right font-semibold text-slate-800">
                              {formatMoney(row.presentSalary)}
                            </td>
                            <td className="p-1 border border-slate-300 text-right text-rose-700">
                              {(row.advance + row.deduction) > 0 ? formatMoney(row.advance + row.deduction) : '—'}
                            </td>
                            <td className="p-1 border border-slate-300 text-right font-black text-slate-950 bg-slate-100">
                              {formatMoney(row.netPayable)} ৳
                            </td>
                            <td className="p-1 border border-slate-300 text-center text-[8.5px] font-semibold">
                              {row.paymentStatus === 'paid' ? (
                                <span className="text-emerald-700 font-bold">সম্পূর্ণ পরিশোধিত</span>
                              ) : row.paymentStatus === 'pending' || row.paymentStatus === 'partial' ? (
                                <span className="text-amber-700 font-bold">পেন্ডিং</span>
                              ) : (
                                <span className="text-rose-700 font-bold">বাকী</span>
                              )}
                            </td>
                            <td className="p-1 border border-slate-300 text-center">
                              <div className="h-5"></div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-200 text-slate-900 font-black border-t-2 border-slate-500 text-center">
                          <td colSpan={4} className="p-1 border border-slate-300 text-right pr-2">
                            সর্বমোট ({toBengaliNumber(masterTotals.workersCount)} জন):
                          </td>
                          <td className="p-1 border border-slate-300 text-right">{formatMoney(masterTotals.totalBasicSalary)} ৳</td>
                          <td className="p-1 border border-slate-300">—</td>
                          <td className="p-1 border border-slate-300 text-emerald-950">{toBengaliNumber(masterTotals.totalPresentDays)}</td>
                          <td className="p-1 border border-slate-300 text-rose-950">{toBengaliNumber(masterTotals.totalAbsentDays)}</td>
                          <td className="p-1 border border-slate-300 text-blue-950">{toBengaliNumber(masterTotals.totalOtHours)}</td>
                          <td className="p-1 border border-slate-300">—</td>
                          <td className="p-1 border border-slate-300 text-right text-blue-950">{formatMoney(masterTotals.totalOtPay)} ৳</td>
                          <td className="p-1 border border-slate-300 text-right text-amber-950">{formatMoney(masterTotals.totalBonus)} ৳</td>
                          <td className="p-1 border border-slate-300 text-right">{formatMoney(masterTotals.totalPresentSalary)} ৳</td>
                          <td className="p-1 border border-slate-300 text-right text-rose-900">
                            {formatMoney(masterTotals.totalAdvance + masterTotals.totalDeduction)} ৳
                          </td>
                          <td className="p-1 border border-slate-300 text-right bg-slate-300 text-slate-950">
                            {formatMoney(masterTotals.totalNetPayable)} ৳
                          </td>
                          <td colSpan={2} className="p-1 border border-slate-300 text-center text-[9px]">
                            পরিশোধিত: {formatMoney(masterTotals.totalPaid)} ৳ | বকেয়া: {formatMoney(masterTotals.totalDue)} ৳
                          </td>
                        </tr>
                      </tfoot>
                    </table>

                    {/* Signatures */}
                    <div className="grid grid-cols-5 gap-3 mt-7 pt-3 border-t border-slate-300 text-center text-[9px] font-bold text-slate-700">
                      <div>
                        <div className="border-t border-slate-400 pt-1 mt-5">হিসাব প্রস্তুতকারী</div>
                        <div className="text-[7.5px] text-slate-500 font-normal">Prepared By</div>
                      </div>
                      <div>
                        <div className="border-t border-slate-400 pt-1 mt-5">হিসাব কর্মকর্তা</div>
                        <div className="text-[7.5px] text-slate-500 font-normal">Accountant</div>
                      </div>
                      <div>
                        <div className="border-t border-slate-400 pt-1 mt-5">সেকশন ইনচার্জ</div>
                        <div className="text-[7.5px] text-slate-500 font-normal">Section In-Charge</div>
                      </div>
                      <div>
                        <div className="border-t border-slate-400 pt-1 mt-5">এইচআর ও এডমিন ম্যানেজার</div>
                        <div className="text-[7.5px] text-slate-500 font-normal">HR & Admin Manager</div>
                      </div>
                      <div>
                        <div className="border-t border-slate-400 pt-1 mt-5">ব্যবস্থাপনা পরিচালক</div>
                        <div className="text-[7.5px] text-slate-500 font-normal">Managing Director</div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* ================= TAB 3: EMPLOYEE FORM (ADD / EDIT) ================= */}
      {activeTab === 'form' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <UserPlus className="w-4 h-4 text-blue-600" />
              <span>{editId ? 'কর্মচারীর তথ্য সম্পাদন (Edit)' : 'নতুন কর্মচারী নিবন্ধন (Add Employee)'}</span>
            </div>
            {editId && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                নতুন কর্মী ফর্মে ফিরে যান
              </button>
            )}
          </div>

          <form onSubmit={handleSaveEmployee} className="space-y-3.5 text-xs text-slate-800">
            <div>
              <label className="block font-bold text-slate-700 mb-1">কর্মচারীর পূর্ণ নাম *</label>
              <input
                type="text"
                required
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="যেমন: মোঃ রফিকুল ইসলাম"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Worker ID / আইডি নম্বর *</label>
                <input
                  type="text"
                  required
                  value={formWorkerId}
                  onChange={(e) => setFormWorkerId(e.target.value)}
                  placeholder="যেমন: TW-106"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">পদবি (Designation) *</label>
                <input
                  type="text"
                  required
                  value={formDesignation}
                  onChange={(e) => setFormDesignation(e.target.value)}
                  placeholder="যেমন: সুইং অপারেটর / কোয়ালিটি"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">সেকশন / ডিপার্টমেন্ট</label>
                <select
                  value={formDepartment}
                  onChange={(e) => setFormDepartment(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                >
                  <option value="সুইং সেকশন">সুইং সেকশন</option>
                  <option value="কাটিং সেকশন">কাটিং সেকশন</option>
                  <option value="ফিনিশিং সেকশন">ফিনিশিং সেকশন</option>
                  <option value="কোয়ালিটি কন্ট্রোল">কোয়ালিটি কন্ট্রোল</option>
                  <option value="আইরন ও প্যাকিং">আইরন ও প্যাকিং</option>
                  <option value="মেইনটেন্যান্স ও মেকানিক">মেইনটেন্যান্স ও মেকানিক</option>
                  <option value="অফিস ও প্রশাসন">অফিস ও প্রশাসন</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মাসিক মূল বেতন *</label>
                <input
                  type="number"
                  required
                  min={0}
                  value={formSalary}
                  onChange={(e) => setFormSalary(e.target.value)}
                  placeholder="14000"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">প্রতি ঘণ্টা OT রেট *</label>
                <input
                  type="number"
                  required
                  min={0}
                  value={formOtRate}
                  onChange={(e) => setFormOtRate(e.target.value)}
                  placeholder="85"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">যোগদানের তারিখ</label>
                <input
                  type="date"
                  value={formJoinDate}
                  onChange={(e) => setFormJoinDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">জন্ম তারিখ</label>
                <input
                  type="date"
                  value={formBirthDate}
                  onChange={(e) => setFormBirthDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                <input
                  type="tel"
                  value={formMobile}
                  onChange={(e) => setFormMobile(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">জাতীয় পরিচয়পত্র (NID) নম্বর</label>
                <input
                  type="text"
                  value={formNid}
                  onChange={(e) => setFormNid(e.target.value)}
                  placeholder="NID নম্বর"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Worker Portal Password (Admin Control) */}
            <div className="p-3 bg-indigo-50/60 border border-indigo-200 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-indigo-950 text-xs flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-indigo-600" />
                  <span>শ্রমিক পোর্টাল লগইন পাসওয়ার্ড (Worker Portal Password)</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    const last4 = formMobile.replace(/[^0-9]/g, '').slice(-4);
                    setFormPortalPassword(last4 || '123456');
                  }}
                  className="text-[10.5px] text-indigo-700 hover:text-indigo-900 underline font-semibold cursor-pointer"
                >
                  ডিফল্ট সেট করুন
                </button>
              </div>
              <input
                type="text"
                value={formPortalPassword}
                onChange={(e) => setFormPortalPassword(e.target.value)}
                placeholder="পাসওয়ার্ড দিন (ডিফল্ট: মোবাইলের শেষ ৪ সংখ্যা বা 123456)"
                className="w-full p-2 bg-white border border-indigo-300 rounded-xl font-mono text-xs font-bold text-indigo-950 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <p className="text-[10.5px] text-slate-500">
                শ্রমিক এই পাসওয়ার্ড ও মোবাইল নম্বর দিয়ে তার ব্যক্তিগত প্রোফাইলে লগইন করে হাজিরা, ইন/আউট টাইম ও বেতন দেখতে পারবে।
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">স্থায়ী ও বর্তমান ঠিকানা</label>
              <textarea
                value={formAddress}
                onChange={(e) => setFormAddress(e.target.value)}
                placeholder="গ্রাম, ডাকঘর, থানা, জেলা..."
                rows={2}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white"
              />
            </div>

            {/* Employee Photo Upload or URL */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <label className="block font-bold text-slate-700">
                শ্রমিকের ছবি (চুক্তিপত্র ও আইডি কার্ডে ব্যবহৃত হবে)
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-3">
                {formPhotoUrl ? (
                  <img
                    src={formPhotoUrl}
                    alt="Preview"
                    className="w-16 h-16 rounded-full object-cover border-2 border-blue-400 shadow-xs shrink-0"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-slate-200 border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 shrink-0">
                    <Camera className="w-6 h-6" />
                  </div>
                )}
                <div className="flex-1 w-full space-y-1.5">
                  <div className="flex items-center gap-2">
                    <label className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-2xs">
                      <Upload className="w-3.5 h-3.5 text-blue-600" />
                      <span>ডিভাইস থেকে ছবি আপলোড</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          if (file.size > 2.5 * 1024 * 1024) {
                            showToast('ছবির সাইজ ২.৫ মেগাবাইটের কম হতে হবে');
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = () => {
                            setFormPhotoUrl(reader.result as string);
                            showToast('ছবি সফলভাবে লোড হয়েছে');
                          };
                          reader.readAsDataURL(file);
                        }}
                      />
                    </label>
                    {formPhotoUrl && (
                      <button
                        type="button"
                        onClick={() => setFormPhotoUrl('')}
                        className="text-xs text-rose-600 hover:underline font-semibold"
                      >
                        ছবি সরান
                      </button>
                    )}
                  </div>
                  <input
                    type="url"
                    value={formPhotoUrl}
                    onChange={(e) => setFormPhotoUrl(e.target.value)}
                    placeholder="অথবা ছবির URL দিন: https://example.com/photo.jpg"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Employee Signature Upload or Digital Pad */}
            <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                  <FileSignature className="w-4 h-4 text-amber-700" />
                  <span>শ্রমিকের স্বাক্ষর (চুক্তিপত্র, বরখাস্ত ও পদত্যাগ ফাইলের জন্য)</span>
                </label>
                <span className="text-[10px] text-amber-900 bg-amber-100 border border-amber-300 font-bold px-2 py-0.5 rounded-full">
                  স্বয়ংক্রিয়ভাবে ফর্মে বসবে
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                {formSignatureUrl ? (
                  <div className="relative group p-1.5 bg-white rounded-lg border-2 border-amber-400 shadow-2xs shrink-0">
                    <img
                      src={formSignatureUrl}
                      alt="Signature Preview"
                      className="h-12 w-32 object-contain bg-white"
                    />
                    <div className="text-[9px] text-center text-slate-500 font-bold mt-0.5">স্বাক্ষর সংরক্ষিত</div>
                  </div>
                ) : (
                  <div className="h-12 w-32 rounded-lg bg-amber-100/50 border-2 border-dashed border-amber-300 flex flex-col items-center justify-center text-amber-600 shrink-0">
                    <FileSignature className="w-5 h-5 text-amber-500" />
                    <span className="text-[9px] font-bold">স্বাক্ষর নেই</span>
                  </div>
                )}

                <div className="flex-1 w-full space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <label className="py-2 px-3 bg-white hover:bg-slate-50 border border-amber-300 text-slate-800 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-2xs transition active:scale-95">
                      <Upload className="w-3.5 h-3.5 text-amber-600" />
                      <span>ডিভাইস থেকে স্বাক্ষর আপলোড (PNG/JPG)</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          if (file.size > 2.5 * 1024 * 1024) {
                            showToast('স্বাক্ষর ফাইলের সাইজ ২.৫ মেগাবাইটের কম হতে হবে');
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = () => {
                            setFormSignatureUrl(reader.result as string);
                            showToast('✓ স্বাক্ষর সফলভাবে লোড হয়েছে');
                          };
                          reader.readAsDataURL(file);
                        }}
                      />
                    </label>

                    <button
                      type="button"
                      onClick={() => setShowSignaturePad((prev) => !prev)}
                      className="py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs transition active:scale-95 cursor-pointer"
                    >
                      <PenTool className="w-3.5 h-3.5" />
                      <span>{showSignaturePad ? 'প্যাড বন্ধ করুন' : 'প্যাডে সই আঁকা (ঐচ্ছিক)'}</span>
                    </button>

                    {formSignatureUrl && (
                      <button
                        type="button"
                        onClick={() => setFormSignatureUrl('')}
                        className="text-xs text-rose-600 hover:underline font-bold"
                      >
                        স্বাক্ষর সরান
                      </button>
                    )}
                  </div>

                  {/* Expandable Digital Signature Canvas Pad */}
                  {showSignaturePad && (
                    <div className="p-2.5 bg-white border border-amber-300 rounded-xl shadow-xs space-y-2 mt-2">
                      <div className="flex items-center justify-between text-xs text-slate-700">
                        <span className="font-bold flex items-center gap-1 text-amber-900">
                          <PenTool className="w-3 h-3 text-amber-600" />
                          নিচের বক্সে মাউস বা আঙুল দিয়ে সই করুন:
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              const canvas = signatureCanvasRef.current;
                              if (canvas) {
                                const ctx = canvas.getContext('2d');
                                if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
                              }
                            }}
                            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold"
                          >
                            মুছুন (Clear)
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const canvas = signatureCanvasRef.current;
                              if (canvas) {
                                const dataUrl = canvas.toDataURL('image/png');
                                setFormSignatureUrl(dataUrl);
                                setShowSignaturePad(false);
                                showToast('✓ ডিজিটাল স্বাক্ষর সংরক্ষিত হয়েছে');
                              }
                            }}
                            className="px-2.5 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold flex items-center gap-1"
                          >
                            <Check className="w-3 h-3" />
                            <span>সম্পন্ন (Save)</span>
                          </button>
                        </div>
                      </div>
                      <div className="border-2 border-dashed border-amber-300 rounded-lg overflow-hidden bg-white">
                        <canvas
                          ref={signatureCanvasRef}
                          width={320}
                          height={100}
                          className="w-full h-24 touch-none cursor-crosshair bg-white"
                          onMouseDown={(e) => {
                            const canvas = signatureCanvasRef.current;
                            if (!canvas) return;
                            const rect = canvas.getBoundingClientRect();
                            const scaleX = canvas.width / rect.width;
                            const scaleY = canvas.height / rect.height;
                            const ctx = canvas.getContext('2d');
                            if (!ctx) return;
                            ctx.strokeStyle = '#1e3a8a';
                            ctx.lineWidth = 2.5;
                            ctx.lineCap = 'round';
                            ctx.lineJoin = 'round';
                            ctx.beginPath();
                            ctx.moveTo((e.clientX - rect.left) * scaleX, (e.clientY - rect.top) * scaleY);
                            setIsDrawing(true);
                          }}
                          onMouseMove={(e) => {
                            if (!isDrawing) return;
                            const canvas = signatureCanvasRef.current;
                            if (!canvas) return;
                            const rect = canvas.getBoundingClientRect();
                            const scaleX = canvas.width / rect.width;
                            const scaleY = canvas.height / rect.height;
                            const ctx = canvas.getContext('2d');
                            if (!ctx) return;
                            ctx.lineTo((e.clientX - rect.left) * scaleX, (e.clientY - rect.top) * scaleY);
                            ctx.stroke();
                          }}
                          onMouseUp={() => setIsDrawing(false)}
                          onMouseLeave={() => setIsDrawing(false)}
                          onTouchStart={(e) => {
                            const canvas = signatureCanvasRef.current;
                            if (!canvas || !e.touches[0]) return;
                            const rect = canvas.getBoundingClientRect();
                            const scaleX = canvas.width / rect.width;
                            const scaleY = canvas.height / rect.height;
                            const touch = e.touches[0];
                            const ctx = canvas.getContext('2d');
                            if (!ctx) return;
                            ctx.strokeStyle = '#1e3a8a';
                            ctx.lineWidth = 2.5;
                            ctx.lineCap = 'round';
                            ctx.lineJoin = 'round';
                            ctx.beginPath();
                            ctx.moveTo((touch.clientX - rect.left) * scaleX, (touch.clientY - rect.top) * scaleY);
                            setIsDrawing(true);
                          }}
                          onTouchMove={(e) => {
                            if (!isDrawing || !e.touches[0]) return;
                            const canvas = signatureCanvasRef.current;
                            if (!canvas) return;
                            const rect = canvas.getBoundingClientRect();
                            const scaleX = canvas.width / rect.width;
                            const scaleY = canvas.height / rect.height;
                            const touch = e.touches[0];
                            const ctx = canvas.getContext('2d');
                            if (!ctx) return;
                            ctx.lineTo((touch.clientX - rect.left) * scaleX, (touch.clientY - rect.top) * scaleY);
                            ctx.stroke();
                          }}
                          onTouchEnd={() => setIsDrawing(false)}
                        />
                      </div>
                      <p className="text-[9.5px] text-slate-500 italic">
                        পরামর্শ: আঙুল বা মাউস দিয়ে সই করে "সম্পন্ন (Save)" বাটনে চাপুন। এটি নীল কালিতে ডিজিটাল স্বাক্ষর তৈরি করবে।
                      </p>
                    </div>
                  )}

                  <p className="text-[10px] text-amber-800">
                    💡 এই স্বাক্ষরটি নিয়োগ চুক্তিপত্র (Contract), চাকরি বরখাস্ত নোটিশ (Termination) ও পদত্যাগপত্রে (Resignation) স্বয়ংক্রিয়ভাবে যুক্ত হবে।
                  </p>
                </div>
              </div>
            </div>

            {/* Bank Information (Exact user request) */}
            <div className="p-3 bg-blue-50/50 border border-blue-200 rounded-xl space-y-2">
              <div className="font-bold text-blue-950 flex items-center gap-1.5 text-xs">
                <CreditCard className="w-4 h-4 text-blue-700" />
                <span>ব্যাংক তথ্য (চুক্তিপত্র ও বেতন স্থানান্তরের জন্য):</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">ব্যাংক নাম</label>
                  <input
                    type="text"
                    value={formBankName}
                    onChange={(e) => setFormBankName(e.target.value)}
                    placeholder="যেমন: ডাচ বাংলা ব্যাংক / বিকাশ"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">একাউন্ট নাম</label>
                  <input
                    type="text"
                    value={formAccountName}
                    onChange={(e) => setFormAccountName(e.target.value)}
                    placeholder="শ্রমিকের নাম অনুযায়ী"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">একাউন্ট নাম্বার</label>
                  <input
                    type="text"
                    value={formAccountNumber}
                    onChange={(e) => setFormAccountNumber(e.target.value)}
                    placeholder="যেমন: ১২৩.১০১.XXXXX"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">চাকরির বর্তমান স্ট্যাটাস</label>
              <select
                value={formStatus}
                onChange={(e) => setFormStatus(e.target.value as EmploymentStatus)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white font-bold"
              >
                <option value="active">কর্মরত / সক্রিয় (Active)</option>
                <option value="resigned">পদত্যাগ / রিজাইনকৃত (Resigned)</option>
                <option value="suspended">সাময়িক স্থগিত (Suspended)</option>
                <option value="terminated">অব্যাহতিপ্রাপ্ত (Terminated)</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="submit"
                className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md transition"
              >
                {editId ? 'তথ্য আপডেট করুন' : 'নতুন কর্মচারী সংরক্ষণ করুন'}
              </button>
              {editId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-3 rounded-xl bg-slate-200 text-slate-700 font-bold hover:bg-slate-300 transition"
                >
                  বাতিল
                </button>
              )}
            </div>
          </form>
        </div>
      )}

      {/* ================= TAB 4: EMPLOYEE DETAILS & PRINT ================= */}
      {activeTab === 'details' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <IdCard className="w-4 h-4 text-blue-600" />
              <span>শ্রমিকের বিস্তারিত প্রোফাইল ও প্রিন্ট</span>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-800">
                কর্মরত শ্রমিক নির্বাচন করুন ({activeWorkingEmployees.length} জন কর্মরত):
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-full border border-emerald-300 font-bold">
                ✓ শুধুমাত্র কর্মরত শ্রমিক
              </span>
            </div>
            <select
              value={detailSelectedId}
              onChange={(e) => {
                const newId = e.target.value;
                setDetailSelectedId(newId);
                try {
                  localStorage.setItem('texware_selected_detail_id', newId);
                } catch {}
              }}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
            >
              {activeWorkingEmployees.length === 0 ? (
                <option value="">কোনো কর্মরত শ্রমিক নেই</option>
              ) : (
                activeWorkingEmployees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} — {emp.workerId} ({emp.designation})
                  </option>
                ))
              )}
            </select>
          </div>

          {selectedDetailEmp && (
            <div
              id="employeeProfilePrintArea"
              ref={profilePrintRef}
              className="border border-slate-200 rounded-xl overflow-hidden shadow-xs bg-white"
            >
              <div className="bg-gradient-to-b from-slate-50 to-white p-5 text-center border-b border-slate-200">
                {/* Hidden photo input */}
                <input
                  type="file"
                  ref={profilePhotoInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={handleProfilePhotoUpload}
                />
                {/* Hidden signature input */}
                <input
                  type="file"
                  ref={profileSignatureInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={handleProfileSignatureUpload}
                />

                <div className="relative inline-block mx-auto mb-2 group">
                  {selectedDetailEmp.photoUrl ? (
                    <img
                      src={selectedDetailEmp.photoUrl}
                      alt={selectedDetailEmp.name}
                      onClick={() => setZoomedPhotoEmp(selectedDetailEmp)}
                      className="w-24 h-24 rounded-full object-cover border-3 border-white shadow-md cursor-pointer hover:scale-105 transition"
                      title="ছবি বড় করে দেখতে চাপুন"
                    />
                  ) : (
                    <div
                      onClick={() => profilePhotoInputRef.current?.click()}
                      className="w-24 h-24 rounded-full bg-blue-600 text-white text-3xl font-black flex items-center justify-center shadow-md cursor-pointer hover:bg-blue-700 transition"
                      title="ছবি যোগ করতে চাপুন"
                    >
                      {selectedDetailEmp.name.charAt(0)}
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => profilePhotoInputRef.current?.click()}
                    className="no-print absolute bottom-0 right-0 p-1.5 rounded-full bg-slate-900 text-white hover:bg-black shadow-md border-2 border-white cursor-pointer transition active:scale-90"
                    title="শ্রমিকের ছবি যুক্ত / পরিবর্তন করুন"
                  >
                    <Camera className="w-3.5 h-3.5 text-amber-400" />
                  </button>
                </div>

                <h3 className="text-base font-black text-slate-900">{selectedDetailEmp.name}</h3>
                <p className="text-xs text-slate-500">
                  {selectedDetailEmp.designation} • {selectedDetailEmp.department || 'সাধারণ'}
                </p>
                <div className="mt-1">
                  <span
                    className={`inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                      getStatusBadge(selectedDetailEmp.status).bg
                    }`}
                  >
                    {getStatusBadge(selectedDetailEmp.status).label}
                  </span>
                </div>

                {/* Quick actions for profile: photo, signature and contract letter */}
                <div className="mt-3 flex items-center justify-center gap-2 flex-wrap no-print">
                  <button
                    type="button"
                    onClick={() => profilePhotoInputRef.current?.click()}
                    className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-slate-300"
                    title="কম্পিউটার বা মোবাইল থেকে ছবি ফাইল আপলোড করুন"
                  >
                    <Camera className="w-3.5 h-3.5 text-blue-600" />
                    <span>{selectedDetailEmp.photoUrl ? 'ছবি ফাইল পরিবর্তন' : 'ছবি আপলোড'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePromptPhotoUrl}
                    className="py-1.5 px-3 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-sky-300"
                    title="ছবির সরাসরি অনলাইন লিংক (URL) দিন"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-sky-600" />
                    <span>ছবির লিংক (URL)</span>
                  </button>

                  {selectedDetailEmp.photoUrl && (
                    <>
                      <button
                        type="button"
                        onClick={() => setZoomedPhotoEmp(selectedDetailEmp)}
                        className="py-1.5 px-3 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-indigo-200"
                        title="ছবি বড় করে দেখুন"
                      >
                        <Eye className="w-3.5 h-3.5 text-indigo-600" />
                        <span>ছবি বড় করুন</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleRemoveProfilePhoto}
                        className="py-1.5 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-rose-200"
                        title="শ্রমিকের ছবি মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>ছবি সরান</span>
                      </button>
                    </>
                  )}

                  <button
                    type="button"
                    onClick={() => profileSignatureInputRef.current?.click()}
                    className="py-1.5 px-3 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-amber-300"
                    title="শ্রমিকের ডিজিটাল স্বাক্ষর আপলোড করুন (চুক্তিপত্র ও বরখাস্ত ফাইলে অটো বসবে)"
                  >
                    <FileSignature className="w-3.5 h-3.5 text-amber-700" />
                    <span>{selectedDetailEmp.signatureUrl ? 'স্বাক্ষর পরিবর্তন' : 'স্বাক্ষর যোগ'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setContractModalEmp(selectedDetailEmp)}
                    className="py-1.5 px-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95 border border-amber-600"
                    title="শ্রমিক নিয়োগ চুক্তিপত্র (A4 সাইজ) প্রিন্ট করুন"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>চুক্তিপত্র প্রিন্ট (A4 Contract Letter)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCredentialModalEmp(selectedDetailEmp)}
                    className="py-1.5 px-3.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                    title="এই শ্রমিকের ব্যক্তিগত প্রোফাইল লিংক ও পাসওয়ার্ড নিয়ন্ত্রণ করুন"
                  >
                    <Key className="w-3.5 h-3.5 text-indigo-200" />
                    <span>লগইন লিংক ও পাসওয়ার্ড</span>
                  </button>
                </div>
              </div>

              <div className="divide-y divide-slate-100 text-xs">
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">Worker ID</div>
                  <div className="w-2/3 font-semibold text-slate-900">{selectedDetailEmp.workerId}</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">মাসিক বেতন</div>
                  <div className="w-2/3 font-bold text-blue-700">{formatMoney(selectedDetailEmp.salary)} টাকা</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">প্রতি ঘণ্টা OT</div>
                  <div className="w-2/3 font-semibold text-slate-900">{formatMoney(selectedDetailEmp.otRate)} টাকা</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">যোগদানের তারিখ</div>
                  <div className="w-2/3 text-slate-800">{formatDateBn(selectedDetailEmp.joinDate)}</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">জন্ম তারিখ</div>
                  <div className="w-2/3 text-slate-800">{formatDateBn(selectedDetailEmp.birthDate)}</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">জাতীয় পরিচয়পত্র (NID)</div>
                  <div className="w-2/3 text-slate-800">{selectedDetailEmp.nid || '—'}</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">মোবাইল নম্বর</div>
                  <div className="w-2/3 text-slate-800">{selectedDetailEmp.mobile || '—'}</div>
                </div>
                <div className="flex p-3">
                  <div className="w-1/3 font-bold text-slate-600">ঠিকানা</div>
                  <div className="w-2/3 text-slate-800">{selectedDetailEmp.address || '—'}</div>
                </div>

                <div className="flex p-3 bg-indigo-50/50 items-center justify-between flex-wrap gap-2 border-t border-indigo-100">
                  <div className="w-1/3 font-bold text-indigo-900 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-indigo-600" />
                    <span>পোর্টাল লগইন পাসওয়ার্ড</span>
                  </div>
                  <div className="w-2/3 flex items-center justify-between">
                    <span className="font-mono font-black text-indigo-950 bg-white px-2 py-0.5 rounded border border-indigo-200 text-xs">
                      {selectedDetailEmp.portalPassword ||
                        (selectedDetailEmp.mobile ? selectedDetailEmp.mobile.replace(/[^0-9]/g, '').slice(-4) : '123456')}
                    </span>
                    <button
                      type="button"
                      onClick={() => setCredentialModalEmp(selectedDetailEmp)}
                      className="text-xs text-indigo-700 hover:text-indigo-900 font-bold underline cursor-pointer"
                    >
                      পাসওয়ার্ড ও লিংক পরিবর্তন →
                    </button>
                  </div>
                </div>

                <div className="flex p-3 bg-amber-50/40 items-center justify-between flex-wrap gap-2 border-t border-amber-100">
                  <div className="w-1/3 font-bold text-slate-700 flex items-center gap-1.5">
                    <FileSignature className="w-4 h-4 text-amber-600" />
                    <span>ডিজিটাল স্বাক্ষর</span>
                  </div>
                  <div className="w-2/3 flex items-center justify-between flex-wrap gap-2">
                    {selectedDetailEmp.signatureUrl ? (
                      <div className="flex items-center gap-2">
                        <div className="p-1 bg-white border border-amber-300 rounded shadow-2xs">
                          <img
                            src={selectedDetailEmp.signatureUrl}
                            alt="স্বাক্ষর"
                            className="h-8 max-w-[120px] object-contain"
                          />
                        </div>
                        <span className="text-[10px] text-emerald-800 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                          ✓ চুক্তিপত্র, বরখাস্ত ও পদত্যাগে স্বয়ংক্রিয় বসবে
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 italic">স্বাক্ষর যুক্ত নেই</span>
                        <span className="text-[10px] text-amber-800 font-semibold bg-amber-100/70 border border-amber-200 px-1.5 py-0.5 rounded">
                          আপলোড করতে পাশের বাটন চাপুন
                        </span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 no-print">
                      <button
                        type="button"
                        onClick={() => profileSignatureInputRef.current?.click()}
                        className="py-1 px-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer shadow-2xs active:scale-95"
                      >
                        <Upload className="w-3 h-3" />
                        <span>{selectedDetailEmp.signatureUrl ? 'স্বাক্ষর পরিবর্তন' : 'স্বাক্ষর আপলোড'}</span>
                      </button>
                      {selectedDetailEmp.signatureUrl && (
                        <button
                          type="button"
                          onClick={handleProfileSignatureRemove}
                          className="text-xs text-rose-600 hover:underline font-bold cursor-pointer"
                        >
                          মুছুন
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {selectedDetailEmp.status === 'resigned' && (
                  <>
                    <div className="flex p-3 bg-rose-50/50">
                      <div className="w-1/3 font-bold text-rose-800">রিজাইনের তারিখ</div>
                      <div className="w-2/3 font-bold text-rose-900">{formatDateBn(selectedDetailEmp.resignationDate)}</div>
                    </div>
                    <div className="flex p-3 bg-rose-50/50">
                      <div className="w-1/3 font-bold text-rose-800">পদত্যাগের কারণ</div>
                      <div className="w-2/3 text-rose-900">{selectedDetailEmp.resignationReason || '—'}</div>
                    </div>
                    <div className="flex p-3 bg-rose-50/50">
                      <div className="w-1/3 font-bold text-rose-800">ক্লিয়ারেন্স ও দেনা-পাওনা</div>
                      <div className="w-2/3 text-rose-900">
                        {selectedDetailEmp.finalSettlementPaid ? 'সম্পূর্ণ পরিশোধিত' : 'বকেয়া রয়েছে'}
                      </div>
                    </div>
                  </>
                )}

                {selectedDetailEmp.status === 'suspended' && (
                  <>
                    <div className="flex p-3 bg-amber-50/50">
                      <div className="w-1/3 font-bold text-amber-800">স্থগিতাদেশের তারিখ</div>
                      <div className="w-2/3 font-bold text-amber-900">{formatDateBn(selectedDetailEmp.suspensionDate || selectedDetailEmp.resignationDate)}</div>
                    </div>
                    <div className="flex p-3 bg-amber-50/50">
                      <div className="w-1/3 font-bold text-amber-800">স্থগিতাদেশের মেয়াদ</div>
                      <div className="w-2/3 text-amber-900">{selectedDetailEmp.suspensionDuration || '৭ কার্যদিবস (তদন্ত সাপেক্ষে)'}</div>
                    </div>
                    <div className="flex p-3 bg-amber-50/50">
                      <div className="w-1/3 font-bold text-amber-800">স্থগিতের কারণ</div>
                      <div className="w-2/3 text-amber-900">{selectedDetailEmp.suspensionReason || '—'}</div>
                    </div>
                  </>
                )}

                {selectedDetailEmp.status === 'terminated' && (
                  <>
                    <div className="flex p-3 bg-slate-100/70">
                      <div className="w-1/3 font-bold text-slate-800">বরখাস্তের কার্যকর তারিখ</div>
                      <div className="w-2/3 font-bold text-slate-900">{formatDateBn(selectedDetailEmp.terminationDate || selectedDetailEmp.resignationDate)}</div>
                    </div>
                    <div className="flex p-3 bg-slate-100/70">
                      <div className="w-1/3 font-bold text-slate-800">বরখাস্তের কারণ</div>
                      <div className="w-2/3 text-slate-900">{selectedDetailEmp.terminationReason || '—'}</div>
                    </div>
                    <div className="flex p-3 bg-slate-100/70">
                      <div className="w-1/3 font-bold text-slate-800">ক্লিয়ারেন্স ও পাওনা স্থিতি</div>
                      <div className="w-2/3 text-slate-900">
                        {selectedDetailEmp.finalSettlementPaid ? 'পরিশোধিত' : 'বকেয়া রয়েছে'}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Attendance & In/Out Time Dashboard inside Profile and Print */}
              <div className="p-4 border-t border-slate-200">
                <EmployeeAttendanceProfileView
                  employee={selectedDetailEmp}
                  records={attendanceRecords}
                  employees={employees}
                  showToast={showToast}
                  allowQuickMark={true}
                />
              </div>

              {/* Profile Bottom Actions */}
              <div className="p-3 bg-slate-50 flex items-center justify-end flex-wrap gap-2">
                {selectedDetailEmp.status === 'resigned' && (
                  <button
                    type="button"
                    onClick={() => {
                      setResignationLetterModalEmp(selectedDetailEmp);
                      onOpenResignationLetter?.(selectedDetailEmp);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center gap-1.5 cursor-pointer transition shadow-2xs active:scale-95"
                    title="১-ক্লিকে পদত্যাগ ফরম প্রিন্ট করুন"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>১-ক্লিক রিজাইন ফরম প্রিন্ট</span>
                  </button>
                )}
                {selectedDetailEmp.status === 'suspended' && (
                  <button
                    type="button"
                    onClick={() => {
                      setSuspensionNoticeModalEmp(selectedDetailEmp);
                      onOpenSuspensionNotice?.(selectedDetailEmp);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-black text-xs flex items-center gap-1.5 cursor-pointer transition shadow-2xs active:scale-95"
                    title="১-ক্লিকে সাময়িক স্থগিতাদেশ নোটিশ প্রিন্ট করুন"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>১-ক্লিক স্থগিত নোটিশ প্রিন্ট</span>
                  </button>
                )}
                {selectedDetailEmp.status === 'terminated' && (
                  <button
                    type="button"
                    onClick={() => {
                      setTerminationNoticeModalEmp(selectedDetailEmp);
                      onOpenTerminationNotice?.(selectedDetailEmp);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-black text-white font-black text-xs flex items-center gap-1.5 cursor-pointer transition shadow-2xs active:scale-95"
                    title="১-ক্লিকে চাকরি হতে অব্যাহতি ও বরখাস্ত আদেশ প্রিন্ট করুন"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>১-ক্লিক অব্যাহতি পত্র প্রিন্ট</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setNoticeTargetEmp(selectedDetailEmp);
                    setNoticeModalOpen(true);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold border border-indigo-200 text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                  title="এই শ্রমিককে ব্যক্তিগত নোটিশ পাঠান"
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>নোটিশ পাঠান</span>
                </button>
                <button
                  type="button"
                  onClick={() => onOpenResignationModal(selectedDetailEmp)}
                  className="px-3 py-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 font-bold border border-rose-200 text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                >
                  <UserX className="w-3.5 h-3.5" />
                  <span>রিজাইন আপডেট</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleEditEmployee(selectedDetailEmp)}
                  className="px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 font-bold border border-amber-200 text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>এডিট</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteEmployee(selectedDetailEmp)}
                  className="px-3 py-1.5 rounded-lg bg-red-50 text-red-700 hover:bg-red-100 font-bold border border-red-200 text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                  <span>ডিলিট</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCopyEmployee(selectedDetailEmp)}
                  className="px-3 py-1.5 rounded-lg bg-white text-slate-700 hover:bg-slate-100 font-semibold border border-slate-200 text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>কপি</span>
                </button>
                <button
                  type="button"
                  onClick={() => setContractModalEmp(selectedDetailEmp)}
                  className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer transition active:scale-95 shadow-xs border border-amber-600"
                  title="শ্রমিক নিয়োগ চুক্তিপত্র (A4 সাইজ) প্রিন্ট করুন"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>চুক্তিপত্র (Contract Letter)</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintProfile}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-black font-semibold text-xs flex items-center gap-1 cursor-pointer transition active:scale-95"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>প্রিন্ট প্রোফাইল</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 5: TELEGRAM SETTINGS ================= */}
      {activeTab === 'telegram' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          {/* Sub Navigation for Password & Settings */}
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 flex-wrap">
            <button
              type="button"
              onClick={() => handleTabChange('password')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-600" />
              <span>🔐 অ্যাডমিন পাসওয়ার্ড</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('telegram')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-blue-600 text-white shadow-xs transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>📱 Telegram Bot</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('sms')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
              <span>💬 Auto SMS (Bulk)</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('factory')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-teal-600" />
              <span>🏢 কারখানার তথ্য ও চুক্তি</span>
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <Send className="w-4 h-4 text-blue-600" />
              <span>Telegram Bot Settings</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-xs text-blue-900 leading-relaxed space-y-1.5">
            <div className="font-bold flex items-center gap-1.5 text-blue-950">
              <span>💡 Telegram Bot ও Web App ব্যবহারের নিয়মাবলী:</span>
            </div>
            <p>
              • <b>টেলিগ্রাম বটে লিংক অ্যাড:</b> নিচের "ওয়েব অ্যাপ লিংক" কপি করে @BotFather-এ গিয়ে আপনার বটের Menu Button বা Inline WebApp হিসেবে যুক্ত করতে পারেন।
            </p>
            <p>
              • <b>প্রিন্টিং সংক্রান্ত তথ্য:</b> মোবাইলের টেলিগ্রাম অ্যাপ ব্রাউজারে সিস্টেম প্রিন্ট সাপোর্ট করে না। তাই ব্যবহারকারীরা অ্যাপের উপরে থাকা <b>"ব্রাউজারে খুলুন"</b> বাটনে ক্লিক করলে সরাসরি Chrome/Safari দিয়ে ব্লুটুথ ও থার্মাল প্রিন্টারে প্রিন্ট করতে পারবেন।
            </p>
            <p>
              • <b>কর্মচারী ডিলিট ও ম্যানেজমেন্ট:</b> এখন টেলিগ্রাম বট বা যে কোনো সংযোগে কর্মী ডিলিট ও বেতন খাতা তাৎক্ষণিকভাবে আপডেট হবে।
            </p>
          </div>

          <div className="space-y-3 text-xs">
            {/* User App Link for Employees */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>১. ইউজার অ্যাপ লিংক (সাধারণ কর্মীদের বেতন দেখার জন্য)</span>
                </label>
                <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-bold border border-emerald-200">
                  নিরাপদ (কোনো এডমিন লিংক নেই)
                </span>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={typeof window !== 'undefined' ? window.location.origin : ''}
                  className="w-full py-2.5 px-3 bg-slate-100 border border-slate-300 rounded-xl text-slate-800 font-mono text-[11px] select-all cursor-text"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      navigator.clipboard.writeText(window.location.origin);
                      showToast('ইউজার অ্যাপ লিংক কপি হয়েছে (বট বা কর্মীদের দিন)');
                    }
                  }}
                  className="px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5 shrink-0 transition cursor-pointer shadow-xs"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>কপি</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                টেলিগ্রাম বট বা কর্মীদের মেসেজে এই লিংকটি দিন। কর্মীরা এতে শুধু বেতন হিসাব করতে পারবে, নিচে কোনো এডমিন লিংক বা ট্যাব থাকবে না।
              </p>
            </div>

            {/* Admin Panel Direct Link */}
            <div className="pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  <span>২. এডমিন প্যানেল সরাসরি লিংক (মালিক/এইচআর ব্যবহারের জন্য)</span>
                </label>
                <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full font-bold border border-amber-200">
                  পাসওয়ার্ড সুরক্ষিত
                </span>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={typeof window !== 'undefined' ? `${window.location.origin}/?mode=admin` : ''}
                  className="w-full py-2.5 px-3 bg-slate-100 border border-slate-300 rounded-xl text-slate-800 font-mono text-[11px] select-all cursor-text"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      navigator.clipboard.writeText(`${window.location.origin}/?mode=admin`);
                      showToast('এডমিন লিংক কপি করা হয়েছে');
                    }
                  }}
                  className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white font-bold flex items-center gap-1.5 shrink-0 transition cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>কপি</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                আপনার ব্রাউজারে বুকমার্ক করে রাখতে পারেন। সরাসরি এডমিন প্যানেল ওপেন হবে।
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Telegram Bot Token
              </label>
              <div className="relative">
                <input
                  type={showTgToken ? 'text' : 'password'}
                  value={tgSettings.botToken}
                  onChange={(e) => setTgSettings({ ...tgSettings, botToken: e.target.value })}
                  placeholder="যেমন: 123456789:ABCdefGhIJKlmNoPQRstuVWxyz"
                  className="w-full py-2.5 pl-3 pr-10 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setShowTgToken(!showTgToken)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showTgToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Telegram Chat ID
              </label>
              <input
                type="text"
                value={tgSettings.chatId}
                onChange={(e) => setTgSettings({ ...tgSettings, chatId: e.target.value })}
                placeholder="যেমন: 987654321 বা @channel_username"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={handleSaveTelegram}
                className="py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-xs"
              >
                সেটিংস Save করুন
              </button>

              <button
                type="button"
                disabled={tgTesting}
                onClick={handleTestTelegram}
                className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold transition shadow-xs flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{tgTesting ? 'পরীক্ষা হচ্ছে...' : 'Telegram Test'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 6: AUTO MESSAGE / SMS ================= */}
      {activeTab === 'sms' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4">
          {/* Sub Navigation for Password & Settings */}
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 flex-wrap">
            <button
              type="button"
              onClick={() => handleTabChange('password')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-600" />
              <span>🔐 অ্যাডমিন পাসওয়ার্ড</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('telegram')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-blue-600" />
              <span>📱 Telegram Bot</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('sms')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-indigo-600 text-white shadow-xs transition cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>💬 Auto SMS (Bulk)</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('factory')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-teal-600" />
              <span>🏢 কারখানার তথ্য ও চুক্তি</span>
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>Auto Message / SMS (BulkSMSBD)</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setSmsMode('single')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border ${
                smsMode === 'single'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              একজন শ্রমিককে SMS
            </button>
            <button
              type="button"
              onClick={() => setSmsMode('bulk')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border ${
                smsMode === 'bulk'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              সকল শ্রমিককে নোটিশ (Bulk)
            </button>
          </div>

          {/* Single SMS Form */}
          {smsMode === 'single' ? (
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">শ্রমিক নির্বাচন করুন</label>
                <select
                  value={singleSmsEmpId}
                  onChange={(e) => setSingleSmsEmpId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                >
                  <option value="">-- শ্রমিক নির্বাচন করুন --</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} — {emp.mobile || 'মোবাইল নেই'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মেসেজ লিখুন</label>
                <textarea
                  value={singleSmsMsg}
                  onChange={(e) => setSingleSmsMsg(e.target.value)}
                  rows={3}
                  placeholder="আপনার মেসেজ লিখুন..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <button
                type="button"
                disabled={isSendingSms}
                onClick={handleSendSingleSMS}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold transition shadow-xs"
              >
                {isSendingSms ? 'পাঠানো হচ্ছে...' : 'SMS পাঠান'}
              </button>
            </div>
          ) : (
            <div className="space-y-3 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-700">প্রাপক তালিকা নির্বাচন</label>
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedBulkEmpIds(employees.map((e) => e.id))}
                      className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200"
                    >
                      সব নির্বাচন
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedBulkEmpIds([])}
                      className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200"
                    >
                      সব বাদ
                    </button>
                  </div>
                </div>

                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl p-2 space-y-1 bg-slate-50">
                  {employees.map((emp) => (
                    <label
                      key={emp.id}
                      className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white cursor-pointer select-none"
                    >
                      <input
                        type="checkbox"
                        checked={selectedBulkEmpIds.includes(emp.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedBulkEmpIds([...selectedBulkEmpIds, emp.id]);
                          } else {
                            setSelectedBulkEmpIds(selectedBulkEmpIds.filter((id) => id !== emp.id));
                          }
                        }}
                        className="w-3.5 h-3.5 text-blue-600 rounded"
                      />
                      <div className="flex-1 text-[11px]">
                        <b>{emp.name}</b> <span className="text-slate-500">({emp.mobile || 'মোবাইল নেই'})</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">নোটিশ বার্তা</label>
                <textarea
                  value={bulkSmsMsg}
                  onChange={(e) => setBulkSmsMsg(e.target.value)}
                  rows={3}
                  placeholder="যেমন: জরুরি নোটিশ: আগামীকাল কারখানা সকাল ৮টায় শুরু হবে।"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <button
                type="button"
                disabled={isSendingSms}
                onClick={handleSendBulkSMS}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold transition shadow-xs"
              >
                {isSendingSms ? 'পাঠানো হচ্ছে...' : `নির্বাচিত ${selectedBulkEmpIds.length} জনকে SMS পাঠান`}
              </button>
            </div>
          )}

          {/* BulkSMSBD API Parameters Box */}
          <div className="pt-3 border-t border-slate-100 text-xs space-y-2.5">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-blue-600" />
              <span>BulkSMSBD API সেটিংস</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-600 mb-0.5">API URL</label>
                <input
                  type="text"
                  value={smsSettings.apiUrl}
                  onChange={(e) => setSmsSettingsState({ ...smsSettings, apiUrl: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-0.5">API Key</label>
                <input
                  type="password"
                  value={smsSettings.apiKey}
                  onChange={(e) => setSmsSettingsState({ ...smsSettings, apiKey: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-0.5">Sender ID</label>
                <input
                  type="text"
                  value={smsSettings.senderId}
                  onChange={(e) => setSmsSettingsState({ ...smsSettings, senderId: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-0.5">HTTP Method</label>
                <select
                  value={smsSettings.method}
                  onChange={(e) =>
                    setSmsSettingsState({ ...smsSettings, method: e.target.value as 'GET' | 'POST' })
                  }
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="GET">GET</option>
                  <option value="POST">POST</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSaveSmsSettings}
              className="py-2 px-4 rounded-lg bg-slate-800 text-white font-bold hover:bg-slate-900 transition"
            >
              SMS API Settings Save
            </button>
          </div>
        </div>
      )}

      {/* ================= TAB 7: PASSWORD & LOGOUT ================= */}
      {activeTab === 'password' && (
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-4 max-w-lg mx-auto">
          {/* Sub Navigation for Password & Settings */}
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 flex-wrap">
            <button
              type="button"
              onClick={() => handleTabChange('password')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-amber-600 text-white shadow-xs transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>🔐 অ্যাডমিন পাসওয়ার্ড</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('telegram')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-blue-600" />
              <span>📱 Telegram Bot</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('sms')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
              <span>💬 Auto SMS (Bulk)</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('factory')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-teal-600" />
              <span>🏢 কারখানার তথ্য ও চুক্তি</span>
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <KeyRound className="w-4 h-4 text-amber-600" />
              <span>Admin Password পরিবর্তন</span>
            </div>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">বর্তমান পাসওয়ার্ড *</label>
              <input
                type="password"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">নতুন পাসওয়ার্ড *</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="কমপক্ষে ৬ অক্ষর"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">নতুন পাসওয়ার্ড নিশ্চিত করুন *</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition shadow-xs"
            >
              পাসওয়ার্ড পরিবর্তন করুন
            </button>
          </form>

          <div className="pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={handleLogout}
              className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold transition shadow-xs flex items-center justify-center gap-2 text-xs"
            >
              <LogOut className="w-4 h-4" />
              <span>Admin Logout</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= TAB 9: FACTORY & AGREEMENT SETTINGS ================= */}
      {activeTab === 'factory' && (
        <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-slate-200 space-y-5 max-w-2xl mx-auto">
          {/* Sub Navigation for Settings */}
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 flex-wrap">
            <button
              type="button"
              onClick={() => handleTabChange('password')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-600" />
              <span>🔐 অ্যাডমিন পাসওয়ার্ড</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('telegram')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-blue-600" />
              <span>📱 Telegram Bot</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('sms')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-purple-600" />
              <span>💬 Auto SMS (Bulk)</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('factory')}
              className="py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-teal-700 text-white shadow-xs transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>🏢 কারখানার তথ্য ও চুক্তি</span>
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-teal-700" />
                <span>কারখানার পরিচিতি ও চুক্তিপত্র (Agreement) সেটিংস</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                এখানে দেওয়া কারখানার নাম, ঠিকানা ও ফোন নম্বর স্বয়ংক্রিয়ভাবে সকল চুক্তিপত্র ও অফিশিয়াল নথিতে প্রদর্শিত হবে।
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveFactoryProfile} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  কারখানার নাম (বাংলায়) *
                </label>
                <input
                  type="text"
                  required
                  value={facName}
                  onChange={(e) => setFacName(e.target.value)}
                  placeholder="যেমন: টেক্স ওয়ার অ্যাপারেলস"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Factory Name (in English)
                </label>
                <input
                  type="text"
                  value={facNameEn}
                  onChange={(e) => setFacNameEn(e.target.value)}
                  placeholder="e.g. TexWare Apparels Ltd."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                কারখানার পূর্ণাঙ্গ ঠিকানা (বাংলায়) *
              </label>
              <textarea
                required
                rows={2}
                value={facAddress}
                onChange={(e) => setFacAddress(e.target.value)}
                placeholder="যেমন: কারখানা কমপ্লেক্স, রোড # ০৩, কোনাবাড়ী বিসিক শিল্প এলাকা, গাজীপুর, ঢাকা।"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs leading-relaxed focus:ring-2 focus:ring-teal-500"
              />
              <span className="text-[10.5px] text-slate-400">এই ঠিকানা চুক্তিপত্রের শীর্ষে লেটারহেডে মুদ্রিত হবে।</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  যোগাযোগের ফোন নম্বর (Phone) *
                </label>
                <input
                  type="text"
                  required
                  value={facPhone}
                  onChange={(e) => setFacPhone(e.target.value)}
                  placeholder="যেমন: +৮৮০১৭১২-৩৪৫৬৭৮, +৮৮০১৯১১-২২৩৩৪৪"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  অফিশিয়াল ইমেইল (Email)
                </label>
                <input
                  type="email"
                  value={facEmail}
                  onChange={(e) => setFacEmail(e.target.value)}
                  placeholder="info@texwareapparels.com"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            {/* ================= CONTRACT RULES & AGREEMENT CLAUSES ================= */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-gradient-to-r from-teal-50 to-slate-50 p-3 rounded-xl border border-teal-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-teal-700 text-white flex items-center justify-center font-black shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <span>চুক্তিপত্রের শর্তাবলি ও কারখানার নিয়ম-কানুন</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-bold border border-teal-300">
                        {toBengaliNumber(facContractRules.length)} টি শর্ত সক্রিয়
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      এখানে যেকোনো শর্ত সম্পাদন, নতুন নিয়ম যোগ অথবা মুছতে পারেন। A4 চুক্তিপত্রে সরাসরি মুদ্রিত হবে।
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      if (!isBulkRulesMode) {
                        setBulkRulesText(facContractRules.join('\n'));
                      } else {
                        const parsed = bulkRulesText
                          .split('\n')
                          .map((l) => l.trim().replace(/^\d+[\.\-\)]\s*/, ''))
                          .filter((l) => l.length > 0);
                        if (parsed.length > 0) {
                          setFacContractRules(parsed);
                        }
                      }
                      setIsBulkRulesMode(!isBulkRulesMode);
                    }}
                    className="py-1 px-2.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-[11px] transition cursor-pointer"
                  >
                    {isBulkRulesMode ? '✓ প্রতিটি শর্ত আলাদা ভিউ' : '📝 বালক টেক্সট ভিউ (একক বক্স)'}
                  </button>

                  <button
                    type="button"
                    onClick={handleResetContractRules}
                    className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                    title="ডিফল্ট ৮টি শর্ত ফিরিয়ে আনুন"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>ডিফল্ট ৮টি শর্ত</span>
                  </button>
                </div>
              </div>

              {isBulkRulesMode ? (
                /* Bulk Textarea Editor */
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                    <span>প্রতি লাইনে একটি করে শর্ত লিখুন বা পেস্ট করুন:</span>
                    <span className="text-[10px] text-slate-400">প্রতিটি লাইন চুক্তিপত্রে আলাদা শর্ত হিসেবে প্রদর্শিত হবে</span>
                  </div>
                  <textarea
                    rows={8}
                    value={bulkRulesText}
                    onChange={(e) => setBulkRulesText(e.target.value)}
                    placeholder="১. এই চুক্তি অনির্দিষ্টকালের জন্য...&#10;২. প্রতিদিন ৮ ঘণ্টা কাজ করতে হবে..."
                    className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs leading-relaxed font-sans focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              ) : (
                /* Clause-by-Clause Cards */
                <div className="space-y-2">
                  <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                    {facContractRules.map((rule, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 bg-slate-50 hover:bg-white rounded-xl border border-slate-200 hover:border-teal-300 transition-all flex items-start gap-2 shadow-2xs group"
                      >
                        <div className="flex flex-col items-center gap-1 shrink-0 pt-0.5">
                          <span className="w-6 h-6 rounded-lg bg-teal-100 text-teal-900 font-black text-xs flex items-center justify-center border border-teal-300">
                            {toBengaliNumber(idx + 1)}
                          </span>
                          <div className="flex flex-col gap-0.5 opacity-60 group-hover:opacity-100 transition">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => handleMoveContractRule(idx, 'up')}
                              title="উপরে নিন"
                              className="p-0.5 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              disabled={idx === facContractRules.length - 1}
                              onClick={() => handleMoveContractRule(idx, 'down')}
                              title="নিচে নিন"
                              className="p-0.5 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>
                        </div>

                        <div className="flex-1">
                          <textarea
                            rows={2}
                            value={rule}
                            onChange={(e) => handleUpdateContractRule(idx, e.target.value)}
                            className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs leading-relaxed focus:ring-1 focus:ring-teal-500 outline-none resize-y"
                            placeholder={`শর্ত #${toBengaliNumber(idx + 1)} লিখুন...`}
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteContractRule(idx)}
                          title="এই শর্তটি মুছুন"
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition shrink-0 cursor-pointer self-start"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Add New Rule Box */}
                  <div className="p-3 bg-teal-50/60 rounded-xl border border-dashed border-teal-300 space-y-2">
                    <label className="block font-bold text-teal-950 text-xs">
                      + নতুন নিয়ম বা শর্ত যোগ করুন:
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newRuleInput}
                        onChange={(e) => setNewRuleInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddContractRule();
                          }
                        }}
                        placeholder="যেমন: কারখানায় মোবাইল ফোন ব্যবহার সংক্রান্ত বা বিশেষ নিয়ম..."
                        className="flex-1 p-2 bg-white border border-teal-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-teal-500 outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleAddContractRule}
                        className="py-2 px-3.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-1 transition shadow-xs cursor-pointer active:scale-95 shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>শর্ত যোগ করুন</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Worker Declaration text */}
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <label className="block font-bold text-slate-800 text-xs mb-1">
                  শ্রমিকের ঘোষণাবাক্য (Worker's Declaration Text):
                </label>
                <input
                  type="text"
                  value={facContractDeclaration}
                  onChange={(e) => setFacContractDeclaration(e.target.value)}
                  placeholder="আমি উক্ত কারখানার সকল নিয়ম মেনে কাজ করবো।"
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-teal-500 outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  এটি চুক্তিপত্রের শর্তাবলির নিচে কোটেশন চিহ্নের ভেতরে মুদ্রিত হবে।
                </span>
              </div>
            </div>

            <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl flex items-start gap-2.5 text-teal-950">
              <CheckCircle2 className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
              <div className="space-y-0.5 text-[11.5px]">
                <strong className="block text-teal-900">স্বয়ংক্রিয় লাইভ সিঙ্ক:</strong>
                <span>
                  এখানে যেকোনো পরিবর্তন সংরক্ষণ করলে তা তাৎক্ষণিকভাবে সকল কর্মচারীর A4 চুক্তিপত্রে (Agreement Form) যুক্ত হয়ে যাবে।
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  setFacName(DEFAULT_FACTORY_SETTINGS.name);
                  setFacNameEn(DEFAULT_FACTORY_SETTINGS.nameEn || '');
                  setFacAddress(DEFAULT_FACTORY_SETTINGS.address);
                  setFacPhone(DEFAULT_FACTORY_SETTINGS.phone);
                  setFacEmail(DEFAULT_FACTORY_SETTINGS.email || '');
                  setFacContractRules(DEFAULT_CONTRACT_RULES);
                  setFacContractDeclaration(DEFAULT_CONTRACT_DECLARATION);
                  setBulkRulesText(DEFAULT_CONTRACT_RULES.join('\n'));
                  showToast('ডিফল্ট কারখানার তথ্য ও ৮টি শর্ত রিস্টোর করা হয়েছে');
                }}
                className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>ডিফল্ট তথ্য ও ৮টি শর্ত রিসেট</span>
              </button>

              <button
                type="submit"
                disabled={isSavingFac}
                className="py-2.5 px-6 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs transition shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingFac ? 'সংরক্ষণ হচ্ছে...' : 'কারখানার তথ্য ও চুক্তিপত্র Save করুন'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ================= TAB 10: JOB APPLICATIONS & PENDING APPLICANTS ================= */}
      {activeTab === 'applications' && (
        <JobApplicationsAdminTab
          existingEmployees={employees}
          onOpenContractLetter={(emp) => setContractModalEmp(emp)}
          onOpenNewApplicationForm={() => setShowDirectAppForm(true)}
          showToast={showToast}
        />
      )}

      {/* Modal / Overlay for Filling Job Application Form from Admin */}
      {showDirectAppForm && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl my-auto overflow-hidden border border-slate-200 max-h-[96vh] flex flex-col">
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100">
              <JobApplicationForm
                onBackToApp={() => setShowDirectAppForm(false)}
                showToast={showToast}
                isStandalone={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* ================= EMPLOYEE DELETE CONFIRMATION MODAL ================= */}
      {deleteConfirmEmp && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">
                কর্মচারী মুছে ফেলতে চান?
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                আপনি কি নিশ্চিত যে <b>"{deleteConfirmEmp.name}"</b> (ID: {deleteConfirmEmp.workerId})-কে ডাটাবেজ থেকে স্থায়ীভাবে মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।
              </p>
            </div>

            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-left text-[11px] text-rose-800 space-y-1">
              <div>• নাম: <b>{deleteConfirmEmp.name}</b></div>
              <div>• পদবি: {deleteConfirmEmp.designation}</div>
              <div>• বিভাগ: {deleteConfirmEmp.department || 'সাধারণ'}</div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeleteConfirmEmp(null)}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
              >
                বাতিল করুন
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={confirmExecuteDelete}
                className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, মুছে ফেলুন'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= SALARY RECORD DELETE CONFIRMATION MODAL ================= */}
      {deleteSalaryRecordTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">
                বেতন রেকর্ড মুছে ফেলতে চান?
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                আপনি কি নিশ্চিত যে <b>"{deleteSalaryRecordTarget.employeeName}"</b>-এর <b>{deleteSalaryRecordTarget.month}</b> মাসের বেতন রেকর্ড মুছে ফেলতে চান?
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left text-[11px] text-slate-700 space-y-1">
              <div>• কর্মী: <b>{deleteSalaryRecordTarget.employeeName}</b> ({deleteSalaryRecordTarget.workerId})</div>
              <div>• মাস: {deleteSalaryRecordTarget.month} {deleteSalaryRecordTarget.year}</div>
              <div>• পরিশোধিত: {formatMoney(deleteSalaryRecordTarget.paidAmount)} ৳ ({deleteSalaryRecordTarget.paymentMethod})</div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteSalaryRecordTarget(null)}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={confirmExecuteDeleteSalaryRecord}
                className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হ্যাঁ, মুছুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= SALARY RECORD EDIT MODAL ================= */}
      {editingSalaryRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                  <Edit className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    শ্রমিকের বেতন হিসাব সম্পাদন (Edit Salary)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {editingSalaryRecord.employeeName} (ID: {editingSalaryRecord.workerId}) — {editingSalaryRecord.month} {editingSalaryRecord.year}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingSalaryRecord(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEditedSalaryRecord} className="space-y-3 text-xs text-slate-800">
              {/* Row 1: Basic Salary, Total Days, Present Days */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">মূল বেতন (৳)</label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={editRecBasicSalary}
                    onChange={(e) => setEditRecBasicSalary(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">মোট কার্যদিবস</label>
                  <input
                    type="number"
                    min={1}
                    max={31}
                    required
                    value={editRecTotalDays}
                    onChange={(e) => setEditRecTotalDays(Number(e.target.value) || 26)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">উপস্থিত দিন</label>
                  <input
                    type="number"
                    min={0}
                    max={editRecTotalDays}
                    required
                    value={editRecPresentDays}
                    onChange={(e) => setEditRecPresentDays(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-blue-700 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Row 2: OT Hours, OT Rate, Bonus */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">ওভারটাইম ঘণ্টা</label>
                  <input
                    type="number"
                    min={0}
                    step={0.5}
                    value={editRecOtHours}
                    onChange={(e) => setEditRecOtHours(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">ওটি দর (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={editRecOtRate}
                    onChange={(e) => setEditRecOtRate(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">বোনাস (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={editRecBonus}
                    onChange={(e) => setEditRecBonus(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-amber-700 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Row 3: Advance, Deduction, Deduction Reason */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">অগ্রিম কর্তন (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={editRecAdvance}
                    onChange={(e) => setEditRecAdvance(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-rose-700 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">অন্যান্য কর্তন (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={editRecDeduction}
                    onChange={(e) => setEditRecDeduction(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-rose-700 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">কর্তনের কারণ</label>
                  <input
                    type="text"
                    value={editRecDeductionReason}
                    onChange={(e) => setEditRecDeductionReason(e.target.value)}
                    placeholder="যেমন: জরিমানা"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Row 4: Net Payable & Paid Amount & Auto Due */}
              <div className="grid grid-cols-3 gap-2.5 p-2.5 bg-blue-50/60 rounded-xl border border-blue-200">
                <div>
                  <label className="block text-[11px] font-black text-blue-900 mb-1">সর্বমোট নিট বেতন (৳)</label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={editRecNetPayable}
                    onChange={(e) => setEditRecNetPayable(Number(e.target.value) || 0)}
                    className="w-full p-2 bg-white border border-blue-300 rounded-lg font-black text-blue-950 text-sm focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black text-emerald-900 mb-1">প্রদত্ত টাকা (Paid) ৳</label>
                  <input
                    type="number"
                    min={0}
                    value={editRecPaidAmount}
                    onChange={(e) => {
                      const paid = Number(e.target.value) || 0;
                      setEditRecPaidAmount(paid);
                      if (paid >= editRecNetPayable && editRecNetPayable > 0) {
                        setEditRecPaymentStatus('paid');
                      } else if (paid > 0) {
                        setEditRecPaymentStatus('partial');
                      }
                    }}
                    className="w-full p-2 bg-white border border-emerald-300 rounded-lg font-black text-emerald-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black text-rose-900 mb-1">বকেয়া টাকা (Due) ৳</label>
                  <div className="p-2 bg-white border border-rose-300 rounded-lg font-black text-rose-700 text-sm">
                    {formatMoney(Math.max(0, editRecNetPayable - editRecPaidAmount))} ৳
                  </div>
                </div>
              </div>

              {/* Row 5: Payment Method & Payment Status */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={editRecPaymentMethod}
                    onChange={(e) => setEditRecPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="cash">💵 ক্যাশ (নগদ)</option>
                    <option value="bkash">📱 বিকাশ (bKash)</option>
                    <option value="nagad">📲 নগদ (Nagad)</option>
                    <option value="rocket">🟣 রকেট (Rocket)</option>
                    <option value="bank">🏦 ব্যাংক (Bank)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">পরিশোধ স্ট্যাটাস</label>
                  <select
                    value={editRecPaymentStatus}
                    onChange={(e) => setEditRecPaymentStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="pending">⏳ পেন্ডিং (Pending)</option>
                    <option value="paid">✓ সম্পূর্ণ পরিশোধিত (Paid)</option>
                    <option value="partial">⌛ আংশিক পরিশোধ (Partial)</option>
                    <option value="due">🔴 বাকী (Due)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">মন্তব্য (Note)</label>
                <input
                  type="text"
                  value={editRecNote}
                  onChange={(e) => setEditRecNote(e.target.value)}
                  placeholder="যেমন: ছুটির সমন্বয় অথবা স্পেশাল অনুমতি"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingSalaryRecord(null)}
                  className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isEditingSalarySaving}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isEditingSalarySaving ? 'সংরক্ষণ হচ্ছে...' : 'হিসাব সংরক্ষণ করুন'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= 1-CLICK MONTH-BASED SALARY BATCH DELETE MODAL ================= */}
      {showBatchDeleteModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">
                মাস অনুযায়ী সবার হিসাব এক ক্লিকে মুছুন
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                যে মাসের সকল শ্রমিকের বেতন হিসাব এক ক্লিকে মুছে ফেলতে চান, সেই মাস ও বছর নির্বাচন করুন:
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">মাস নির্বাচন</label>
                <select
                  value={batchDeleteMonth}
                  onChange={(e) => setBatchDeleteMonth(e.target.value)}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-800 focus:ring-2 focus:ring-rose-500"
                >
                  {BENGALI_MONTHS.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">বছর নির্বাচন</label>
                <select
                  value={batchDeleteYear}
                  onChange={(e) => setBatchDeleteYear(Number(e.target.value))}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-800 focus:ring-2 focus:ring-rose-500"
                >
                  {[2024, 2025, 2026, 2027, 2028].map((y) => (
                    <option key={y} value={y}>{toBengaliNumber(y)}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-left text-xs text-rose-800 space-y-1">
              <div className="font-bold flex items-center justify-between">
                <span>বিদ্যমান রেকর্ড সংখ্যা:</span>
                <span className="text-sm font-black text-rose-950 bg-rose-100 px-2 py-0.5 rounded-md">
                  {toBengaliNumber(recordsInSelectedBatchMonth.length)} জন
                </span>
              </div>
              <p className="text-[11px] text-rose-700 mt-1">
                ⚠️ সতর্কতা: এই অ্যাকশনটি নিশ্চিত করলে {batchDeleteMonth} {toBengaliNumber(batchDeleteYear)} সালের সকল শ্রমিকের বেতন হিসাব স্থায়ীভাবে ডাটাবেজ থেকে মুছে যাবে।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                disabled={isBatchDeleting}
                onClick={() => setShowBatchDeleteModal(false)}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
              >
                বাতিল করুন
              </button>
              <button
                type="button"
                disabled={isBatchDeleting || recordsInSelectedBatchMonth.length === 0}
                onClick={handleExecuteBatchDeleteByMonth}
                className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {isBatchDeleting
                    ? 'মুছে ফেলা হচ্ছে...'
                    : recordsInSelectedBatchMonth.length === 0
                    ? 'কোনো রেকর্ড নেই'
                    : `এক ক্লিকে মুছুন (${toBengaliNumber(recordsInSelectedBatchMonth.length)} টি)`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= 1-CLICK A4 MASTER PAYROLL & ATTENDANCE SHEET MODAL ================= */}
      {showMasterA4Modal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex flex-col p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-7xl w-full mx-auto my-auto shadow-2xl border border-slate-300 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="px-5 py-3.5 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black flex items-center gap-2">
                    <span>A4 মাস্টার বেতন ও হাজিরা শিট প্রিন্ট প্রিভিউ</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400 text-slate-950">
                      A4 Landscape Format
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300">
                    সকল শ্রমিকের উপস্থিতি, অনুপস্থিতি, ওটি ঘণ্টা ও টাকা, হাজিরা বোনাস ও স্বাক্ষর কলামসহ ফ্যাক্টরি পে-রোল
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintMasterA4Sheet}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-md transition cursor-pointer active:scale-95"
                >
                  <Printer className="w-4 h-4 text-slate-950" />
                  <span>🖨️ এখনই প্রিন্ট করুন (A4)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowMasterA4Modal(false)}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  বন্ধ করুন ✕
                </button>
              </div>
            </div>

            {/* Filter & Customization Toolbar */}
            <div className="p-3 bg-slate-50 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-6 gap-2.5 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">মাস</label>
                <select
                  value={masterA4Month}
                  onChange={(e) => setMasterA4Month(e.target.value)}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">সকল মাস (সব রেকর্ড)</option>
                  {BENGALI_MONTHS.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">বছর</label>
                <select
                  value={masterA4Year}
                  onChange={(e) => setMasterA4Year(Number(e.target.value))}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  {[2024, 2025, 2026, 2027, 2028].map((y) => (
                    <option key={y} value={y}>{toBengaliNumber(y)}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">সেকশন / বিভাগ</label>
                <select
                  value={masterA4Dept}
                  onChange={(e) => setMasterA4Dept(e.target.value)}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">সকল সেকশন</option>
                  {availableDepartments.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">কর্মী স্ট্যাটাস</label>
                <select
                  value={masterA4Status}
                  onChange={(e) => setMasterA4Status(e.target.value as 'active' | 'all')}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="active">শুধুমাত্র কর্মরত (Active)</option>
                  <option value="all">সকল কর্মী (All)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">মাসের মোট দিন</label>
                <input
                  type="number"
                  min={1}
                  max={31}
                  value={masterTotalDays}
                  onChange={(e) => setMasterTotalDays(Math.max(1, Number(e.target.value) || 26))}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">ডিফল্ট হাজিরা বোনাস</label>
                <input
                  type="number"
                  min={0}
                  step={50}
                  value={masterDefaultBonus}
                  onChange={(e) => setMasterDefaultBonus(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                  placeholder="যেমন: ৫০০ ৳"
                />
              </div>
            </div>

            {/* Paper Preview Area (Interactive on screen) */}
            <div className="p-3 sm:p-5 bg-slate-200 overflow-x-auto max-h-[68vh]">
              <div
                ref={masterA4SheetPrintRef}
                className="print-landscape bg-white rounded-xl shadow-lg border border-slate-300 p-4 sm:p-6 min-w-[1100px] text-slate-900 mx-auto text-[10px]"
              >
                {/* Factory Header */}
                <div className="border-b-2 border-slate-900 pb-2 mb-2 text-center">
                  <h1 className="text-xl font-black text-slate-900 tracking-wide uppercase">
                    টেক্স ওয়ার অ্যাপারেলস (TexWare Apparels)
                  </h1>
                  <h2 className="text-xs font-bold text-slate-800 mt-0.5">
                    শ্রমিক ও কর্মচারীদের মাসিক বেতন ও হাজিরা মাস্টার বিবরণী (Monthly Attendance & Payroll Master Sheet)
                  </h2>
                  <div className="text-[9px] text-amber-900 bg-amber-50 border border-amber-200 rounded-md py-0.5 px-2 mt-1 inline-block font-semibold">
                    কারখানার নিয়মাবলি: ৩ দিন অননুমোদিত অনুপস্থিতিতে অতিরিক্ত ১ দিন কর্তন | প্রতি ৩ দিন লেটে ১ দিনের হাজিরা কর্তন
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[10px] text-slate-600 font-semibold px-1">
                    <div>
                      <span>মাস ও বছর: </span>
                      <strong className="text-slate-950 text-[11px]">{masterA4Month} {toBengaliNumber(masterA4Year)}</strong>
                      {masterA4Dept !== 'all' && (
                        <span className="ml-2 px-1.5 py-0.5 bg-slate-100 rounded text-slate-900">
                          সেকশন: {masterA4Dept}
                        </span>
                      )}
                    </div>
                    <div>
                      <span>মোট শ্রমিক সংখ্যা: </span>
                      <strong className="text-slate-950">{toBengaliNumber(masterTotals.workersCount)} জন</strong>
                    </div>
                    <div>
                      <span>মুদ্রণ তারিখ: </span>
                      <span>{new Date().toLocaleDateString('bn-BD')}</span>
                    </div>
                  </div>
                </div>

                {/* Table */}
                <table className="w-full border-collapse border border-slate-400 text-left text-[9px]">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-400 text-center">
                      <th className="p-1 border border-slate-300 w-6">ক্র.</th>
                      <th className="p-1 border border-slate-300 w-12">আইডি</th>
                      <th className="p-1 border border-slate-300 text-left">শ্রমিকের নাম ও পদবি</th>
                      <th className="p-1 border border-slate-300">সেকশন</th>
                      <th className="p-1 border border-slate-300 text-right">মূল বেতন</th>
                      <th className="p-1 border border-slate-300 w-8">কার্যদিবস</th>
                      <th className="p-1 border border-slate-300 w-8 bg-emerald-50 text-emerald-900">উপস্থিতি</th>
                      <th className="p-1 border border-slate-300 w-8 bg-rose-50 text-rose-900">অনুপস্থিতি</th>
                      <th className="p-1 border border-slate-300 w-9 bg-rose-100/70 text-rose-950" title="৩ দিন অনুপস্থিতিতে অতিরিক্ত ১ দিন কর্তন">অনু. জরিমানা</th>
                      <th className="p-1 border border-slate-300 w-8 bg-amber-50 text-amber-900">লেট</th>
                      <th className="p-1 border border-slate-300 w-9 bg-amber-100/70 text-amber-950" title="৩ দিন লেট করলে ১ দিন কর্তন">লেট কর্তন</th>
                      <th className="p-1 border border-slate-300 w-8 bg-emerald-100/70 text-emerald-950 font-black">প্রদেয় দিন</th>
                      <th className="p-1 border border-slate-300 w-9 bg-blue-50 text-blue-900">ওটি ঘণ্টা</th>
                      <th className="p-1 border border-slate-300 text-right bg-blue-50 text-blue-900">ওটি টাকা</th>
                      <th className="p-1 border border-slate-300 text-right bg-amber-50 text-amber-900">হাজিরা বোনাস</th>
                      <th className="p-1 border border-slate-300 text-right">অর্জিত বেতন</th>
                      <th className="p-1 border border-slate-300 text-right">কর্তন</th>
                      <th className="p-1 border border-slate-300 text-right font-black bg-slate-200 text-slate-950">নিট প্রদেয়</th>
                      <th className="p-1 border border-slate-300 w-14">স্ট্যাটাস</th>
                      <th className="p-1 border border-slate-300 w-16">স্বাক্ষর</th>
                    </tr>
                  </thead>
                  <tbody>
                    {masterA4Rows.map((row) => (
                      <tr key={row.workerId} className="border-b border-slate-300 hover:bg-slate-50">
                        <td className="p-1 border border-slate-300 text-center font-semibold">{toBengaliNumber(row.sl)}</td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-slate-800">{row.workerId}</td>
                        <td className="p-1 border border-slate-300 text-left">
                          <div className="font-bold text-slate-900 leading-tight">{row.name}</div>
                          <div className="text-[8px] text-slate-600 leading-tight">{row.designation}</div>
                        </td>
                        <td className="p-1 border border-slate-300 text-center text-[8.5px] text-slate-700">{row.department}</td>
                        <td className="p-1 border border-slate-300 text-right font-semibold">{formatMoney(row.basicSalary)}</td>
                        <td className="p-1 border border-slate-300 text-center">{toBengaliNumber(row.totalDays)}</td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-emerald-800 bg-emerald-50/40">
                          {toBengaliNumber(row.presentDays)}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-rose-800 bg-rose-50/40">
                          {toBengaliNumber(row.absentDays)}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-rose-900 bg-rose-100/50">
                          {row.absentPenaltyDays > 0 ? `+${toBengaliNumber(row.absentPenaltyDays)}` : '০'}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-amber-800 bg-amber-50/40">
                          {toBengaliNumber(row.lateDays || 0)}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-amber-900 bg-amber-100/50">
                          {row.latePenaltyDays > 0 ? `-${toBengaliNumber(row.latePenaltyDays)}` : '০'}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-black text-emerald-950 bg-emerald-100/40">
                          {toBengaliNumber(row.effectivePresentDays)}
                        </td>
                        <td className="p-1 border border-slate-300 text-center font-bold text-blue-800 bg-blue-50/40">
                          {toBengaliNumber(row.otHours)}
                        </td>
                        <td className="p-1 border border-slate-300 text-right font-bold text-blue-900 bg-blue-50/40">
                          {formatMoney(row.otPay)}
                        </td>
                        <td className="p-1 border border-slate-300 text-right font-bold text-amber-900 bg-amber-50/40">
                          {row.attendanceBonus > 0 ? formatMoney(row.attendanceBonus) : '—'}
                        </td>
                        <td className="p-1 border border-slate-300 text-right font-semibold text-slate-800">
                          {formatMoney(row.presentSalary)}
                        </td>
                        <td className="p-1 border border-slate-300 text-right text-rose-700">
                          {(row.advance + row.deduction) > 0 ? formatMoney(row.advance + row.deduction) : '—'}
                        </td>
                        <td className="p-1 border border-slate-300 text-right font-black text-slate-950 bg-slate-100">
                          {formatMoney(row.netPayable)} ৳
                        </td>
                        <td className="p-1 border border-slate-300 text-center text-[8px] font-semibold">
                          {row.paymentStatus === 'paid' ? (
                            <span className="text-emerald-700 font-bold">পরিশোধিত</span>
                          ) : row.paymentStatus === 'pending' || row.paymentStatus === 'partial' ? (
                            <span className="text-amber-700 font-bold">পেন্ডিং</span>
                          ) : (
                            <span className="text-rose-700 font-bold">বাকী</span>
                          )}
                        </td>
                        <td className="p-1 border border-slate-300 text-center">
                          <div className="h-4"></div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-200 text-slate-900 font-black border-t-2 border-slate-500 text-center text-[8.5px]">
                      <td colSpan={4} className="p-1 border border-slate-300 text-right pr-2">
                        সর্বমোট ({toBengaliNumber(masterTotals.workersCount)} জন):
                      </td>
                      <td className="p-1 border border-slate-300 text-right">{formatMoney(masterTotals.totalBasicSalary)} ৳</td>
                      <td className="p-1 border border-slate-300">—</td>
                      <td className="p-1 border border-slate-300 text-emerald-950">{toBengaliNumber(masterTotals.totalPresentDays)}</td>
                      <td className="p-1 border border-slate-300 text-rose-950">{toBengaliNumber(masterTotals.totalAbsentDays)}</td>
                      <td className="p-1 border border-slate-300 text-rose-950">+{toBengaliNumber(masterTotals.totalAbsentPenaltyDays)}</td>
                      <td className="p-1 border border-slate-300 text-amber-950">{toBengaliNumber(masterTotals.totalLateDays)}</td>
                      <td className="p-1 border border-slate-300 text-amber-950">-{toBengaliNumber(masterTotals.totalLatePenaltyDays)}</td>
                      <td className="p-1 border border-slate-300 text-emerald-950">{toBengaliNumber(masterTotals.totalEffectivePresentDays)}</td>
                      <td className="p-1 border border-slate-300 text-blue-950">{toBengaliNumber(masterTotals.totalOtHours)}</td>
                      <td className="p-1 border border-slate-300 text-right text-blue-950">{formatMoney(masterTotals.totalOtPay)} ৳</td>
                      <td className="p-1 border border-slate-300 text-right text-amber-950">{formatMoney(masterTotals.totalBonus)} ৳</td>
                      <td className="p-1 border border-slate-300 text-right">{formatMoney(masterTotals.totalPresentSalary)} ৳</td>
                      <td className="p-1 border border-slate-300 text-right text-rose-900">
                        {formatMoney(masterTotals.totalAdvance + masterTotals.totalDeduction)} ৳
                      </td>
                      <td className="p-1 border border-slate-300 text-right bg-slate-300 text-slate-950">
                        {formatMoney(masterTotals.totalNetPayable)} ৳
                      </td>
                      <td colSpan={2} className="p-1 border border-slate-300 text-center text-[8.5px]">
                        পরিশোধ: {formatMoney(masterTotals.totalPaid)} | বাকি: {formatMoney(masterTotals.totalDue)}
                      </td>
                    </tr>
                  </tfoot>
                </table>

                {/* Signatures */}
                <div className="grid grid-cols-5 gap-3 mt-7 pt-3 border-t border-slate-300 text-center text-[9px] font-bold text-slate-700">
                  <div>
                    <div className="border-t border-slate-400 pt-1 mt-5">হিসাব প্রস্তুতকারী</div>
                    <div className="text-[7.5px] text-slate-500 font-normal">Prepared By</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 mt-5">হিসাব কর্মকর্তা</div>
                    <div className="text-[7.5px] text-slate-500 font-normal">Accountant</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 mt-5">সেকশন ইনচার্জ</div>
                    <div className="text-[7.5px] text-slate-500 font-normal">Section In-Charge</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 mt-5">এইচআর ও এডমিন ম্যানেজার</div>
                    <div className="text-[7.5px] text-slate-500 font-normal">HR & Admin Manager</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 mt-5">ব্যবস্থাপনা পরিচালক</div>
                    <div className="text-[7.5px] text-slate-500 font-normal">Managing Director</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Bottom Action Bar */}
            <div className="px-5 py-3 bg-white border-t border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-3 text-slate-600">
                <span>মোট কর্মী: <strong className="text-slate-900">{toBengaliNumber(masterTotals.workersCount)} জন</strong></span>
                <span>•</span>
                <span>ওটি টাকা: <strong className="text-blue-700">{formatMoney(masterTotals.totalOtPay)} ৳</strong></span>
                <span>•</span>
                <span>বোনাস: <strong className="text-amber-700">{formatMoney(masterTotals.totalBonus)} ৳</strong></span>
                <span>•</span>
                <span>সর্বমোট প্রদেয়: <strong className="text-slate-900 font-black text-sm">{formatMoney(masterTotals.totalNetPayable)} ৳</strong></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowMasterA4Modal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition cursor-pointer"
                >
                  বন্ধ করুন
                </button>
                <button
                  type="button"
                  onClick={handlePrintMasterA4Sheet}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black flex items-center gap-2 shadow-md transition cursor-pointer active:scale-95"
                >
                  <Printer className="w-4 h-4 text-emerald-100" />
                  <span>🖨️ A4 ল্যান্ডস্কেপ পেপারে প্রিন্ট করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {telegramPrintModalTitle && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
              <Printer className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">
                Telegram Bot-এ সরাসরি প্রিন্ট সাপোর্ট নেই
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                টেলিগ্রাম অ্যাপের নিজস্ব মোবাইল ব্রাউজারে সিস্টেম প্রিন্ট ডায়ালগ কাজ করে না। {telegramPrintModalTitle} প্রিন্ট করতে আপনার ফোনের ডিফল্ট ব্রাউজারে খুলুন:
              </p>
            </div>

            <div className="space-y-2 text-xs pt-1">
              <button
                type="button"
                onClick={() => {
                  setTelegramPrintModalTitle(null);
                  openInExternalBrowser();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer transition active:scale-95"
              >
                <ExternalLink className="w-4 h-4" />
                <span>ডিফল্ট ব্রাউজারে খুলুন (প্রিন্ট করতে)</span>
              </button>
            </div>

            <div className="pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setTelegramPrintModalTitle(null)}
                className="w-full py-2 rounded-xl text-slate-500 hover:text-slate-700 font-semibold text-xs text-center cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Worker Contract Letter A4 Modal */}
      {contractModalEmp && (
        <ContractLetterModal
          employee={contractModalEmp}
          isOpen={Boolean(contractModalEmp)}
          onClose={() => setContractModalEmp(null)}
          onEmployeeUpdated={(updated) => {
            setContractModalEmp(updated);
          }}
          showToast={showToast}
        />
      )}
      {/* Worker Resignation Letter A4 Modal */}
      {resignationLetterModalEmp && (
        <ResignationLetterModal
          employee={resignationLetterModalEmp}
          isOpen={Boolean(resignationLetterModalEmp)}
          onClose={() => setResignationLetterModalEmp(null)}
          onEmployeeUpdated={(updated) => {
            setResignationLetterModalEmp(updated);
          }}
          showToast={showToast}
        />
      )}
      {/* Worker Suspension Notice A4 Modal */}
      {suspensionNoticeModalEmp && (
        <SuspensionNoticeModal
          employee={suspensionNoticeModalEmp}
          isOpen={Boolean(suspensionNoticeModalEmp)}
          onClose={() => setSuspensionNoticeModalEmp(null)}
          onEmployeeUpdated={(updated) => {
            setSuspensionNoticeModalEmp(updated);
          }}
          showToast={showToast}
        />
      )}
      {/* Worker Termination Notice A4 Modal */}
      {terminationNoticeModalEmp && (
        <TerminationNoticeModal
          employee={terminationNoticeModalEmp}
          isOpen={Boolean(terminationNoticeModalEmp)}
          onClose={() => setTerminationNoticeModalEmp(null)}
          onEmployeeUpdated={(updated) => {
            setTerminationNoticeModalEmp(updated);
          }}
          showToast={showToast}
        />
      )}
      {/* Worker Portal Login & Password Control Modal */}
      {credentialModalEmp && (
        <WorkerCredentialModal
          employee={credentialModalEmp}
          isOpen={Boolean(credentialModalEmp)}
          onClose={() => setCredentialModalEmp(null)}
          showToast={showToast}
        />
      )}
      {/* All Workers Login Credentials & Links Table Modal */}
      {showAllWorkersLoginModal && (
        <AllWorkersLoginModal
          employees={employees}
          isOpen={showAllWorkersLoginModal}
          onClose={() => setShowAllWorkersLoginModal(false)}
          onSelectWorker={(emp) => {
            setShowAllWorkersLoginModal(false);
            setCredentialModalEmp(emp);
          }}
          showToast={showToast}
        />
      )}
      {/* Worker Notice Modal (শ্রমিকদের আলাদা বা একসঙ্গে নোটিশ প্রেরণের ব্যবস্থা) */}
      {noticeModalOpen && (
        <WorkerNoticeModal
          isOpen={noticeModalOpen}
          onClose={() => {
            setNoticeModalOpen(false);
            setNoticeTargetEmp(null);
          }}
          employees={employees}
          initialSelectedEmployee={noticeTargetEmp}
          showToast={showToast}
        />
      )}
      {/* Zoomed Profile Photo Modal */}
      {zoomedPhotoEmp && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-200 text-slate-900">
            <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-black text-sm text-white">{zoomedPhotoEmp.name}</h4>
                <p className="text-[11px] text-slate-300 font-mono">Worker ID: {zoomedPhotoEmp.workerId}</p>
              </div>
              <button
                type="button"
                onClick={() => setZoomedPhotoEmp(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex flex-col items-center">
              <div className="w-64 h-80 rounded-2xl bg-slate-100 border border-slate-200 overflow-hidden shadow-inner flex items-center justify-center">
                {zoomedPhotoEmp.photoUrl ? (
                  <img
                    src={zoomedPhotoEmp.photoUrl}
                    alt={zoomedPhotoEmp.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-24 h-24 text-slate-300" />
                )}
              </div>
              <div className="mt-3 text-center text-xs space-y-0.5">
                <div className="font-bold text-slate-800">{zoomedPhotoEmp.designation} • {zoomedPhotoEmp.department}</div>
                <div className="text-slate-500 font-mono">মোবাইল: {zoomedPhotoEmp.mobile || '—'}</div>
              </div>
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-center">
              <button
                type="button"
                onClick={() => setZoomedPhotoEmp(null)}
                className="px-5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
