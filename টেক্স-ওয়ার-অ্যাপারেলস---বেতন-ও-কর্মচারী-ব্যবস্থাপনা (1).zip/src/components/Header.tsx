import React, { useState, useEffect } from 'react';
import { Shirt, UserCheck, Users, UserX, ExternalLink, Lock, Send, MessageSquare, Building2, FileText, TrendingUp } from 'lucide-react';
import { isTelegramWebApp, openInExternalBrowser } from '../lib/telegram';

export type AppMode = 'user' | 'admin' | 'attendance' | 'salaries' | 'password' | 'telegram' | 'sms' | 'factory' | 'apply' | 'applications' | 'worker' | 'investment' | 'investor';

interface HeaderProps {
  currentTab: AppMode;
  onTabChange: (tab: AppMode) => void;
  activeCount: number;
  resignedCount: number;
  suspendedCount?: number;
  terminatedCount?: number;
  totalCount: number;
  pendingApplicationsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  activeCount,
  resignedCount,
  suspendedCount = 0,
  terminatedCount = 0,
  totalCount,
  pendingApplicationsCount = 0,
}) => {
  const [isTelegram, setIsTelegram] = useState(false);

  useEffect(() => {
    setIsTelegram(isTelegramWebApp());
  }, []);

  return (
    <header className="mb-4">
      {/* Factory Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white rounded-2xl p-5 shadow-lg relative overflow-hidden">
        {/* Subtle geometric background pattern */}
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-44 h-44 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-36 h-36 bg-indigo-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-blue-600/30 border border-blue-400/30 flex items-center justify-center shadow-inner text-blue-300">
              <Shirt className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl md:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                  টেক্স ওয়ার অ্যাপারেলস
                </h1>
                <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/25 text-blue-200 border border-blue-400/30">
                  {currentTab === 'worker' ? 'Worker Portal' : currentTab === 'user' ? 'HR & Payroll' : 'Admin Portal'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 flex items-center gap-2">
                <span>
                  {currentTab === 'worker'
                    ? 'শ্রমিকের ব্যক্তিগত প্রোফাইল — দৈনিক হাজিরা, ইন/আউট টাইম, ওটি ও বেতন বিবরণী'
                    : currentTab === 'user'
                    ? 'বেতন হিসাব, ওভারটাইম ও পে-স্লিপ প্রিন্ট'
                    : 'কর্মী তালিকা, হাজিরা ও ইন-আউট টাইম, বেতন খাতা ও পাসওয়ার্ড নিয়ন্ত্রণ'}
                </span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[11px] text-emerald-300 font-medium">Cloud Synced</span>
              </p>
            </div>
          </div>

          {/* Quick Metrics Bar & Action Buttons (Hidden when in Worker Profile) */}
          {currentTab === 'worker' ? (
            <div className="flex items-center gap-2 self-start md:self-auto">
              <span className="px-3.5 py-1.5 rounded-xl bg-blue-500/20 text-blue-200 border border-blue-400/30 text-xs font-bold flex items-center gap-1.5 shadow-xs">
                <UserCheck className="w-3.5 h-3.5 text-blue-300" />
                <span>শ্রমিক প্রোফাইল (সুরক্ষিত ভিউ)</span>
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 bg-slate-950/40 p-1.5 rounded-xl border border-white/10 backdrop-blur-sm self-start md:self-auto flex-wrap">
              <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/20 text-emerald-300 text-xs font-semibold" title="কর্মরত / সক্রিয়">
                <Users className="w-3.5 h-3.5" />
                <span>সক্রিয়: {activeCount}</span>
              </div>
              <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-rose-500/15 border border-rose-500/20 text-rose-300 text-xs font-semibold" title="পদত্যাগ / রিজাইনকৃত">
                <UserX className="w-3.5 h-3.5" />
                <span>রিজাইন: {resignedCount}</span>
              </div>
              {suspendedCount > 0 && (
                <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 text-xs font-semibold" title="সাময়িক স্থগিত">
                  <span>স্থগিত: {suspendedCount}</span>
                </div>
              )}
              {terminatedCount > 0 && (
                <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-700/50 border border-slate-600 text-slate-300 text-xs font-semibold" title="অব্যাহতি / বরখাস্ত">
                  <span>বরখাস্ত: {terminatedCount}</span>
                </div>
              )}
              <div className="hidden sm:flex items-center gap-1 px-1.5 py-1 text-slate-400 text-xs">
                <span>মোট: {totalCount}</span>
              </div>

              {/* Quick Telegram & SMS Settings Links */}
              <button
                type="button"
                onClick={() => onTabChange('telegram')}
                title="Telegram Bot সেটিংস"
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs ${
                  currentTab === 'telegram'
                    ? 'bg-sky-500 text-white'
                    : 'bg-sky-500/20 text-sky-200 hover:bg-sky-500/30 border border-sky-400/30'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Telegram</span>
              </button>

              <button
                type="button"
                onClick={() => onTabChange('sms')}
                title="Auto SMS সেটিংস ও বাল্ক মেসেজ"
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs ${
                  currentTab === 'sms'
                    ? 'bg-purple-500 text-white'
                    : 'bg-purple-500/20 text-purple-200 hover:bg-purple-500/30 border border-purple-400/30'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Auto SMS</span>
              </button>

              <button
                type="button"
                onClick={() => onTabChange('factory')}
                title="কারখানার নাম, ঠিকানা ও চুক্তি সেটিংস"
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs ${
                  currentTab === 'factory'
                    ? 'bg-teal-600 text-white'
                    : 'bg-teal-500/20 text-teal-200 hover:bg-teal-500/30 border border-teal-400/30'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">কারখানা তথ্য</span>
              </button>

              {/* আবেদন ফরম ফাংশন বাটন (Job Application Portal) */}
              <button
                type="button"
                id="btnJobApplicationPortal"
                onClick={() => onTabChange(currentTab === 'admin' ? 'applications' : 'apply')}
                title="নতুন শ্রমিক নিয়োগ আবেদন ফরম ও আবেদন ব্যবস্থাপনা"
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs relative ${
                  currentTab === 'apply' || currentTab === 'applications'
                    ? 'bg-rose-500 text-white ring-2 ring-rose-400/40 shadow-sm'
                    : 'bg-rose-500/20 text-rose-200 hover:bg-rose-500/30 border border-rose-400/30'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-rose-300" />
                <span className="truncate">আবেদন ফরম</span>
                {pendingApplicationsCount > 0 && (
                  <span className="inline-flex items-center justify-center px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 animate-pulse ml-0.5 shadow-xs">
                    {pendingApplicationsCount}
                  </span>
                )}
              </button>

              {/* ইনভেস্টমেন্ট পোর্টাল বাটন (Investment Portal) */}
              <button
                type="button"
                id="btnInvestmentPortal"
                onClick={() => onTabChange('investment')}
                title="কারখানা ইনভেস্টমেন্ট ও চুক্তিপত্র পোর্টাল (মিনিমাম ৫০,০০০ ৳ থেকে আনলিমিটেড)"
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs ${
                  currentTab === 'investment'
                    ? 'bg-emerald-500 text-slate-950 font-black ring-2 ring-emerald-400/50 shadow-sm'
                    : 'bg-emerald-500/20 text-emerald-200 hover:bg-emerald-500/30 border border-emerald-400/30'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-emerald-300" />
                <span className="truncate">ইনভেস্টমেন্ট</span>
              </button>

              {/* শ্রমিক ব্যক্তিগত পোর্টাল বাটন (Worker Portal Login) */}
              <button
                type="button"
                id="btnWorkerPortalAccess"
                onClick={() => onTabChange('worker')}
                title="শ্রমিকদের ব্যক্তিগত হাজিরা ও ওটি দেখার পোর্টাল"
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer active:scale-95 shadow-xs bg-indigo-500/20 text-indigo-200 hover:bg-indigo-500/30 border border-indigo-400/30"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span className="truncate">শ্রমিক পোর্টাল</span>
              </button>

              {/* Single Clean Mode Switch Button */}
              {currentTab === 'user' ? (
                <button
                  type="button"
                  id="btnAdminAccess"
                  onClick={() => onTabChange('admin')}
                  title="অ্যাডমিন প্যানেলে প্রবেশ করুন"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 text-slate-950 hover:bg-amber-300 font-black text-xs transition cursor-pointer active:scale-95 shadow-sm ml-1"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Admin প্যানেল</span>
                </button>
              ) : (
                <button
                  type="button"
                  id="btnUserAccess"
                  onClick={() => onTabChange('user')}
                  title="ইউজার অ্যাপে ফিরে যান"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition cursor-pointer active:scale-95 shadow-xs ml-1"
                >
                  <UserCheck className="w-3.5 h-3.5 text-white" />
                  <span>← User অ্যাপ</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Telegram WebApp Notice & External Browser Link */}
      {isTelegram && (
        <div className="mt-2.5 p-2.5 rounded-xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white border border-blue-400/40 flex items-center justify-between gap-2 shadow-xs text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping shrink-0" />
            <div>
              <span className="font-bold text-blue-200">Telegram Bot মোড সক্রিয়:</span>{' '}
              <span className="text-slate-200 text-[11px]">সরাসরি প্রিন্ট ও ডাউনলোড করতে ব্রাউজারে খুলুন</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => openInExternalBrowser()}
            className="px-2.5 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-400 text-white font-bold text-xs flex items-center gap-1 shadow-xs cursor-pointer transition active:scale-95 shrink-0"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>ব্রাউজারে খুলুন</span>
          </button>
        </div>
      )}
    </header>
  );
};
