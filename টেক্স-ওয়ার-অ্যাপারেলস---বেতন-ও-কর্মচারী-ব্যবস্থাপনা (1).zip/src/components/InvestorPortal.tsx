import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  InvestmentRecord,
  InvestmentWithdrawalRecord,
  FactorySettings,
  WithdrawalType,
  PaymentMethod
} from '../types';
import {
  subscribeInvestments,
  subscribeWithdrawals,
  saveOrUpdateWithdrawal,
  loadFactorySettings,
  DEFAULT_FACTORY_SETTINGS
} from '../lib/firebase';
import { formatMoney, toBengaliNumber, formatDateBn, numberToBengaliWords } from '../lib/utils';
import { printElement } from '../lib/printer';
import {
  TrendingUp,
  Lock,
  Phone,
  Eye,
  EyeOff,
  User,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  FileText,
  Printer,
  Download,
  Receipt,
  DollarSign,
  ArrowRight,
  LogOut,
  Calendar,
  Building2,
  AlertTriangle,
  PenTool,
  Upload,
  Camera,
  X,
  Plus,
  Clock,
  Sparkles,
  CreditCard,
  Ban,
  Check
} from 'lucide-react';

interface InvestorPortalProps {
  initialMobile?: string;
  initialInvestorId?: string;
  onBackToApp?: () => void;
  showToast: (msg: string) => void;
}

export const InvestorPortal: React.FC<InvestorPortalProps> = ({
  initialMobile = '',
  initialInvestorId = '',
  onBackToApp,
  showToast,
}) => {
  // All investments & withdrawals state
  const [investments, setInvestments] = useState<InvestmentRecord[]>([]);
  const [withdrawals, setWithdrawals] = useState<InvestmentWithdrawalRecord[]>([]);
  const [factory, setFactory] = useState<FactorySettings>(DEFAULT_FACTORY_SETTINGS);

  // Auth State
  const [loggedInInvestor, setLoggedInInvestor] = useState<InvestmentRecord | null>(null);
  const [loginIdentifier, setLoginIdentifier] = useState(initialMobile || initialInvestorId);
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Active view tab inside portal
  const [portalTab, setPortalTab] = useState<'overview' | 'withdrawals' | 'documents'>('overview');

  // Modals
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [selectedAgreementDoc, setSelectedAgreementDoc] = useState<InvestmentRecord | null>(null);
  const [selectedReceiptDoc, setSelectedReceiptDoc] = useState<InvestmentRecord | null>(null);
  const [selectedVoucherDoc, setSelectedVoucherDoc] = useState<InvestmentWithdrawalRecord | null>(null);

  // Withdrawal Form Fields
  const [wthAmount, setWthAmount] = useState<number | ''>(10000);
  const [wthType, setWthType] = useState<WithdrawalType>('profit_monthly');
  const [wthDate, setWthDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [wthPaymentMethod, setWthPaymentMethod] = useState<PaymentMethod | 'cheque'>('bank');
  const [wthBankName, setWthBankName] = useState('ইসলামী ব্যাংক বাংলাদেশ লিঃ');
  const [wthAccountNo, setWthAccountNo] = useState('');
  const [wthChequeOrTxn, setWthChequeOrTxn] = useState('');
  const [wthReason, setWthReason] = useState('');
  const [wthFormError, setWthFormError] = useState('');
  const [isSubmittingWth, setIsSubmittingWth] = useState(false);

  // Signature: Default to File Upload
  const [signatureMode, setSignatureMode] = useState<'upload' | 'draw'>('upload');
  const [drawnSignatureUrl, setDrawnSignatureUrl] = useState('');
  const [uploadedSignatureUrl, setUploadedSignatureUrl] = useState('');
  const sigCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawingSig, setIsDrawingSig] = useState(false);
  const sigFileInputRef = useRef<HTMLInputElement | null>(null);

  // Subscribe to real-time data
  useEffect(() => {
    loadFactorySettings().then((res) => {
      if (res && res.name) setFactory(res);
    });

    const unsubInv = subscribeInvestments((list) => {
      setInvestments(list);
      // Keep logged in investor in sync
      if (loggedInInvestor) {
        const found = list.find((i) => i.id === loggedInInvestor.id);
        if (found) setLoggedInInvestor(found);
      }
    });

    const unsubWth = subscribeWithdrawals((list) => {
      setWithdrawals(list);
    });

    return () => {
      unsubInv();
      unsubWth();
    };
  }, [loggedInInvestor?.id]);

  // Set initial login input
  useEffect(() => {
    if (!loggedInInvestor && (initialMobile || initialInvestorId)) {
      setLoginIdentifier(initialMobile || initialInvestorId);
    }
  }, [initialMobile, initialInvestorId, loggedInInvestor]);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const cleanInput = loginIdentifier.trim().toLowerCase();
    const cleanPass = loginPassword.trim();

    if (!cleanInput) {
      setLoginError('অনুগ্রহ করে মোবাইল নম্বর বা ইনভেস্টর কোড লিখুন');
      return;
    }
    if (!cleanPass) {
      setLoginError('অনুগ্রহ করে আপনার গোপন পাসওয়ার্ড লিখুন');
      return;
    }

    // Match investor by mobile number, agreementNo or code
    const matched = investments.find((inv) => {
      const invMob = (inv.investorMobile || '').replace(/[^0-9]/g, '');
      const inputMob = cleanInput.replace(/[^0-9]/g, '');
      const matchMobile = inputMob.length >= 8 && invMob.endsWith(inputMob);
      const matchAgreement = inv.agreementNo.toLowerCase() === cleanInput;
      const matchCode = (inv.investorCode || '').toLowerCase() === cleanInput;
      const matchId = inv.id.toLowerCase() === cleanInput;
      return matchMobile || matchAgreement || matchCode || matchId;
    });

    if (!matched) {
      setLoginError('এই মোবাইল নম্বর বা চুক্তি নম্বর দিয়ে কোনো বিনিয়োগকারীর তথ্য পাওয়া যায়নি।');
      return;
    }

    // BLOCK CHECK: If investor is blocked by Admin
    if (matched.isBlocked) {
      setLoginError(
        `⛔ আপনার ইনভেস্টর অ্যাকাউন্ট অ্যাডমিন কর্তৃক সাময়িকভাবে ব্লক করা হয়েছে!\n\nকারণ: ${
          matched.blockReason || 'প্রশাসনিক প্রয়োজনে অ্যাকাউন্ট সাময়িকভাবে বন্ধ রাখা হয়েছে।'
        }\n\nঅ্যাকাউন্ট আনব্লক করতে কারখানার অ্যাডমিন বা ব্যবস্থাপনা কর্তৃপক্ষের সাথে যোগাযোগ করুন।`
      );
      return;
    }

    // Password validation:
    // 1. Explicit portalPassword if set
    // 2. Default: last 4 digits of phone, or '123456'
    const mobileDigits = (matched.investorMobile || '').replace(/[^0-9]/g, '');
    const defaultLast4 = mobileDigits.slice(-4);
    const isValidPassword =
      (matched.portalPassword && matched.portalPassword === cleanPass) ||
      (!matched.portalPassword && (cleanPass === defaultLast4 || cleanPass === '123456')) ||
      cleanPass === '123456';

    if (!isValidPassword) {
      setLoginError('ভুল পাসওয়ার্ড। পাসওয়ার্ড ভুলে গেলে কারখানা অ্যাডমিনের সাথে যোগাযোগ করুন।');
      return;
    }

    setLoggedInInvestor(matched);
    showToast(`স্বাগতম জনাব ${matched.investorName}! ইনভেস্টর পোর্টালে সফলভাবে প্রবেশ করেছেন।`);
  };

  const handleLogout = () => {
    setLoggedInInvestor(null);
    setLoginPassword('');
    setLoginError('');
    showToast('ইনভেস্টর পোর্টাল থেকে সফলভাবে লগআউট করা হয়েছে');
  };

  // Withdrawals for this logged in investor
  const myWithdrawals = useMemo(() => {
    if (!loggedInInvestor) return [];
    return withdrawals.filter(
      (w) => w.investmentId === loggedInInvestor.id || w.agreementNo === loggedInInvestor.agreementNo
    );
  }, [withdrawals, loggedInInvestor]);

  // Aggregate Metrics for this investor
  const totalWithdrawnAmount = useMemo(() => {
    return myWithdrawals.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [myWithdrawals]);

  const capitalWithdrawnAmount = useMemo(() => {
    return myWithdrawals
      .filter((w) => w.withdrawalType === 'capital_partial' || w.withdrawalType === 'capital_full')
      .reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [myWithdrawals]);

  const profitWithdrawnAmount = useMemo(() => {
    return myWithdrawals
      .filter((w) => w.withdrawalType === 'profit_monthly' || w.withdrawalType === 'profit_annual')
      .reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [myWithdrawals]);

  const remainingCapital = useMemo(() => {
    if (!loggedInInvestor) return 0;
    return Math.max(0, (Number(loggedInInvestor.amount) || 0) - capitalWithdrawnAmount);
  }, [loggedInInvestor, capitalWithdrawnAmount]);

  const expectedMonthlyProfit = useMemo(() => {
    if (!loggedInInvestor) return 0;
    const base = remainingCapital > 0 ? remainingCapital : Number(loggedInInvestor.amount) || 0;
    const rate = (Number(loggedInInvestor.profitRatePercent) || 0) / 100;
    return Math.round((base * rate) / 12);
  }, [loggedInInvestor, remainingCapital]);

  // Signature canvas handlers
  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsDrawingSig(true);
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#0284c7';
    ctx.lineCap = 'round';
  };

  const handleDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingSig) return;
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const handleEndDraw = () => {
    if (!isDrawingSig) return;
    setIsDrawingSig(false);
    const canvas = sigCanvasRef.current;
    if (canvas) {
      setDrawnSignatureUrl(canvas.toDataURL('image/png'));
    }
  };

  const handleClearSignature = () => {
    const canvas = sigCanvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }
    setDrawnSignatureUrl('');
  };

  // Upload signature photo
  const handleSignatureFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('অনুগ্রহ করে সঠিক ছবির ফাইল নির্বাচন করুন');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      showToast('ছবির ফাইল সাইজ ৩ মেগাবাইটের কম হতে হবে');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedSignatureUrl(reader.result as string);
      showToast('✓ সিগনেচারের ছবি আপলোড হয়েছে');
    };
    reader.readAsDataURL(file);
  };

  // Submit Withdrawal
  const handleSubmitWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWthFormError('');

    if (!loggedInInvestor) return;

    const numAmount = Number(wthAmount);
    if (!numAmount || isNaN(numAmount) || numAmount <= 0) {
      setWthFormError('অনুগ্রহ করে সঠিক টাকার অংক লিখুন');
      return;
    }

    // Capital check
    if ((wthType === 'capital_partial' || wthType === 'capital_full') && numAmount > remainingCapital) {
      setWthFormError(`উত্তোলনকৃত অর্থ আপনার অবশিষ্ট মূলধন (৳ ${formatMoney(remainingCapital)}) এর চেয়ে বেশি হতে পারে না`);
      return;
    }

    const finalSig = uploadedSignatureUrl || drawnSignatureUrl;
    if (!finalSig) {
      setWthFormError('অনুগ্রহ করে আপনার স্বাক্ষরের ছবি আপলোড করুন');
      return;
    }

    setIsSubmittingWth(true);
    try {
      const recordPayload: Omit<InvestmentWithdrawalRecord, 'id' | 'createdAt' | 'updatedAt'> = {
        investmentId: loggedInInvestor.id,
        agreementNo: loggedInInvestor.agreementNo,
        investorName: loggedInInvestor.investorName,
        investorMobile: loggedInInvestor.investorMobile,
        withdrawalDate: wthDate,
        withdrawalType: wthType,
        amount: numAmount,
        paymentMethod: wthPaymentMethod,
        bankName: wthPaymentMethod === 'bank' ? wthBankName : undefined,
        chequeOrTxnNo: wthChequeOrTxn.trim() || undefined,
        reasonOrNote: wthReason.trim() || undefined,
        investorSignatureUrl: finalSig,
        signatureType: signatureMode === 'draw' ? 'drawn' : 'uploaded',
        status: 'approved',
      };

      const newId = await saveOrUpdateWithdrawal(recordPayload);
      const savedDoc: InvestmentWithdrawalRecord = {
        ...recordPayload,
        id: newId,
        createdAt: Date.now(),
      };

      setShowWithdrawalModal(false);
      // Reset form
      setWthAmount(10000);
      setWthReason('');
      setDrawnSignatureUrl('');
      setUploadedSignatureUrl('');
      handleClearSignature();

      showToast('✓ টাকা উত্তোলনের আবেদন ও ভাউচার সফলভাবে সম্পন্ন হয়েছে!');
      // Open the official A4 printable voucher automatically
      setSelectedVoucherDoc(savedDoc);
    } catch {
      setWthFormError('উত্তোলন সংরক্ষণ করতে সমস্যা হয়েছে');
    } finally {
      setIsSubmittingWth(false);
    }
  };

  const handlePrintDoc = () => {
    if (selectedVoucherDoc) {
      const el = document.getElementById('printableA4WithdrawalVoucher');
      if (el) {
        printElement(el, `Withdrawal_Voucher_${selectedVoucherDoc.agreementNo}`, 'contract');
        return;
      }
    }
    if (selectedAgreementDoc) {
      const el = document.getElementById('printableA4InvestmentAgreement');
      if (el) {
        printElement(el, `Investment_Agreement_${selectedAgreementDoc.agreementNo}`, 'contract');
        return;
      }
    }
    if (selectedReceiptDoc) {
      const el = document.getElementById('printableMoneyReceipt');
      if (el) {
        printElement(el, `Money_Receipt_${selectedReceiptDoc.agreementNo}`, 'pos');
        return;
      }
    }
    window.print();
  };

  /* ================= 1. LOGIN SCREEN (ISOLATED MODE) ================= */
  if (!loggedInInvestor) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-slate-900/90 backdrop-blur-md rounded-3xl border border-amber-400/30 p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
          {/* Subtle Golden Glow Accents */}
          <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-44 h-44 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Factory Brand & Monogram Header */}
          <div className="text-center space-y-2 relative z-10">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg border-2 border-amber-300">
              <TrendingUp className="w-9 h-9 stroke-[2.5]" />
            </div>
            <div>
              <div className="inline-block px-3 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10.5px] font-black uppercase tracking-wider mb-1">
                Investor Partner Portal
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {factory.name || 'টেক্স ওয়ার অ্যাপারেলস'}
              </h1>
              <p className="text-xs text-slate-300 mt-1">
                কারখানা বিনিয়োগকারী অংশীদারদের ব্যক্তিগত পোর্টাল
              </p>
            </div>
          </div>

          {/* Error Banner */}
          {loginError && (
            <div className="p-4 bg-rose-950/80 border border-rose-500/50 rounded-2xl text-rose-200 text-xs whitespace-pre-line space-y-1.5 animate-in fade-in duration-200 shadow-md">
              <div className="font-bold flex items-center gap-1.5 text-rose-300">
                <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
                <span>প্রবেশাধিকার নোটিশ:</span>
              </div>
              <p className="leading-relaxed pl-5 font-medium">{loginError}</p>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4 relative z-10">
            <div>
              <label className="block text-xs font-bold text-amber-200 mb-1.5 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>নিবন্ধিত মোবাইল নম্বর বা চুক্তি নং *</span>
              </label>
              <input
                type="text"
                required
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="যেমন: 017xxxxxxxx বা TW-INV-2026-001"
                className="w-full px-4 py-3 bg-slate-950/80 border border-slate-700 focus:border-amber-400 rounded-xl font-mono text-sm font-bold text-white focus:ring-2 focus:ring-amber-400/40 outline-none transition"
              />
              <span className="text-[10.5px] text-slate-400 mt-1 block">
                বিনিয়োগের সময় প্রদত্ত মোবাইল নম্বরটি লিখুন
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-amber-200 mb-1.5 flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>পোর্টাল পাসওয়ার্ড *</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড লিখুন"
                  className="w-full px-4 py-3 bg-slate-950/80 border border-slate-700 focus:border-amber-400 rounded-xl font-mono text-sm font-bold text-white focus:ring-2 focus:ring-amber-400/40 outline-none transition pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                ডিফল্ট পাসওয়ার্ড: মোবাইলের শেষ ৪ ডিজিট অথবা ১২৩৪৫৬
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg transition active:scale-95 cursor-pointer"
            >
              <span>ইনভেস্টর পোর্টালে প্রবেশ করুন</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Secure System Seal */}
          <div className="pt-3 border-t border-slate-800 text-center text-[10.5px] text-slate-400 space-y-1">
            <div className="flex items-center justify-center gap-1 text-emerald-400 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>২৫৬-বিট এনক্রিপ্টেড সিকিউর পোর্টাল</span>
            </div>
            <p>সকল ডাটা কারখানা সার্ভারে সুরক্ষিতভাবে সংরক্ষিত</p>
          </div>

          {onBackToApp && (
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={onBackToApp}
                className="text-xs text-slate-400 hover:text-amber-300 font-semibold underline cursor-pointer"
              >
                ← প্রধান অ্যাপ্লিকেশনে ফিরে যান
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* ================= 2. LOGGED-IN INVESTOR DASHBOARD ================= */
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-16">
      {/* Top Corporate Navigation Bar */}
      <header className="bg-slate-900/90 border-b border-amber-400/20 backdrop-blur-md sticky top-0 z-40 px-4 py-3 sm:px-8 flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black flex items-center justify-center shadow-md border border-amber-300">
            <TrendingUp className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-black text-sm sm:text-base text-white tracking-tight">
                {factory.name}
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase">
                Investor Portal
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              বিনিয়োগকারী অংশীদার: <b className="text-amber-300 font-bold">{loggedInInvestor.investorName}</b> ({loggedInInvestor.agreementNo})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Apply Withdrawal Button */}
          <button
            type="button"
            onClick={() => setShowWithdrawalModal(true)}
            className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition active:scale-95 cursor-pointer"
          >
            <DollarSign className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">টাকা উত্তোলন ফরম</span>
            <span className="sm:hidden">উত্তোলন</span>
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-white border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">লগআউট</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-5xl mx-auto p-3 sm:p-6 space-y-6">
        {/* Investor Profile Hero Card (Golden Luxury Theme) */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-5 sm:p-7 border border-amber-400/30 shadow-2xl relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute left-1/3 bottom-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl border-2 border-amber-400/60 overflow-hidden bg-slate-800 shrink-0 shadow-lg">
                {loggedInInvestor.investorPhotoUrl ? (
                  <img
                    src={loggedInInvestor.investorPhotoUrl}
                    alt={loggedInInvestor.investorName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-amber-300 text-2xl font-black">
                    {loggedInInvestor.investorName.charAt(0)}
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg sm:text-2xl font-black text-white">
                    {loggedInInvestor.investorName}
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>সক্রিয় অংশীদার</span>
                  </span>
                </div>
                <div className="text-xs text-slate-300 space-y-0.5 font-medium">
                  <p>চুক্তি নং: <b className="text-amber-300 font-mono">{loggedInInvestor.agreementNo}</b> | মোবাইল: <b className="text-white font-mono">{loggedInInvestor.investorMobile}</b></p>
                  <p>বিনিয়োগের তারিখ: {formatDateBn(loggedInInvestor.investmentDate)} | নমিনি: <b>{loggedInInvestor.nomineeName} ({loggedInInvestor.nomineeRelation})</b></p>
                </div>
              </div>
            </div>

            {/* Quick Document Buttons */}
            <div className="flex items-center gap-2 flex-wrap self-stretch sm:self-auto">
              <button
                type="button"
                onClick={() => setSelectedAgreementDoc(loggedInInvestor)}
                className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-blue-600/80 hover:bg-blue-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer border border-blue-400/40"
              >
                <FileText className="w-4 h-4" />
                <span>A4 চুক্তিপত্র</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedReceiptDoc(loggedInInvestor)}
                className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer border border-emerald-400/40"
              >
                <Receipt className="w-4 h-4" />
                <span>টাকা জমার রসিদ</span>
              </button>
            </div>
          </div>
        </div>

        {/* 4 Essential Financial Balance Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Card 1: Total Initial Investment */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
            <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">
              মোট বিনিয়োগকৃত মূলধন:
            </span>
            <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono">
              ৳ {formatMoney(loggedInInvestor.amount)}
            </div>
            <span className="text-[10.5px] text-slate-400 block">
              মেয়াদ: {toBengaliNumber(loggedInInvestor.durationMonths)} মাস ({toBengaliNumber(Math.round(loggedInInvestor.durationMonths / 12))} বছর)
            </span>
          </div>

          {/* Card 2: Remaining Capital Balance */}
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 shadow-md space-y-1">
            <span className="text-[11px] font-bold text-emerald-400 block uppercase tracking-wider">
              বর্তমান মূলধন ব্যালেন্স:
            </span>
            <div className="text-xl sm:text-2xl font-black text-emerald-300 font-mono">
              ৳ {formatMoney(remainingCapital)}
            </div>
            <span className="text-[10.5px] text-emerald-400/80 block">
              {capitalWithdrawnAmount > 0
                ? `মূলধন উত্তোলন হয়েছে: ৳ ${formatMoney(capitalWithdrawnAmount)}`
                : 'সম্পূর্ণ মূলধন নিরাপদ ও অপরিবর্তিত'}
            </span>
          </div>

          {/* Card 3: Monthly Profit Yield */}
          <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/30 shadow-md space-y-1">
            <span className="text-[11px] font-bold text-blue-400 block uppercase tracking-wider">
              মাসিক লভ্যাংশ হার ({toBengaliNumber(loggedInInvestor.profitRatePercent || 0)}%):
            </span>
            <div className="text-xl sm:text-2xl font-black text-blue-300 font-mono">
              ৳ {formatMoney(expectedMonthlyProfit)}
            </div>
            <span className="text-[10.5px] text-blue-400/80 block">
              লভ্যাংশ বণ্টন: {loggedInInvestor.profitPayout === 'monthly' ? 'প্রতি মাসে নিয়মিত' : 'চুক্তি অনুযায়ী'}
            </span>
          </div>

          {/* Card 4: Total Withdrawn */}
          <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-500/30 shadow-md space-y-1">
            <span className="text-[11px] font-bold text-purple-400 block uppercase tracking-wider">
              সর্বমোট অর্থ উত্তোলন:
            </span>
            <div className="text-xl sm:text-2xl font-black text-purple-300 font-mono">
              ৳ {formatMoney(totalWithdrawnAmount)}
            </div>
            <span className="text-[10.5px] text-purple-300/80 block">
              উত্তোলন ভাউচার: {toBengaliNumber(myWithdrawals.length)} টি
            </span>
          </div>
        </div>

        {/* Action Callout Banner: Apply for Withdrawal */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/50 via-slate-900 to-amber-950/40 border border-amber-400/40 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <h3 className="font-black text-white text-base flex items-center justify-center sm:justify-start gap-2">
              <DollarSign className="w-5 h-5 text-amber-400" />
              <span>টাকা উত্তোলন করতে চান? ডিজিটাল স্বাক্ষর দিয়ে ভাউচার পূরণ করুন</span>
            </h3>
            <p className="text-xs text-slate-300">
              মূলধন অথবা অর্জিত মাসিক লভ্যাংশের টাকা উত্তোলনের জন্য স্বাক্ষরের ছবি আপলোড করে অফিশিয়াল ক্যাশ ভাউচার প্রিন্ট করুন।
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowWithdrawalModal(true)}
            className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg transition active:scale-95 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>টাকা উত্তোলনের ফর্ম পূরণ করুন</span>
          </button>
        </div>

        {/* Withdrawal History & Printable Vouchers Register */}
        <div className="bg-slate-900 rounded-3xl p-4 sm:p-6 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 flex-wrap gap-2">
            <div className="flex items-center gap-2 font-black text-white text-sm sm:text-base">
              <Receipt className="w-5 h-5 text-amber-400" />
              <span>আপনার টাকা উত্তোলন ইতিহাস ও ভাউচার রেজিস্টার</span>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
              মোট উত্তোলন: {toBengaliNumber(myWithdrawals.length)} টি
            </span>
          </div>

          {myWithdrawals.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Receipt className="w-10 h-10 mx-auto opacity-30 text-amber-400" />
              <p className="font-bold text-slate-400 text-xs">
                আপনি এখনও কোনো অর্থ উত্তোলন করেননি।
              </p>
              <p className="text-[11px] text-slate-500">
                মুনাফা বা মূলধনের টাকা উত্তোলন করতে উপরের "টাকা উত্তোলনের ফর্ম পূরণ করুন" বাটনে চাপ দিন।
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {myWithdrawals.map((wth) => {
                const typeLabels: Record<WithdrawalType, string> = {
                  capital_partial: 'মূলধন আংশিক ফেরত',
                  capital_full: 'সম্পূর্ণ মূলধন প্রত্যাহার',
                  profit_monthly: 'মাসিক লভ্যাংশ উত্তোলন',
                  profit_annual: 'বাৎসরিক লভ্যাংশ উত্তোলন',
                };

                return (
                  <div
                    key={wth.id}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-400/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-amber-300 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                          {wth.voucherNo || wth.id}
                        </span>
                        <span className="text-xs font-black text-white">
                          {typeLabels[wth.withdrawalType] || wth.withdrawalType}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-bold">
                          ✓ সম্পন্ন
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 space-y-0.5">
                        <p>তারিখ: <b>{formatDateBn(wth.withdrawalDate)}</b> | মাধ্যম: <b>{wth.paymentMethod}</b> {wth.bankName && `(${wth.bankName})`}</p>
                        {wth.reasonOrNote && (
                          <p className="text-slate-400 italic">বিবরণ: {wth.reasonOrNote}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-end sm:self-auto">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block">উত্তোলিত অর্থ:</span>
                        <span className="text-lg font-black text-amber-400 font-mono">
                          ৳ {formatMoney(wth.amount)}
                        </span>
                      </div>

                      {/* 1-Click Print Voucher Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedVoucherDoc(wth)}
                        className="py-1.5 px-3 rounded-xl bg-blue-600/80 hover:bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer border border-blue-400/30 shrink-0"
                        title="A4 সাইজ টাকা উত্তোলন ভাউচার ও রসিদ প্রিন্ট করুন"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>ভাউচার প্রিন্ট</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* ================= 3. WITHDRAWAL APPLICATION & SIGNATURE FORM MODAL ================= */}
      {showWithdrawalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 text-white rounded-3xl max-w-xl w-full shadow-2xl border border-amber-400/40 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-slate-950 p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center shadow-md">
                  <DollarSign className="w-6 h-6 stroke-[3]" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-950">
                    টাকা উত্তোলনের আবেদন ও ভাউচার
                  </h3>
                  <p className="text-[11px] font-bold text-slate-900/80">
                    আঙুল দিয়ে ফোনে স্বাক্ষর করুন বা স্বাক্ষরের ছবি আপলোড করুন
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowWithdrawalModal(false)}
                className="w-8 h-8 rounded-full bg-slate-950/20 hover:bg-slate-950 text-slate-950 hover:text-white flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={handleSubmitWithdrawal} className="p-4 sm:p-6 space-y-4 overflow-y-auto">
              {wthFormError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500 text-rose-200 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{wthFormError}</span>
                </div>
              )}

              {/* Investor Info Recap */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
                <div>
                  <span className="text-slate-400">বিনিয়োগকারী: </span>
                  <strong className="text-white">{loggedInInvestor.investorName}</strong>
                </div>
                <div>
                  <span className="text-slate-400">অবশিষ্ট মূলধন: </span>
                  <strong className="text-emerald-400 font-mono">৳ {formatMoney(remainingCapital)}</strong>
                </div>
              </div>

              {/* Amount & Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-amber-200 mb-1">
                    উত্তোলনের ধরন *
                  </label>
                  <select
                    value={wthType}
                    onChange={(e) => setWthType(e.target.value as WithdrawalType)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white focus:border-amber-400 outline-none"
                  >
                    <option value="profit_monthly">মাসিক লভ্যাংশ উত্তোলন</option>
                    <option value="profit_annual">বাৎসরিক লভ্যাংশ উত্তোলন</option>
                    <option value="capital_partial">মূলধন আংশিক ফেরত উত্তোলন</option>
                    <option value="capital_full">সম্পূর্ণ মূলধন প্রত্যাহার</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-amber-200 mb-1">
                    টাকার পরিমাণ (৳) *
                  </label>
                  <input
                    type="number"
                    required
                    min={100}
                    value={wthAmount}
                    onChange={(e) => setWthAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="যেমন: 10000"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono font-black text-amber-300 text-sm focus:border-amber-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-amber-200 mb-1">
                    উত্তোলনের তারিখ *
                  </label>
                  <input
                    type="date"
                    required
                    value={wthDate}
                    onChange={(e) => setWthDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-white focus:border-amber-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-amber-200 mb-1">
                    পরিশোধের মাধ্যম *
                  </label>
                  <select
                    value={wthPaymentMethod}
                    onChange={(e) => setWthPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white focus:border-amber-400 outline-none"
                  >
                    <option value="bank">ব্যাংক ট্রান্সফার (Bank)</option>
                    <option value="cash">নগদ ক্যাশ (Cash)</option>
                    <option value="cheque">ব্যাংক চেক (Cheque)</option>
                    <option value="bkash">বিকাশ (bKash)</option>
                    <option value="nagad">নগদ (Nagad)</option>
                  </select>
                </div>

                {wthPaymentMethod === 'bank' && (
                  <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-300 mb-1">ব্যাংকের নাম</label>
                      <input
                        type="text"
                        value={wthBankName}
                        onChange={(e) => setWthBankName(e.target.value)}
                        placeholder="যেমন: ইসলামী ব্যাংক বাংলাদেশ লিঃ"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-300 mb-1">একাউন্ট নম্বর</label>
                      <input
                        type="text"
                        value={wthAccountNo}
                        onChange={(e) => setWthAccountNo(e.target.value)}
                        placeholder="একাউন্ট নং"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-white outline-none"
                      />
                    </div>
                  </div>
                )}

                <div className="sm:col-span-2">
                  <label className="block font-bold text-amber-200 mb-1">
                    উত্তোলনের কারণ বা বিশেষ বিবরণ (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={wthReason}
                    onChange={(e) => setWthReason(e.target.value)}
                    placeholder="যেমন: জানুয়ারি মাসের অর্জিত মুনাফা গ্রহণ..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
              </div>

              {/* SIGNATURE SECTION (CRITICAL REQUIREMENT: ফোনের উপর লেখা থেকে সিগনেচারের ছবি আপলোড করার অপশন) */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-amber-400/30 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-black text-amber-300 text-xs flex items-center gap-1.5">
                    <PenTool className="w-4 h-4 text-amber-400" />
                    <span>বিনিয়োগকারীর ডিজিটাল স্বাক্ষর প্রদান *</span>
                  </span>

                  {/* Mode Toggle */}
                  <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setSignatureMode('upload')}
                      className={`px-3 py-1 rounded font-bold cursor-pointer transition ${
                        signatureMode === 'upload'
                          ? 'bg-amber-500 text-slate-950 shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      স্বাক্ষরের ছবি আপলোড (সুপারিশকৃত)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSignatureMode('draw')}
                      className={`px-2.5 py-1 rounded font-bold cursor-pointer transition ${
                        signatureMode === 'draw'
                          ? 'bg-amber-500 text-slate-950 shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      স্ক্রিনে সাইন আঁকা
                    </button>
                  </div>
                </div>

                {signatureMode === 'draw' ? (
                  /* Screen Touch Draw Mode */
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-[10.5px] text-slate-400">
                      <span>👉 ফোনের টাচ স্ক্রিনে বা মাউস দিয়ে আপনার স্বাভাবিক স্বাক্ষরটি আঁকুন:</span>
                      <button
                        type="button"
                        onClick={handleClearSignature}
                        className="text-rose-400 hover:underline font-bold cursor-pointer"
                      >
                        স্বাক্ষর মুছুন
                      </button>
                    </div>

                    <div className="border-2 border-dashed border-amber-400/40 rounded-xl p-1 bg-white">
                      <canvas
                        ref={sigCanvasRef}
                        width={460}
                        height={110}
                        onMouseDown={handleStartDraw}
                        onMouseMove={handleDraw}
                        onMouseUp={handleEndDraw}
                        onMouseLeave={handleEndDraw}
                        onTouchStart={handleStartDraw}
                        onTouchMove={handleDraw}
                        onTouchEnd={handleEndDraw}
                        className="w-full h-24 bg-slate-50 rounded-lg cursor-crosshair touch-none"
                      />
                    </div>
                  </div>
                ) : (
                  /* Image File Upload Mode */
                  <div className="space-y-2">
                    <span className="text-[10.5px] text-slate-400 block">
                      👉 কাগজের উপর করা স্বাক্ষরের স্পষ্ট ছবি নির্বাচন বা ক্যামেরা দিয়ে তুলুন:
                    </span>

                    <input
                      type="file"
                      ref={sigFileInputRef}
                      accept="image/*"
                      className="hidden"
                      onChange={handleSignatureFileUpload}
                    />

                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => sigFileInputRef.current?.click()}
                        className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-400/40 font-bold text-xs flex items-center gap-2 cursor-pointer transition active:scale-95"
                      >
                        <Upload className="w-4 h-4" />
                        <span>{uploadedSignatureUrl ? 'স্বাক্ষরের ছবি পরিবর্তন' : 'স্বাক্ষরের ছবি আপলোড করুন'}</span>
                      </button>

                      {uploadedSignatureUrl && (
                        <div className="w-24 h-12 border border-slate-700 bg-white rounded-lg p-1 flex items-center justify-center overflow-hidden">
                          <img
                            src={uploadedSignatureUrl}
                            alt="Uploaded Signature"
                            className="max-h-full max-w-full object-contain"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowWithdrawalModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingWth}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg transition active:scale-95 cursor-pointer disabled:opacity-50"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>{isSubmittingWth ? 'প্রসেসিং হচ্ছে...' : 'উত্তোলন ভাউচার সম্পন্ন করুন'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= 4. OFFICIAL A4 WITHDRAWAL VOUCHER & RECEIPT MODAL (1-CLICK PRINT & PDF) ================= */}
      {selectedVoucherDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white text-slate-900 rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-300 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            {/* Modal Top Bar */}
            <div className="bg-slate-900 text-white p-3.5 sm:px-6 flex items-center justify-between shrink-0 no-print">
              <div className="flex items-center gap-2.5">
                <Receipt className="w-5 h-5 text-amber-400" />
                <div>
                  <h4 className="font-bold text-sm text-white">
                    A4 টাকা উত্তোলন ভাউচার ও রসিদ — {selectedVoucherDoc.voucherNo}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    বিনিয়োগকারীর মূলধন / মুনাফা বুঝিয়া পাওয়ার অফিশিয়াল প্রত্যয়নপত্র
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintDoc}
                  className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition active:scale-95 cursor-pointer"
                >
                  <Printer className="w-4 h-4 stroke-[2.5]" />
                  <span>১-ক্লিকে A4 প্রিন্ট</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedVoucherDoc(null)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable A4 Container */}
            <div className="p-4 sm:p-8 overflow-y-auto bg-slate-100/60 print:p-0 print:bg-white">
              <div
                id="printableA4WithdrawalVoucher"
                className="w-full max-w-[210mm] min-h-[297mm] mx-auto bg-white p-8 sm:p-12 shadow-md print:shadow-none border border-slate-200 print:border-none text-slate-900 space-y-6 relative"
                style={{ fontFamily: 'sans-serif' }}
              >
                {/* Official Factory Header */}
                <div className="text-center pb-4 border-b-2 border-slate-800 space-y-1">
                  <div className="inline-block px-3 py-0.5 rounded-full bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest mb-1">
                    Official Investment Withdrawal Voucher & Acknowledgment
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
                    {factory.name || 'টেক্স ওয়ার অ্যাপারেলস'}
                  </h1>
                  <p className="text-xs text-slate-700 font-medium">
                    {factory.address || 'কোনাবাড়ী শিল্প এলাকা, গাজীপুর-১৭০০'}
                  </p>
                  <p className="text-[11px] text-slate-600 font-mono">
                    ফোন: {factory.phone}
                  </p>
                </div>

                {/* Voucher Meta Tracking Bar */}
                <div className="flex items-center justify-between text-xs font-bold py-2 border-b border-dashed border-slate-300">
                  <div>
                    <span className="text-slate-500 font-normal">ভাউচার / স্মারক নং: </span>
                    <span className="font-mono text-slate-950">{selectedVoucherDoc.voucherNo}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-normal">তারিখ: </span>
                    <span className="font-mono text-slate-950">{formatDateBn(selectedVoucherDoc.withdrawalDate)}</span>
                  </div>
                </div>

                {/* Voucher Heading */}
                <div className="text-center py-2 bg-amber-50 rounded-xl border border-amber-300">
                  <h2 className="text-base sm:text-lg font-black text-slate-950">
                    বিনিয়োগের অর্থ / লভ্যাংশ উত্তোলন ও প্রাপ্তিস্বীকার রসিদ
                  </h2>
                  <p className="text-[11px] text-amber-900 font-bold">
                    [ কারখানা প্রশাসন ও হিসাব বিভাগ কর্তৃক অনুমোদিত ]
                  </p>
                </div>

                {/* Details Section */}
                <div className="space-y-4 text-xs leading-relaxed">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <p className="text-slate-900">
                      অত্র ভাউচারের মাধ্যমে এই মর্মে প্রত্যয়ন করা যাইতেছে যে, কারখানা বিনিয়োগকারী অংশীদার:
                    </p>
                    <div className="grid grid-cols-2 gap-2 p-3 bg-white rounded-lg border border-slate-200 font-bold">
                      <div>
                        <span className="text-slate-500 font-normal">বিনিয়োগকারীর নাম: </span>
                        <span className="text-slate-950">{selectedVoucherDoc.investorName}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-normal">মোবাইল নম্বর: </span>
                        <span className="text-slate-950 font-mono">{selectedVoucherDoc.investorMobile}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-normal">মূল চুক্তি নম্বর: </span>
                        <span className="text-slate-950 font-mono">{selectedVoucherDoc.agreementNo}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-normal">উত্তোলনের খাত: </span>
                        <span className="text-amber-900">
                          {selectedVoucherDoc.withdrawalType === 'capital_partial'
                            ? 'মূলধন আংশিক ফেরত'
                            : selectedVoucherDoc.withdrawalType === 'capital_full'
                            ? 'সম্পূর্ণ মূলধন প্রত্যাহার'
                            : selectedVoucherDoc.withdrawalType === 'profit_monthly'
                            ? 'মাসিক লভ্যাংশ উত্তোলন'
                            : 'বাৎসরিক মুনাফা'}
                        </span>
                      </div>
                    </div>

                    <p className="text-slate-900 pt-1">
                      তাঁহার বিনিয়োগ চুক্তির অনুকূলে কারখানা কর্তৃপক্ষ হইতে নিম্নে বর্ণিত অর্থ নগদ / ব্যাংক / চেক মারফত স্বজ্ঞানে বুঝিয়া গ্রহণ করিলেন:
                    </p>

                    {/* Amount Banner */}
                    <div className="p-4 bg-emerald-50 rounded-xl border-2 border-emerald-400 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] text-emerald-800 font-bold block">
                          উত্তোলিত মোট টাকার অংক:
                        </span>
                        <span className="text-2xl font-black text-emerald-950 font-mono block">
                          ৳ {formatMoney(selectedVoucherDoc.amount)}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[11px] text-emerald-800 font-bold block">কথায়:</span>
                        <span className="text-sm font-black text-emerald-900">
                          {numberToBengaliWords(selectedVoucherDoc.amount)}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11.5px] text-slate-700 space-y-1 pt-1">
                      <p>
                        <b>পরিশোধের মাধ্যম:</b> {selectedVoucherDoc.paymentMethod}
                        {selectedVoucherDoc.bankName && ` • ব্যাংক: ${selectedVoucherDoc.bankName}`}
                        {selectedVoucherDoc.chequeOrTxnNo && ` • ট্রানজেকশন/চেক নং: ${selectedVoucherDoc.chequeOrTxnNo}`}
                      </p>
                      {selectedVoucherDoc.reasonOrNote && (
                        <p><b>উত্তোলনের বিবরণ বা কারণ:</b> {selectedVoucherDoc.reasonOrNote}</p>
                      )}
                    </div>
                  </div>

                  {/* Legal Release Statement */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-800">
                    <p className="font-bold text-slate-950 mb-1">বিনিয়োগকারীর সম্মতি ও প্রাপ্তিস্বীকার ঘোষণা:</p>
                    <p className="leading-relaxed">
                      "আমি অত্র ভাউচারে উল্লিখিত সর্বমোট <b>৳ {formatMoney(selectedVoucherDoc.amount)}</b> (<span className="underline font-bold">{numberToBengaliWords(selectedVoucherDoc.amount)}</span>) টাকা কারখানা কর্তৃপক্ষ হইতে পূর্ণ সন্তুষ্টির সাথে বুঝিয়া পাইলাম এবং অত্র রসিদে নিজ স্বাক্ষরে তাহা স্বীকার করিলাম।"
                    </p>
                  </div>
                </div>

                {/* Signatures Grid */}
                <div className="pt-12 grid grid-cols-3 gap-6 text-center text-xs">
                  {/* Verified Investor Signature */}
                  <div className="space-y-2">
                    <div className="h-16 flex items-end justify-center pb-1">
                      {selectedVoucherDoc.investorSignatureUrl ? (
                        <img
                          src={selectedVoucherDoc.investorSignatureUrl}
                          alt="Investor Signature"
                          className="max-h-14 max-w-[140px] object-contain"
                        />
                      ) : (
                        <div className="w-32 border-b border-slate-400" />
                      )}
                    </div>
                    <div className="border-t-2 border-slate-800 pt-1">
                      <p className="font-bold text-slate-950">{selectedVoucherDoc.investorName}</p>
                      <p className="text-[10px] text-slate-600 font-bold">গ্রহীতা / বিনিয়োগকারীর স্বাক্ষর</p>
                    </div>
                  </div>

                  {/* Cashier / Accounts */}
                  <div className="space-y-2">
                    <div className="h-16 flex items-end justify-center pb-1">
                      <div className="w-32 border-b border-slate-400" />
                    </div>
                    <div className="border-t-2 border-slate-800 pt-1">
                      <p className="font-bold text-slate-950">হিসাবরক্ষণ কর্মকর্তা</p>
                      <p className="text-[10px] text-slate-600 font-bold">ক্যাশ ও একাউন্টস শাখা</p>
                    </div>
                  </div>

                  {/* Factory MD / Official Stamp */}
                  <div className="space-y-2">
                    <div className="h-16 flex items-end justify-center pb-1">
                      <div className="w-16 h-16 rounded-full border-2 border-dashed border-slate-400 flex items-center justify-center text-[9px] text-slate-400 uppercase font-black">
                        অফিস সিল
                      </div>
                    </div>
                    <div className="border-t-2 border-slate-800 pt-1">
                      <p className="font-bold text-slate-950">ব্যবস্থাপনা কর্তৃপক্ষ</p>
                      <p className="text-[10px] text-slate-600 font-bold">{factory.name}</p>
                    </div>
                  </div>
                </div>

                {/* Footer Meta */}
                <div className="pt-6 border-t border-slate-200 text-center text-[10px] text-slate-400 space-y-0.5">
                  <p>© {factory.name} — বিনিয়োগ হিসাব বিভাগ • ভাউচার আইডি: {selectedVoucherDoc.id}</p>
                  <p>মুদ্রণ তারিখ: {new Date().toLocaleDateString('bn-BD')}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= 5. A4 OFFICIAL AGREEMENT MODAL ================= */}
      {selectedAgreementDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white text-slate-900 rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-300 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            <div className="bg-slate-900 text-white p-3.5 sm:px-6 flex items-center justify-between shrink-0 no-print">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-amber-400" />
                <h4 className="font-bold text-sm text-white">
                  A4 বিনিয়োগ চুক্তিপত্র — {selectedAgreementDoc.agreementNo}
                </h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintDoc}
                  className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition active:scale-95 cursor-pointer"
                >
                  <Printer className="w-4 h-4 stroke-[2.5]" />
                  <span>১-ক্লিকে A4 প্রিন্ট</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedAgreementDoc(null)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-8 overflow-y-auto bg-slate-100/60 print:p-0 print:bg-white">
              <div
                id="printableA4InvestmentAgreement"
                className="w-full max-w-[210mm] min-h-[297mm] mx-auto bg-white p-8 sm:p-12 shadow-md print:shadow-none border border-slate-200 print:border-none text-slate-900 space-y-6 relative"
                style={{ fontFamily: 'sans-serif' }}
              >
                <div className="text-center pb-4 border-b-2 border-slate-800 space-y-1">
                  <div className="inline-block px-3 py-0.5 rounded-full bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest mb-1">
                    Official Investment Agreement & Deed of Partnership
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
                    {factory.name}
                  </h1>
                  <p className="text-xs text-slate-700 font-medium">
                    {factory.address}
                  </p>
                  <p className="text-[11px] text-slate-600 font-mono">
                    ফোন: {factory.phone}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs font-bold py-2 border-b border-dashed border-slate-300">
                  <div>
                    <span className="text-slate-500 font-normal">স্মারক নং: </span>
                    <span className="font-mono text-slate-900">{selectedAgreementDoc.agreementNo}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-normal">তারিখ: </span>
                    <span className="font-mono text-slate-900">{formatDateBn(selectedAgreementDoc.investmentDate)}</span>
                  </div>
                </div>

                <div className="text-center py-2 bg-slate-100 rounded-xl border border-slate-300">
                  <h2 className="text-base sm:text-lg font-black text-slate-950">
                    ব্যবসায়িক বিনিয়োগ ও লাভ-ক্ষতি বণ্টন চুক্তিপত্র
                  </h2>
                </div>

                {/* Parties */}
                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <p className="font-black text-slate-950">১ম পক্ষ (কারখানা কর্তৃপক্ষ):</p>
                    <p className="text-slate-800"><b>{factory.name}</b>, ঠিকানা: {factory.address}</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <p className="font-black text-slate-950">২য় পক্ষ (বিনিয়োগকারী অংশীদার):</p>
                    <p className="text-slate-900"><b>নাম:</b> {selectedAgreementDoc.investorName} | <b>পিতা/স্বামী:</b> {selectedAgreementDoc.investorFatherOrSpouse || '—'}</p>
                    <p className="text-slate-800"><b>মোবাইল:</b> {selectedAgreementDoc.investorMobile} | <b>NID:</b> {selectedAgreementDoc.investorNid}</p>
                    <p className="text-slate-800"><b>ঠিকানা:</b> {selectedAgreementDoc.investorPresentAddress}</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <p className="font-black text-slate-950">মনোনীত নমিনি (উত্তরাধিকারী):</p>
                    <p className="text-slate-800"><b>নাম:</b> {selectedAgreementDoc.nomineeName} ({selectedAgreementDoc.nomineeRelation})</p>
                  </div>
                </div>

                {/* Amount */}
                <div className="p-4 bg-emerald-50 rounded-xl border-2 border-emerald-400 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-emerald-800 font-bold block">বিনিয়োগকৃত মোট অর্থ:</span>
                    <span className="text-2xl font-black text-emerald-950 font-mono">
                      ৳ {formatMoney(selectedAgreementDoc.amount)}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-emerald-800 font-bold block">লভ্যাংশ হার:</span>
                    <span className="text-base font-black text-emerald-900">
                      বার্ষিক {toBengaliNumber(selectedAgreementDoc.profitRatePercent || 0)}%
                    </span>
                  </div>
                </div>

                {/* Signatures */}
                <div className="pt-10 grid grid-cols-2 gap-8 text-center text-xs">
                  <div className="space-y-2">
                    <div className="h-14 flex items-end justify-center">
                      {selectedAgreementDoc.investorSignatureUrl ? (
                        <img
                          src={selectedAgreementDoc.investorSignatureUrl}
                          alt="Signature"
                          className="max-h-12 max-w-[140px] object-contain"
                        />
                      ) : (
                        <div className="w-32 border-b border-slate-400" />
                      )}
                    </div>
                    <div className="border-t border-slate-800 pt-1 font-bold">
                      বিনিয়োগকারীর স্বাক্ষর
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="h-14 flex items-end justify-center">
                      <div className="w-32 border-b border-slate-400" />
                    </div>
                    <div className="border-t border-slate-800 pt-1 font-bold">
                      কারখানা কর্তৃপক্ষের স্বাক্ষর ও সিল
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= 6. OFFICIAL MONEY RECEIPT MODAL ================= */}
      {selectedReceiptDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white text-slate-900 rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-300 overflow-hidden my-4 flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 text-white p-3.5 sm:px-6 flex items-center justify-between shrink-0 no-print">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-400" />
                <h4 className="font-bold text-sm text-white">
                  টাকা প্রাপ্তির মানি রিসিট — {selectedReceiptDoc.agreementNo}
                </h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintDoc}
                  className="py-1.5 px-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>প্রিন্ট রসিদ</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedReceiptDoc(null)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto">
              <div id="printableMoneyReceipt" className="p-6 bg-amber-50/40 rounded-2xl border-2 border-slate-800 space-y-4 text-slate-900">
                <div className="text-center pb-3 border-b-2 border-slate-800 space-y-0.5">
                  <h2 className="text-2xl font-black text-slate-950">{factory.name}</h2>
                  <p className="text-xs text-slate-600">{factory.address}</p>
                  <div className="inline-block px-3 py-0.5 rounded-full bg-slate-900 text-white text-[11px] font-black uppercase mt-1">
                    বিনিয়োগ মূলধন জমা রসিদ (Money Receipt)
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs font-bold">
                  <span>রসিদ নং: <b className="font-mono">{selectedReceiptDoc.agreementNo}</b></span>
                  <span>তারিখ: <b className="font-mono">{formatDateBn(selectedReceiptDoc.investmentDate)}</b></span>
                </div>

                <div className="text-xs space-y-2 leading-relaxed bg-white p-4 rounded-xl border border-slate-200">
                  <p>
                    বিনিয়োগকারী জনাব/জনাবা <b>{selectedReceiptDoc.investorName}</b> (মোবাইল: {selectedReceiptDoc.investorMobile})-এর নিকট হইতে কারখানার উৎপাদন ও ব্যবসা সম্প্রসারণের জন্য সর্বমোট নিম্নের অর্থ বুঝিয়া পাওয়া গেল:
                  </p>
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-300 flex items-center justify-between">
                    <span className="font-black text-emerald-950 text-base">
                      ৳ {formatMoney(selectedReceiptDoc.amount)}
                    </span>
                    <span className="font-bold text-emerald-800">
                      ({numberToBengaliWords(selectedReceiptDoc.amount)})
                    </span>
                  </div>
                </div>

                <div className="pt-8 flex items-center justify-between text-xs">
                  <div className="text-center">
                    <div className="w-28 border-b border-slate-600 mb-1" />
                    <span className="text-[11px] font-bold text-slate-700">বিনিয়োগকারীর স্বাক্ষর</span>
                  </div>
                  <div className="text-center">
                    <div className="w-28 border-b border-slate-600 mb-1" />
                    <span className="text-[11px] font-bold text-slate-900">গ্রহীতার স্বাক্ষর ও সিল</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
