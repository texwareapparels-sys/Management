import React, { useState } from 'react';
import { Employee } from '../types';
import {
  X,
  Key,
  Copy,
  Check,
  Search,
  ExternalLink,
  MessageCircle,
  Phone,
  Lock,
  User,
  Share2,
  FileSpreadsheet
} from 'lucide-react';

interface AllWorkersLoginModalProps {
  employees: Employee[];
  isOpen: boolean;
  onClose: () => void;
  onSelectWorker: (emp: Employee) => void;
  showToast: (msg: string) => void;
}

export const AllWorkersLoginModal: React.FC<AllWorkersLoginModalProps> = ({
  employees,
  isOpen,
  onClose,
  onSelectWorker,
  showToast,
}) => {
  if (!isOpen) return null;

  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const baseUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}`
    : '';

  const getWorkerLink = (emp: Employee) => {
    return `${baseUrl}?mode=worker&workerId=${encodeURIComponent(emp.workerId || '')}&mobile=${encodeURIComponent(emp.mobile || '')}${emp.portalToken ? `&token=${encodeURIComponent(emp.portalToken)}` : ''}`;
  };

  const getWorkerPass = (emp: Employee) => {
    return (
      emp.portalPassword ||
      (emp.mobile ? emp.mobile.replace(/[^0-9]/g, '').slice(-4) : '123456') ||
      '123456'
    );
  };

  const activeEmployees = employees.filter((e) => e.status === 'active');

  const filtered = activeEmployees.filter((emp) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      emp.name.toLowerCase().includes(q) ||
      emp.workerId.toLowerCase().includes(q) ||
      (emp.mobile && emp.mobile.includes(q)) ||
      emp.designation.toLowerCase().includes(q)
    );
  });

  const handleCopyLink = (emp: Employee) => {
    try {
      const link = getWorkerLink(emp);
      navigator.clipboard.writeText(link);
      setCopiedId(emp.id);
      showToast(`${emp.name} এর প্রোফাইল লিংক কপি করা হয়েছে`);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      showToast('লিংক কপি করা সম্ভব হয়নি');
    }
  };

  const handleCopyAllReport = () => {
    try {
      let report = `টেক্স ওয়ার অ্যাপারেলস — সকল কর্মীর ব্যক্তিগত পোর্টাল লগইন ও পাসওয়ার্ড তালিকা:\n\n`;
      activeEmployees.forEach((emp, i) => {
        const pass = getWorkerPass(emp);
        const link = getWorkerLink(emp);
        report += `${i + 1}. ${emp.name} (${emp.workerId})\n`;
        report += `   মোবাইল: ${emp.mobile || 'নেই'} | পাসওয়ার্ড: ${pass}\n`;
        report += `   লিংক: ${link}\n\n`;
      });

      navigator.clipboard.writeText(report);
      showToast('সকল কর্মীর লগইন ও পাসওয়ার্ড রিপোর্ট কপি করা হয়েছে!');
    } catch {
      showToast('রিপোর্ট কপি করা সম্ভব হয়নি');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300 shrink-0">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                সকল শ্রমিকের প্রোফাইল লগইন লিংক ও পাসওয়ার্ড তালিকা
              </h3>
              <p className="text-xs text-indigo-200 mt-0.5">
                মোট সক্রিয় শ্রমিক: {activeEmployees.length} জন • অ্যাডমিন কন্ট্রোল প্যানেল
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2.5 shrink-0">
          <div className="relative w-full sm:w-80">
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="নাম / Worker ID / মোবাইল দিয়ে খুঁজুন..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          </div>

          <button
            type="button"
            onClick={handleCopyAllReport}
            className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white font-black text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shrink-0 shadow-2xs"
            title="সব কর্মীর আইডি, পাসওয়ার্ড ও লিংক একসঙ্গে টেক্সট হিসেবে কপি করুন"
          >
            <Copy className="w-3.5 h-3.5 text-indigo-300" />
            <span>সব কর্মীর পাসওয়ার্ড তালিকা কপি করুন</span>
          </button>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-y-auto p-3">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <Key className="w-8 h-8 mx-auto opacity-30 mb-2" />
              <span>কোনো শ্রমিক পাওয়া যায়নি</span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-bold">
                    <th className="py-2 px-3">শ্রমিকের নাম ও পদ</th>
                    <th className="py-2 px-3">Worker ID</th>
                    <th className="py-2 px-3">মোবাইল নম্বর</th>
                    <th className="py-2 px-3">পাসওয়ার্ড</th>
                    <th className="py-2 px-3 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((emp) => {
                    const pass = getWorkerPass(emp);
                    const link = getWorkerLink(emp);
                    return (
                      <tr key={emp.id} className="hover:bg-indigo-50/30 transition">
                        <td className="py-2.5 px-3">
                          <div className="font-black text-slate-900">{emp.name}</div>
                          <div className="text-[10.5px] text-slate-500">{emp.designation} • {emp.department || 'সুইং'}</div>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-mono font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200 text-[11px]">
                            {emp.workerId}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-800">
                          {emp.mobile || <span className="text-rose-500 font-normal">নেই</span>}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-mono font-black text-slate-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 text-xs">
                            {pass}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleCopyLink(emp)}
                              className={`px-2 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1 transition active:scale-95 cursor-pointer ${
                                copiedId === emp.id
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
                              }`}
                              title="প্রোফাইল লিংক কপি করুন"
                            >
                              {copiedId === emp.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                              <span>{copiedId === emp.id ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                onSelectWorker(emp);
                              }}
                              className="px-2 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] flex items-center gap-1 transition active:scale-95 cursor-pointer"
                              title="পাসওয়ার্ড পরিবর্তন ও হোয়াটসঅ্যাপে পাঠান"
                            >
                              <Key className="w-3 h-3" />
                              <span>কন্ট্রোল</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs shrink-0">
          <span className="text-slate-500 text-[11px]">
            * শ্রমিক এই পাসওয়ার্ড দিয়ে লগইন করে শুধুমাত্র তথ্য দেখতে পারবেন, কোনো পরিবর্তন করতে পারবেন না।
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
