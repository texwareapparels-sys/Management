import { AttendanceRecord, ShiftSettings } from '../types';
import { INITIAL_EMPLOYEES } from './initialData';
import { calculateAttendanceMetrics, DEFAULT_SHIFT_SETTINGS } from './attendanceUtils';

export function generateInitialAttendanceRecords(shift: ShiftSettings = DEFAULT_SHIFT_SETTINGS): AttendanceRecord[] {
  const records: AttendanceRecord[] = [];
  const activeEmployees = INITIAL_EMPLOYEES.filter((e) => e.status === 'active');
  const today = new Date();

  // Generate logs for past 14 days
  for (let d = 14; d >= 0; d--) {
    const targetDate = new Date(today);
    targetDate.setDate(today.getDate() - d);

    // Skip Fridays (Garments weekly holiday)
    const dayOfWeek = targetDate.getDay();
    if (dayOfWeek === 5) continue; // Friday

    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;

    activeEmployees.forEach((emp, index) => {
      // Create interesting, realistic variations per employee
      let inTime = '07:55';
      let outTime = '17:00';
      let status: 'present' | 'absent' | 'late' | 'half_day' | 'leave' = 'present';
      let note = '';

      if (emp.workerId === 'TW-101') {
        // Highly active worker, frequent overtime
        if (d === 3) {
          inTime = '08:30';
          outTime = '18:00';
          status = 'late';
          note = 'যানজটের কারণে লেট';
        } else if (d === 8) {
          inTime = '07:50';
          outTime = '19:30';
          note = 'জরুরি শিপমেন্ট কাটিং ও সুইং ওটি';
        } else {
          inTime = '07:55';
          outTime = d % 2 === 0 ? '19:00' : '17:30';
        }
      } else if (emp.workerId === 'TW-102') {
        // Quality Inspector
        if (d === 5) {
          status = 'absent';
          inTime = '';
          outTime = '';
          note = 'অসুস্থতার জন্য ছুটি';
        } else if (d === 1) {
          inTime = '08:20';
          outTime = '17:00';
          status = 'late';
          note = 'দেরিতে প্রবেশ';
        } else {
          inTime = '07:50';
          outTime = '18:00';
        }
      } else if (emp.workerId === 'TW-103') {
        // Cutting Master
        if (d === 11) {
          inTime = '08:25';
          outTime = '20:00';
          status = 'late';
          note = 'লেট প্রবেশ ও ৩ ঘণ্টা ওটি';
        } else {
          inTime = '07:45';
          outTime = '19:00';
        }
      } else {
        // Other employees
        if (d === 7) {
          status = 'half_day';
          inTime = '08:00';
          outTime = '13:00';
          note = 'হাফ-ডে ছুটি';
        } else {
          inTime = '08:00';
          outTime = '17:00';
        }
      }

      const metrics = calculateAttendanceMetrics(inTime, outTime, shift);

      records.push({
        id: `att_${emp.id}_${dateStr}`,
        employeeId: emp.id,
        workerId: emp.workerId,
        employeeName: emp.name,
        department: emp.department,
        date: dateStr,
        status: status === 'absent' ? 'absent' : (metrics.isLate ? 'late' : status),
        inTime: inTime || undefined,
        outTime: outTime || undefined,
        shiftStart: shift.standardInTime,
        shiftEnd: shift.standardOutTime,
        isLate: metrics.isLate,
        lateMinutes: metrics.lateMinutes,
        otHours: status === 'absent' ? 0 : metrics.otHours,
        note: note || undefined,
        createdAt: targetDate.getTime(),
        updatedAt: targetDate.getTime(),
      });
    });
  }

  return records;
}
