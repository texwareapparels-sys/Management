import { AttendanceRecord, AttendanceStatus, ShiftSettings, EmployeeAttendanceStats } from '../types';

export const DEFAULT_SHIFT_SETTINGS: ShiftSettings = {
  standardInTime: '08:00',
  standardOutTime: '17:00',
  graceMinutes: 15,
  standardHours: 8,
};

/**
 * Returns today's date formatted as YYYY-MM-DD in local time
 */
export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Converts "HH:mm" string to minutes from midnight
 */
export function timeStringToMinutes(timeStr?: string): number | null {
  if (!timeStr) return null;
  const parts = timeStr.trim().split(':');
  if (parts.length < 2) return null;
  const hours = parseInt(parts[0], 10);
  const minutes = parseInt(parts[1], 10);
  if (isNaN(hours) || isNaN(minutes)) return null;
  return hours * 60 + minutes;
}

/**
 * Converts minutes from midnight to "HH:mm" 24h format
 */
export function minutesToTimeString(totalMinutes: number): string {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, totalMinutes));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Converts "HH:mm" 24h time to 12-hour AM/PM Bengali friendly string
 */
export function formatTime12h(timeStr?: string): string {
  if (!timeStr) return '—';
  const mins = timeStringToMinutes(timeStr);
  if (mins === null) return timeStr;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const period = h >= 12 ? 'PM' : 'AM';
  const displayHour = h % 12 === 0 ? 12 : h % 12;
  return `${displayHour}:${String(m).padStart(2, '0')} ${period}`;
}

/**
 * Checks if a date string (YYYY-MM-DD) is a Friday (5 in JS getDay)
 */
export function isFriday(dateStr?: string): boolean {
  if (!dateStr) return false;
  try {
    const cleanDate = dateStr.trim().split('T')[0].split(' ')[0];
    const parts = cleanDate.split('-');
    if (parts.length < 3) return false;
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const d = parseInt(parts[2], 10);
    if (!y || !m || !d) return false;
    const dateObj = new Date(y, m - 1, d, 12, 0, 0);
    return dateObj.getDay() === 5;
  } catch {
    return false;
  }
}

/**
 * Returns Bengali day of week name (রবিবার, সোমবার, ইত্যাদি)
 */
export function getBengaliDayName(dateStr: string): string {
  if (!dateStr) return '';
  try {
    const cleanDate = dateStr.trim().split('T')[0].split(' ')[0];
    const parts = cleanDate.split('-');
    if (parts.length < 3) return '';
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const d = parseInt(parts[2], 10);
    if (!y || !m || !d) return '';
    const dateObj = new Date(y, m - 1, d, 12, 0, 0);
    const days = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
    return days[dateObj.getDay()] || '';
  } catch {
    return '';
  }
}

/**
 * Calculates Friday lunch & prayer break deduction in minutes.
 * On Friday, 1:00 PM (13:00 = 780 mins) to 2:00 PM (14:00 = 840 mins) is deducted from working OT time.
 * (শুক্রবার দুপুর ১:০০টা থেকে ২:০০টা পর্যন্ত ১ ঘণ্টা নামাজের ও দুপুরের খাবারের বিরতি ওটি থেকে বাদ দেওয়া হয়)
 */
export function calculateFridayBreakDeductionMinutes(inMins: number, outMins: number): number {
  if (outMins <= inMins) return 0;
  const breakStart = 13 * 60; // 780 mins (1:00 PM / দুপুর ১:০০টা)
  const breakEnd = 14 * 60;   // 840 mins (2:00 PM / দুপুর ২:০০টা)
  return Math.max(0, Math.min(outMins, breakEnd) - Math.max(inMins, breakStart));
}

/**
 * Returns helper breakdown for Friday lunch & prayer break deduction.
 */
export function getFridayBreakInfo(inTime?: string, outTime?: string): {
  breakMinutes: number;
  breakDeductedHours: number;
  hasBreakDeduction: boolean;
} {
  const inMins = timeStringToMinutes(inTime);
  const outMins = timeStringToMinutes(outTime);
  if (inMins === null || outMins === null || outMins <= inMins) {
    return { breakMinutes: 0, breakDeductedHours: 0, hasBreakDeduction: false };
  }
  const breakMinutes = calculateFridayBreakDeductionMinutes(inMins, outMins);
  const breakDeductedHours = Math.round((breakMinutes / 60) * 2) / 2;
  return {
    breakMinutes,
    breakDeductedHours,
    hasBreakDeduction: breakMinutes > 0,
  };
}

/**
 * Calculates Friday OT hours:
 * 1. All working time is counted as overtime.
 * 2. Deducts 1 hour lunch & Juma prayer break from 1:00 PM to 2:00 PM (দুপুর ১টা থেকে ২টা পর্যন্ত ১ ঘণ্টা ওটি বাদ).
 */
export function calculateFridayOtHours(inTime?: string, outTime?: string): number {
  const inMins = timeStringToMinutes(inTime);
  const outMins = timeStringToMinutes(outTime);
  if (inMins === null || outMins === null || outMins <= inMins) {
    return 0;
  }
  const totalMinutes = outMins - inMins;
  const breakMinutes = calculateFridayBreakDeductionMinutes(inMins, outMins);
  const effectiveMinutes = Math.max(0, totalMinutes - breakMinutes);
  return Math.round((effectiveMinutes / 60) * 2) / 2;
}

/**
 * Calculates whether employee is late, late minutes, and overtime hours worked
 */
export function calculateAttendanceMetrics(
  inTime?: string,
  outTime?: string,
  shift: ShiftSettings = DEFAULT_SHIFT_SETTINGS,
  dateStr?: string
): {
  isLate: boolean;
  lateMinutes: number;
  otHours: number;
  fridayBreakDeductedMinutes?: number;
} {
  const isFri = isFriday(dateStr);

  // On Friday: Weekly holiday! All duty hours count purely as overtime hours (no late penalties)
  // এবং দুপুর ১টা থেকে ২টা পর্যন্ত (১:০০ PM - ২:০০ PM) খাবারের ও নামাজের বিরতি ১ ঘণ্টা ওটি থেকে বাদ দেওয়া হয়।
  if (isFri) {
    const shiftInMins = timeStringToMinutes(shift.standardInTime) ?? (8 * 60); // 08:00
    // If inTime is not explicitly given but outTime is present, fallback to standard shift start
    const inMins = timeStringToMinutes(inTime) ?? (outTime ? shiftInMins : null);
    const outMins = timeStringToMinutes(outTime);
    let otHours = 0;
    let fridayBreakDeductedMinutes = 0;
    if (inMins !== null && outMins !== null && outMins > inMins) {
      fridayBreakDeductedMinutes = calculateFridayBreakDeductionMinutes(inMins, outMins);
      const effectiveMinutes = Math.max(0, (outMins - inMins) - fridayBreakDeductedMinutes);
      otHours = Math.round((effectiveMinutes / 60) * 2) / 2;
    }
    return { isLate: false, lateMinutes: 0, otHours, fridayBreakDeductedMinutes };
  }

  let isLate = false;
  let lateMinutes = 0;
  let otHours = 0;

  const inMins = timeStringToMinutes(inTime);
  const shiftInMins = timeStringToMinutes(shift.standardInTime) ?? (8 * 60); // 08:00
  const grace = shift.graceMinutes || 0;

  if (inMins !== null) {
    if (inMins > (shiftInMins + grace)) {
      isLate = true;
      lateMinutes = inMins - shiftInMins;
    }
  }

  const outMins = timeStringToMinutes(outTime);
  const shiftOutMins = timeStringToMinutes(shift.standardOutTime) ?? (17 * 60); // 17:00

  // Regular days: Overtime calculation
  // 1. Evening overtime (beyond shift standard out time)
  const lateOtMins = (outMins !== null && outMins > shiftOutMins) ? (outMins - shiftOutMins) : 0;
  // 2. Early morning overtime (before shift standard in time)
  const earlyOtMins = (inMins !== null && inMins < shiftInMins) ? (shiftInMins - inMins) : 0;

  const totalOtMins = lateOtMins + earlyOtMins;
  if (totalOtMins > 0) {
    otHours = Math.round((totalOtMins / 60) * 2) / 2;
  }

  return { isLate, lateMinutes, otHours };
}

/**
 * Get status label and badges in Bengali
 */
export function getAttendanceStatusBadge(status: AttendanceStatus, dateStr?: string, otHours?: number) {
  if (dateStr && isFriday(dateStr)) {
    if (typeof otHours === 'number' && otHours > 0) {
      return {
        label: 'শুক্রবার (শুধু ওটি)',
        badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-300',
        dotClass: 'bg-indigo-500',
      };
    }
    return {
      label: 'শুক্রবার (বন্ধ)',
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
      dotClass: 'bg-slate-500',
    };
  }
  switch (status) {
    case 'present':
      return {
        label: 'উপস্থিত',
        badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-300',
        dotClass: 'bg-emerald-500',
      };
    case 'late':
      return {
        label: 'বিলম্ব / লেট',
        badgeClass: 'bg-amber-50 text-amber-700 border-amber-300',
        dotClass: 'bg-amber-500',
      };
    case 'absent':
      return {
        label: 'অনুপস্থিত',
        badgeClass: 'bg-rose-50 text-rose-700 border-rose-300',
        dotClass: 'bg-rose-500',
      };
    case 'half_day':
      return {
        label: 'অর্ধ-দিবস',
        badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-300',
        dotClass: 'bg-indigo-500',
      };
    case 'leave':
      return {
        label: 'ছুটিতে',
        badgeClass: 'bg-blue-50 text-blue-700 border-blue-300',
        dotClass: 'bg-blue-500',
      };
    case 'holiday':
      return {
        label: 'ছুটি / বন্ধ',
        badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
        dotClass: 'bg-slate-500',
      };
    default:
      return {
        label: 'উপস্থিত',
        badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-300',
        dotClass: 'bg-emerald-500',
      };
  }
}

/**
 * Normalizes worker ID / employee ID by converting Bengali digits to English,
 * trimming, and lowercasing for consistent comparisons across modules.
 */
export function normalizeWorkerId(id?: string | number): string {
  if (id === null || id === undefined) return '';
  const str = String(id).trim();
  const bnToEnMap: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9',
  };
  return str.replace(/[০-৯]/g, (d) => bnToEnMap[d] || d).toLowerCase();
}

/**
 * Compute total attendance statistics for an employee across all or a filtered period
 */
export function calculateEmployeeAttendanceStats(
  employeeId: string,
  records: AttendanceRecord[],
  filterMonth?: string, // e.g. "জানুয়ারি", "ফেব্রুয়ারি" etc. or 'all'
  filterYear?: number | string, // e.g. 2026 or 'all' or undefined
  workerId?: string,
  employeeName?: string
): EmployeeAttendanceStats {
  const BENGALI_MONTHS = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const normEmpWId = normalizeWorkerId(workerId);
  const normEmpId = normalizeWorkerId(employeeId);
  const trimmedEmpName = employeeName ? employeeName.trim().toLowerCase() : '';

  const empRecords = records.filter((r) => {
    if (!r) return false;
    const normRecWId = normalizeWorkerId(r.workerId);
    const normRecEId = normalizeWorkerId(r.employeeId);
    const trimmedRecName = r.employeeName ? r.employeeName.trim().toLowerCase() : '';

    const isMatch =
      // Direct raw matches
      (r.employeeId && (r.employeeId === employeeId || (workerId && r.employeeId === workerId))) ||
      (r.workerId && ((workerId && r.workerId === workerId) || r.workerId === employeeId)) ||
      // Normalized ID matches (e.g. '০৯' vs '09' vs '9')
      (normEmpWId && (normRecWId === normEmpWId || normRecEId === normEmpWId || normRecWId.replace(/^0+/, '') === normEmpWId.replace(/^0+/, ''))) ||
      (normEmpId && (normRecEId === normEmpId || normRecWId === normEmpId || normRecWId.replace(/^0+/, '') === normEmpId.replace(/^0+/, ''))) ||
      // Name match
      (trimmedEmpName && trimmedRecName && trimmedRecName === trimmedEmpName);

    if (!isMatch) return false;
    if (!r.date) return false;
    if (filterYear && filterYear !== 'all' && !r.date.startsWith(`${filterYear}`)) return false;
    if (filterMonth && filterMonth !== 'all') {
      const parts = r.date.split('-');
      if (parts.length >= 2) {
        const monthNum = parseInt(parts[1], 10);
        const monthName = BENGALI_MONTHS[monthNum - 1];
        if (monthName !== filterMonth) return false;
      }
    }
    return true;
  });

  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let halfDayCount = 0;
  let leaveCount = 0;
  let fridayOtHours = 0;
  let totalOtHours = 0;
  let fridayDutiesCount = 0;

  empRecords.forEach((r) => {
    const isFri = isFriday(r.date) || r.status === 'holiday' || getBengaliDayName(r.date) === 'শুক্রবার';

    // On Friday: Closed day / Weekly holiday!
    // শুক্রবার এ ot ঘণ্টার সাথে সাথে কখনোই সাধারণ হাজিরা যোগ হবে না। শুধু OT ঘণ্টা হিসাব হবে।
    if (isFri) {
      let ot = Number(r.otHours) || 0;
      // If duty hours entered (inTime and outTime)
      if (r.inTime && r.outTime) {
        const autoOt = calculateFridayOtHours(r.inTime, r.outTime);
        const inMins = timeStringToMinutes(r.inTime);
        const outMins = timeStringToMinutes(r.outTime);
        if (inMins !== null && outMins !== null && outMins > inMins) {
          const rawHours = Math.round(((outMins - inMins) / 60) * 2) / 2;
          // If ot was 0 or equal to un-deducted raw hours, ensure Friday break is applied
          if (ot === 0 || ot === rawHours) {
            ot = autoOt;
          }
        } else if (ot === 0) {
          ot = autoOt;
        }
      }
      if (ot > 0) {
        fridayOtHours += ot;
        totalOtHours += ot;
        fridayDutiesCount++;
      }
      // Note: On Friday, presentCount, absentCount, and lateCount are strictly NOT incremented!
    } else {
      if (r.status === 'present') {
        presentCount++;
      } else if (r.status === 'late') {
        // Note: A late person on regular work day is present, but late!
        presentCount++;
        lateCount++;
      } else if (r.status === 'absent') {
        absentCount++;
      } else if (r.status === 'half_day') {
        halfDayCount++;
        presentCount += 0.5;
      } else if (r.status === 'leave') {
        leaveCount++;
      }

      if (r.otHours && r.otHours > 0) {
        totalOtHours += Number(r.otHours);
      }
    }
  });

  const totalRecords = empRecords.length;
  // Calculate attendance percentage based on total recorded working days (excluding official leaves/holidays)
  const workingDaysTracked = presentCount + absentCount;
  const attendanceRate = workingDaysTracked > 0 
    ? Math.round((presentCount / workingDaysTracked) * 100) 
    : (totalRecords > 0 ? 100 : 0);

  const regularOtHours = Math.max(0, Math.round((totalOtHours - fridayOtHours) * 10) / 10);

  return {
    totalRecords,
    presentCount: Math.round(presentCount * 10) / 10,
    absentCount,
    lateCount,
    halfDayCount,
    leaveCount,
    fridayOtHours: Math.round(fridayOtHours * 10) / 10,
    regularOtHours,
    fridayDutiesCount,
    totalOtHours: Math.round(totalOtHours * 10) / 10,
    attendanceRate,
  };
}

/**
 * Factory Penalty Calculation Rule:
 * ১. প্রতি ৩ দিন লেট করলে ১ দিনের হাজিরা কাটা হবে (Math.floor(lateDays / 3))
 * ২. প্রতি ৩ দিন না বলে অনুপস্থিত থাকলে অতিরিক্ত ১ দিনের হাজিরা কাটা হবে (Math.floor(absentDays / 3))
 * মোট অনুপস্থিতি কর্তন = absentDays + absentPenaltyDays
 * মোট হাজিরা কর্তন দিন = absentDays + absentPenaltyDays + latePenaltyDays
 * কার্যকর বেতন হাজিরা দিন = Math.max(0, presentDays - absentPenaltyDays - latePenaltyDays)
 */
export function calculateFactoryAttendanceDeduction(
  totalDays: number,
  presentDays: number,
  absentDays: number,
  lateDays: number = 0,
  applyFactoryRules: boolean = true
) {
  if (!applyFactoryRules) {
    return {
      absentPenaltyDays: 0,
      latePenaltyDays: 0,
      totalDeductionDays: absentDays,
      effectivePresentDays: presentDays,
    };
  }

  // ৩ দিন অনুপস্থিতিতে অতিরিক্ত ১ দিন জরিমানা
  const absentPenaltyDays = Math.floor(Math.max(0, absentDays) / 3);
  // ৩ দিন লেট করলে ১ দিন জরিমানা
  const latePenaltyDays = Math.floor(Math.max(0, lateDays) / 3);
  // মোট কর্তন দিন
  const totalDeductionDays = Math.max(0, absentDays) + absentPenaltyDays + latePenaltyDays;
  // কার্যকর প্রদেয় হাজিরা দিন (উপস্থিত দিন থেকে পেনাল্টি বাদ)
  const effectivePresentDays = Math.max(0, presentDays - absentPenaltyDays - latePenaltyDays);

  return {
    absentPenaltyDays,
    latePenaltyDays,
    totalDeductionDays,
    effectivePresentDays,
  };
}
