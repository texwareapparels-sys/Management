import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getDatabase,
  ref,
  push,
  set,
  update,
  remove,
  onValue,
  get,
  Database
} from 'firebase/database';
import {
  Employee,
  TelegramSettings,
  SMSSettings,
  FactorySettings,
  SalaryDisbursementRecord,
  SalaryProgressStatus,
  AttendanceRecord,
  ShiftSettings,
  JobApplication,
  JobApplicationStatus,
  WorkerNotice,
  InvestmentRecord,
  InvestmentWithdrawalRecord
} from '../types';
import { normalizeSmsApiUrl } from './sms';
import { INITIAL_EMPLOYEES } from './initialData';
import { DEFAULT_SHIFT_SETTINGS } from './attendanceUtils';
import { generateInitialAttendanceRecords } from './attendanceSeed';

const firebaseConfig = {
  apiKey: "AIzaSyAiqeoFeg5UUQShhsAT-pXHon1KSThqm78",
  authDomain: "tournament-13d76.firebaseapp.com",
  databaseURL: "https://tournament-13d76-default-rtdb.firebaseio.com",
  projectId: "tournament-13d76",
  storageBucket: "tournament-13d76.firebasestorage.app",
  messagingSenderId: "60952664895",
  appId: "1:60952664895:web:05224b06c79d50b5f9918a",
  measurementId: "G-HDQ7EK8BY5"
};

let db: Database | null = null;
try {
  const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  db = getDatabase(app);
} catch (err) {
  console.warn("Firebase initialization warning, using local fallback:", err);
}

const LOCAL_STORAGE_EMP_KEY = 'texware_employees_v2';
const LOCAL_STORAGE_TG_KEY = 'texware_telegram_settings_v2';
const LOCAL_STORAGE_SMS_KEY = 'texware_sms_settings_v2';
const LOCAL_STORAGE_SALARY_KEY = 'texware_salary_records_v1';
const LOCAL_STORAGE_ATTENDANCE_KEY = 'texware_attendance_records_v1';
const LOCAL_STORAGE_SHIFT_KEY = 'texware_shift_settings_v1';
const LOCAL_STORAGE_SEEDED_KEY = 'texware_has_seeded_initial_v2';
const LOCAL_STORAGE_DELETED_KEY = 'texware_deleted_emp_ids_v2';
const LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY = 'texware_has_seeded_attendance_v2';
const LOCAL_STORAGE_DELETED_ATTENDANCE_KEY = 'texware_deleted_attendance_ids_v2';
const LOCAL_STORAGE_DELETED_SALARY_KEY = 'texware_deleted_salary_ids_v1';
const LOCAL_STORAGE_FACTORY_KEY = 'texware_factory_settings_v1';

// Set of deleted employee IDs to prevent zombie restoration from cache or auto-seeds
export function getDeletedEmployeeIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DELETED_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

export function recordDeletedEmployeeId(id: string, workerId?: string) {
  try {
    const set = getDeletedEmployeeIds();
    if (id) set.add(id);
    if (workerId) set.add(workerId);
    localStorage.setItem(LOCAL_STORAGE_DELETED_KEY, JSON.stringify(Array.from(set)));
  } catch (e) {
    console.warn("Could not save deleted ID:", e);
  }
}

// Set of deleted attendance record IDs to prevent resurrection from cache or auto-seed
export function getDeletedAttendanceIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DELETED_ATTENDANCE_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

export function recordDeletedAttendanceIds(ids: string[]) {
  try {
    const set = getDeletedAttendanceIds();
    ids.forEach((id) => {
      if (id) set.add(id);
    });
    localStorage.setItem(
      LOCAL_STORAGE_DELETED_ATTENDANCE_KEY,
      JSON.stringify(Array.from(set))
    );
  } catch (e) {
    console.warn("Could not save deleted attendance ID:", e);
  }
}

export function unmarkDeletedAttendanceId(id: string) {
  try {
    const set = getDeletedAttendanceIds();
    if (set.has(id)) {
      set.delete(id);
      localStorage.setItem(
        LOCAL_STORAGE_DELETED_ATTENDANCE_KEY,
        JSON.stringify(Array.from(set))
      );
    }
  } catch (e) {
    console.warn("Could not unmark deleted attendance ID:", e);
  }
}

// Set of deleted salary record IDs to prevent zombie restoration from cache or auto-sync
export function getDeletedSalaryIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DELETED_SALARY_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

export function recordDeletedSalaryIds(ids: string[]) {
  try {
    const set = getDeletedSalaryIds();
    ids.forEach((id) => {
      if (id) set.add(id);
    });
    localStorage.setItem(
      LOCAL_STORAGE_DELETED_SALARY_KEY,
      JSON.stringify(Array.from(set))
    );
  } catch (e) {
    console.warn("Could not save deleted salary ID:", e);
  }
}

export function unmarkDeletedSalaryId(id: string) {
  try {
    const set = getDeletedSalaryIds();
    if (set.has(id)) {
      set.delete(id);
      localStorage.setItem(
        LOCAL_STORAGE_DELETED_SALARY_KEY,
        JSON.stringify(Array.from(set))
      );
    }
  } catch (e) {
    console.warn("Could not unmark deleted salary ID:", e);
  }
}

// Active in-memory subscribers for synchronous state propagation
const employeeSubscribers = new Set<(employees: Employee[]) => void>();
const salarySubscribers = new Set<(records: SalaryDisbursementRecord[]) => void>();
const attendanceSubscribers = new Set<(records: AttendanceRecord[]) => void>();

function notifyEmployeeSubscribers(list: Employee[]) {
  employeeSubscribers.forEach((cb) => {
    try {
      cb(list);
    } catch (err) {
      console.error("Employee subscriber error:", err);
    }
  });
}

function notifySalarySubscribers(list: SalaryDisbursementRecord[]) {
  salarySubscribers.forEach((cb) => {
    try {
      cb(list);
    } catch (err) {
      console.error("Salary subscriber error:", err);
    }
  });
}

function notifyAttendanceSubscribers(list: AttendanceRecord[]) {
  attendanceSubscribers.forEach((cb) => {
    try {
      cb(list);
    } catch (err) {
      console.error("Attendance subscriber error:", err);
    }
  });
}

// Timeout helper to avoid infinite hanging on mobile/Telegram WebApp proxy connections
async function safeFirebaseAction<T>(actionPromise: Promise<T>, timeoutMs = 3500): Promise<void> {
  try {
    const timeout = new Promise<void>((_, reject) =>
      setTimeout(() => reject(new Error("Firebase action timeout")), timeoutMs)
    );
    await Promise.race([actionPromise, timeout]);
  } catch (e) {
    console.warn("Firebase action timed out or failed (local state kept):", e);
  }
}

/**
 * Recursively cleans an object for Firebase Realtime Database.
 * Firebase strictly rejects any object that contains `undefined` values.
 */
export function cleanForFirebase<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return null as any;
  }
  if (typeof obj !== 'object') {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => cleanForFirebase(item)) as any;
  }
  const clean: Record<string, any> = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== undefined) {
      if (typeof val === 'object' && val !== null) {
        clean[key] = cleanForFirebase(val);
      } else {
        clean[key] = val;
      }
    }
  }
  return clean as T;
}

export function getLocalEmployees(): Employee[] {
  const deletedIds = getDeletedEmployeeIds();
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_EMP_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(
          (e: Employee) => !deletedIds.has(e.id) && !deletedIds.has(e.workerId)
        );
      }
    }
    // Only seed if key doesn't exist yet and no deletions were ever recorded
    if (deletedIds.size === 0) {
      localStorage.setItem(LOCAL_STORAGE_EMP_KEY, JSON.stringify(INITIAL_EMPLOYEES));
      return INITIAL_EMPLOYEES;
    }
    return [];
  } catch (e) {
    return [];
  }
}

export function setLocalEmployees(employees: Employee[]) {
  const deletedIds = getDeletedEmployeeIds();
  const cleaned = employees.filter(
    (e) => !deletedIds.has(e.id) && !deletedIds.has(e.workerId)
  );
  try {
    localStorage.setItem(LOCAL_STORAGE_EMP_KEY, JSON.stringify(cleaned));
  } catch (e) {
    console.error("Local storage error:", e);
  }
  // Immediately dispatch to all active React listeners
  notifyEmployeeSubscribers(cleaned);
}

export function subscribeEmployees(callback: (employees: Employee[]) => void): () => void {
  employeeSubscribers.add(callback);
  // Always emit local data first for instantaneous rendering
  const initial = getLocalEmployees();
  callback(initial);

  if (!db) {
    return () => {
      employeeSubscribers.delete(callback);
    };
  }

  const empRef = ref(db, 'employees');
  const unsubscribe = onValue(
    empRef,
    (snapshot) => {
      const val = snapshot.val();
      const deletedIds = getDeletedEmployeeIds();
      if (val && typeof val === 'object') {
        const list: Employee[] = Object.entries(val)
          .filter(([key, item]: [string, any]) => {
            if (deletedIds.has(key)) return false;
            if (item?.id && deletedIds.has(item.id)) return false;
            if (item?.workerId && deletedIds.has(item.workerId)) return false;
            return true;
          })
          .map(([key, item]: [string, any]) => ({
            id: key,
            name: item.name || '',
            workerId: item.workerId || '',
            designation: item.designation || '',
            department: item.department || '',
            salary: Number(item.salary || 0),
            otRate: Number(item.otRate || 0),
            mobile: item.mobile || '',
            nid: item.nid || '',
            address: item.address || '',
            joinDate: item.joinDate || '',
            birthDate: item.birthDate || '',
            photoUrl: item.photoUrl || '',
            signatureUrl: item.signatureUrl || '',
            portalPassword: item.portalPassword || '',
            bankName: item.bankName || '',
            accountName: item.accountName || '',
            accountNumber: item.accountNumber || '',
            bankBranch: item.bankBranch || '',
            status: item.status || 'active',
            resignationDate: item.resignationDate || '',
            resignationReason: item.resignationReason || '',
            noticeServed: item.noticeServed || 'no',
            clearanceDone: Boolean(item.clearanceDone),
            finalSettlementPaid: Boolean(item.finalSettlementPaid),
            finalSettlementNote: item.finalSettlementNote || '',
            suspensionDate: item.suspensionDate || '',
            suspensionReason: item.suspensionReason || '',
            suspensionDuration: item.suspensionDuration || '',
            terminationDate: item.terminationDate || '',
            terminationReason: item.terminationReason || '',
            terminationMemo: item.terminationMemo || '',
            isBlocked: Boolean(item.isBlocked),
            blockReason: item.blockReason || '',
            blockedAt: item.blockedAt || 0,
            portalToken: item.portalToken || '',
            portalLinkEnabled: item.portalLinkEnabled !== false,
            portalLinkChangedAt: item.portalLinkChangedAt || 0,
            statusChangedAt: item.statusChangedAt || 0,
            createdAt: item.createdAt || Date.now(),
            updatedAt: item.updatedAt || Date.now(),
          }));
        setLocalEmployees(list);
      } else {
        const currentLocal = getLocalEmployees();
        if (currentLocal.length > 0) {
          callback(currentLocal);
          seedFirebaseIfEmpty(currentLocal);
        } else {
          const hasSeeded = localStorage.getItem(LOCAL_STORAGE_SEEDED_KEY);
          if (!hasSeeded && deletedIds.size === 0) {
            localStorage.setItem(LOCAL_STORAGE_SEEDED_KEY, 'true');
            seedFirebaseIfEmpty(initial);
          } else {
            callback([]);
          }
        }
      }
    },
    (error) => {
      console.warn("Firebase onValue error (using local storage fallback):", error);
      callback(getLocalEmployees());
    }
  );

  return () => {
    employeeSubscribers.delete(callback);
    unsubscribe();
  };
}

async function seedFirebaseIfEmpty(employees: Employee[]) {
  if (!db) return;
  try {
    const snap = await get(ref(db, 'employees'));
    if (!snap.exists()) {
      const obj: Record<string, any> = {};
      employees.forEach((emp) => {
        obj[emp.id] = { ...emp };
      });
      await set(ref(db, 'employees'), obj);
    }
  } catch (e) {
    console.warn("Could not seed Firebase:", e);
  }
}

export async function saveOrUpdateEmployee(
  employeeData: Omit<Employee, 'id'>,
  id?: string
): Promise<string> {
  const now = Date.now();
  const currentList = getLocalEmployees();

  if (id) {
    // Update
    const existing = currentList.find((e) => e.id === id);
    const updatedEmployee: Employee = {
      ...(existing || {}),
      ...employeeData,
      id,
      updatedAt: now,
    };
    const nextList = currentList.map((e) => (e.id === id ? updatedEmployee : e));
    setLocalEmployees(nextList);

    if (db) {
      try {
        await update(ref(db, `employees/${id}`), cleanForFirebase({
          ...(existing || {}),
          ...employeeData,
          updatedAt: now,
        }));
      } catch (err) {
        console.warn("Firebase update error, saved locally:", err);
      }
    }
    return id;
  } else {
    // Insert
    let newId = `emp_${Date.now()}`;
    if (db) {
      try {
        const newRef = push(ref(db, 'employees'));
        newId = newRef.key || newId;
        const newEmployee: Employee = {
          ...employeeData,
          id: newId,
          createdAt: now,
          updatedAt: now,
        };
        await set(newRef, cleanForFirebase({
          ...employeeData,
          createdAt: now,
          updatedAt: now,
        }));
        setLocalEmployees([newEmployee, ...currentList]);
        return newId;
      } catch (err) {
        console.warn("Firebase push error, saving locally:", err);
      }
    }

    const localEmployee: Employee = {
      ...employeeData,
      id: newId,
      createdAt: now,
      updatedAt: now,
    };
    setLocalEmployees([localEmployee, ...currentList]);
    return newId;
  }
}

export async function updateResignationStatus(
  id: string,
  data: Partial<Employee>
): Promise<void> {
  const currentList = getLocalEmployees();
  const now = Date.now();
  const updatedList = currentList.map((e) => {
    if (e.id === id) {
      return {
        ...e,
        ...data,
        updatedAt: now,
      };
    }
    return e;
  });
  setLocalEmployees(updatedList);

  if (db) {
    try {
      const cleanData = cleanForFirebase({
        ...data,
        updatedAt: now,
      });
      await safeFirebaseAction(
        update(ref(db, `employees/${id}`), cleanData)
      );
    } catch (err) {
      console.warn("Firebase updateResignationStatus error (local state preserved):", err);
    }
  }
}

export async function deleteEmployeeById(id: string): Promise<void> {
  const currentList = getLocalEmployees();
  const target = currentList.find((e) => e.id === id || e.workerId === id);
  const workerId = target?.workerId;

  // 1. Record as deleted so onValue never restores it from cache/seeds
  recordDeletedEmployeeId(id, workerId);

  // 2. Immediately remove from local list and dispatch to all React components
  const nextList = currentList.filter(
    (e) => e.id !== id && (workerId ? e.workerId !== workerId : true)
  );
  setLocalEmployees(nextList);

  // Helper for direct HTTPS REST API deletion
  const restDelete = async (key: string) => {
    try {
      await fetch(
        `https://tournament-13d76-default-rtdb.firebaseio.com/employees/${encodeURIComponent(key)}.json`,
        { method: 'DELETE' }
      );
    } catch (e) {
      console.warn("REST delete fallback failed:", key, e);
    }
  };

  // Immediate REST call for the primary ID
  await restDelete(id);
  if (workerId && workerId !== id) {
    await restDelete(workerId);
  }

  // 3. Firebase SDK removal and deep scan for any matching employee nodes
  if (db) {
    try {
      await safeFirebaseAction(remove(ref(db, `employees/${id}`)), 1500);
    } catch (e) {
      console.warn("Firebase SDK remove error:", e);
    }

    try {
      const snap = await get(ref(db, 'employees'));
      if (snap.exists()) {
        const val = snap.val();
        if (val && typeof val === 'object') {
          for (const [key, item] of Object.entries(val)) {
            const it = item as any;
            if (
              key === id ||
              it?.id === id ||
              (workerId && (key === workerId || it?.workerId === workerId))
            ) {
              await remove(ref(db, `employees/${key}`)).catch(() => {});
              await restDelete(key);
            }
          }
        }
      }
    } catch (err) {
      console.warn("Firebase scan delete error:", err);
    }
  }
}

export async function loadTelegramSettings(): Promise<TelegramSettings> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_TG_KEY);
    const local = raw ? JSON.parse(raw) : { botToken: '', chatId: '' };
    if (db) {
      try {
        const snap = await get(ref(db, 'settings/telegram'));
        if (snap.exists()) {
          const val = snap.val();
          localStorage.setItem(LOCAL_STORAGE_TG_KEY, JSON.stringify(val));
          return val;
        }
      } catch (e) {}
    }
    return local;
  } catch (e) {
    return { botToken: '', chatId: '' };
  }
}

export async function saveTelegramSettings(settings: TelegramSettings): Promise<void> {
  const updated = { ...settings, updatedAt: Date.now() };
  localStorage.setItem(LOCAL_STORAGE_TG_KEY, JSON.stringify(updated));
  if (db) {
    try {
      await set(ref(db, 'settings/telegram'), updated);
    } catch (e) {
      console.warn("Firebase telegram save error:", e);
    }
  }
}

export async function loadSMSSettings(): Promise<SMSSettings> {
  const defaultSms: SMSSettings = {
    apiUrl: 'https://bulksmsbd.net/api/smsapi',
    apiKey: '',
    senderId: '8809617619482',
    method: 'GET',
    keyParam: 'api_key',
    mobileParam: 'number',
    messageParam: 'message',
    senderParam: 'senderid',
  };
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_SMS_KEY);
    let local = raw ? JSON.parse(raw) : defaultSms;
    if (local?.apiUrl) {
      local.apiUrl = normalizeSmsApiUrl(local.apiUrl);
    }
    if (db) {
      try {
        const snap = await get(ref(db, 'settings/sms'));
        if (snap.exists()) {
          const val = snap.val();
          if (val && typeof val === 'object') {
            val.apiUrl = normalizeSmsApiUrl(val.apiUrl);
          }
          localStorage.setItem(LOCAL_STORAGE_SMS_KEY, JSON.stringify(val));
          return val;
        }
      } catch (e) {}
    }
    return local;
  } catch (e) {
    return defaultSms;
  }
}

export async function saveSMSSettings(settings: SMSSettings): Promise<void> {
  const sanitized = {
    ...settings,
    apiUrl: normalizeSmsApiUrl(settings.apiUrl),
    updatedAt: Date.now(),
  };
  localStorage.setItem(LOCAL_STORAGE_SMS_KEY, JSON.stringify(sanitized));
  if (db) {
    try {
      await set(ref(db, 'settings/sms'), sanitized);
    } catch (e) {
      console.warn("Firebase SMS save error:", e);
    }
  }
}

/* ================= FACTORY & AGREEMENT SETTINGS ================= */
export const DEFAULT_CONTRACT_RULES: string[] = [
  'এই চুক্তি অনির্দিষ্টকালের জন্য কার্যকর থাকবে, তবে শ্রমিক ৩০ দিনের পূর্বে নোটিশ প্রদান সাপেক্ষে চুক্তি বাতিল করতে পারবে। অন্যথায় তাকে কোন বেতন প্রদান করা হবে না, উক্ত কারখানার নিয়ম অনুযায়ী।',
  'প্রতিদিন ৮ ঘন্টা কাজ করতে হবে, এবং প্রয়োজন ক্ষেত্রে অতিরিক্ত সময় কাজ করতে হবে এবং অতিরিক্ত সময় কাজ করলে অভারটাইম ভাতা প্রদান করা হবে।',
  'শ্রমিক সরকার নির্ধারিত বার্ষিক ছুটি, সপ্তাহিক ছুটি, উৎসব ছুটি ভোগ করতে পারবে, উক্ত কারখানার নিয়ম অনুযায়ী।',
  'শ্রমিক কে উক্ত কারখানার সকল নিয়ম-কানুন ও আচারন বিধি মেনে চলতে হবে। শৃঙ্খলা ভঙ্গের অভিযোগ প্রমানিত হলে মালিকপক্ষ যথাযথ ব্যবস্থা নিতে পারবে।',
  'শ্রমিককে পরিচয় পত্র প্রদান করা হবে, এবং শ্রমিক তা বহন করবে।',
  'চাকুরি শেষে পরিচয় পত্র জমা দিতে হবে, জমা না দিলে এবং পরিচয় পত্র হারালে ৫০০ টাকা জরিমানা।',
  'প্রতিদিন নিয়মিত আসলে হাজিরা বোনাস ৫০০ টাকা দেওয়া হবে।',
  '৩ দিন দেরিতে আসলে এবং ৩ দিন না আসলে ১ দিনের হাজিরা কাটা হবে।',
];

export const DEFAULT_CONTRACT_DECLARATION = 'আমি উক্ত কারখানার সকল নিয়ম মেনে কাজ করবো।';

export const DEFAULT_FACTORY_SETTINGS: FactorySettings = {
  name: 'টেক্স ওয়ার অ্যাপারেলস',
  nameEn: 'TexWare Apparels Ltd.',
  address: 'কারখানা কমপ্লেক্স, রোড # ০৩, কোনাবাড়ী বিসিক শিল্প এলাকা, গাজীপুর, ঢাকা।',
  phone: '+৮৮০১৭১২-৩৪৫৬৭৮, +৮৮০১৯১১-২২৩৩৪৪',
  email: 'info@texwareapparels.com',
  contractRules: DEFAULT_CONTRACT_RULES,
  contractDeclaration: DEFAULT_CONTRACT_DECLARATION,
};

export async function loadFactorySettings(): Promise<FactorySettings> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_FACTORY_KEY);
    const local: FactorySettings = raw ? JSON.parse(raw) : DEFAULT_FACTORY_SETTINGS;
    if (db) {
      try {
        const snap = await get(ref(db, 'settings/factory'));
        if (snap.exists()) {
          const val = snap.val();
          const merged: FactorySettings = {
            name: val.name || DEFAULT_FACTORY_SETTINGS.name,
            nameEn: val.nameEn || DEFAULT_FACTORY_SETTINGS.nameEn,
            address: val.address || DEFAULT_FACTORY_SETTINGS.address,
            phone: val.phone || DEFAULT_FACTORY_SETTINGS.phone,
            email: val.email || DEFAULT_FACTORY_SETTINGS.email,
            contractRules: Array.isArray(val.contractRules) && val.contractRules.length > 0
              ? val.contractRules
              : (local.contractRules && local.contractRules.length > 0 ? local.contractRules : DEFAULT_CONTRACT_RULES),
            contractDeclaration: val.contractDeclaration || local.contractDeclaration || DEFAULT_CONTRACT_DECLARATION,
            updatedAt: val.updatedAt || Date.now(),
          };
          localStorage.setItem(LOCAL_STORAGE_FACTORY_KEY, JSON.stringify(merged));
          return merged;
        }
      } catch (e) {}
    }
    return {
      ...DEFAULT_FACTORY_SETTINGS,
      ...local,
      contractRules: Array.isArray(local.contractRules) && local.contractRules.length > 0
        ? local.contractRules
        : DEFAULT_CONTRACT_RULES,
      contractDeclaration: local.contractDeclaration || DEFAULT_CONTRACT_DECLARATION,
    };
  } catch (e) {
    return DEFAULT_FACTORY_SETTINGS;
  }
}

export async function saveFactorySettings(settings: FactorySettings): Promise<void> {
  const updated: FactorySettings = {
    ...settings,
    name: settings.name?.trim() || DEFAULT_FACTORY_SETTINGS.name,
    nameEn: settings.nameEn?.trim() || DEFAULT_FACTORY_SETTINGS.nameEn,
    address: settings.address?.trim() || DEFAULT_FACTORY_SETTINGS.address,
    phone: settings.phone?.trim() || DEFAULT_FACTORY_SETTINGS.phone,
    email: settings.email?.trim() || DEFAULT_FACTORY_SETTINGS.email,
    contractRules: Array.isArray(settings.contractRules) && settings.contractRules.length > 0
      ? settings.contractRules.map((r) => r.trim()).filter((r) => r.length > 0)
      : DEFAULT_CONTRACT_RULES,
    contractDeclaration: settings.contractDeclaration?.trim() || DEFAULT_CONTRACT_DECLARATION,
    updatedAt: Date.now(),
  };
  localStorage.setItem(LOCAL_STORAGE_FACTORY_KEY, JSON.stringify(updated));
  if (db) {
    try {
      await set(ref(db, 'settings/factory'), updated);
    } catch (e) {
      console.warn("Firebase factory settings save error:", e);
    }
  }
}

/* ================= SALARY DISBURSEMENT RECORDS ================= */
export function getLocalSalaryRecords(): SalaryDisbursementRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_SALARY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      const deletedIds = getDeletedSalaryIds();
      return parsed.filter((r) => !deletedIds.has(r.id));
    }
    return [];
  } catch (e) {
    return [];
  }
}

export function setLocalSalaryRecords(records: SalaryDisbursementRecord[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_SALARY_KEY, JSON.stringify(records));
  } catch (e) {
    console.error("Local storage error:", e);
  }
  // Immediately dispatch to all active React listeners
  notifySalarySubscribers(records);
}

export function subscribeSalaryRecords(
  callback: (records: SalaryDisbursementRecord[]) => void
): () => void {
  salarySubscribers.add(callback);
  const initial = getLocalSalaryRecords();
  callback(initial);

  if (!db) {
    return () => {
      salarySubscribers.delete(callback);
    };
  }

  const recRef = ref(db, 'salaryRecords');
  const unsubscribe = onValue(
    recRef,
    (snapshot) => {
      const val = snapshot.val();
      const deletedSalaryIds = getDeletedSalaryIds();
      if (val && typeof val === 'object') {
        const list: SalaryDisbursementRecord[] = Object.entries(val)
          .filter(([key]) => !deletedSalaryIds.has(key))
          .map(([key, item]: [string, any]) => ({
            id: key,
            employeeId: item.employeeId || '',
            employeeName: item.employeeName || '',
            workerId: item.workerId || '',
            designation: item.designation || '',
            department: item.department || '',
            month: item.month || '',
            year: Number(item.year || new Date().getFullYear()),
            salary: Number(item.salary || 0),
            presentDays: Number(item.presentDays || 0),
            totalDays: Number(item.totalDays || 0),
            absentDays: Number(item.absentDays || 0),
            lateDays: Number(item.lateDays || 0),
            absentPenaltyDays: Number(item.absentPenaltyDays || 0),
            latePenaltyDays: Number(item.latePenaltyDays || 0),
            effectivePresentDays: Number(item.effectivePresentDays || 0),
            presentSalary: Number(item.presentSalary || 0),
            otHours: Number(item.otHours || 0),
            otRate: Number(item.otRate || 0),
            otPay: Number(item.otPay || 0),
            bonus: Number(item.bonus || 0),
            advance: Number(item.advance || 0),
            deduction: Number(item.deduction || 0),
            deductionReason: item.deductionReason || '',
            netPayable: Number(item.netPayable || 0),
            paidAmount: Number(item.paidAmount || 0),
            dueAmount: Number(item.dueAmount || 0),
            paymentMethod: item.paymentMethod || 'cash',
            paymentStatus: item.paymentStatus || 'paid',
            progressStatus: item.progressStatus || (item.paymentStatus === 'paid' ? 'disbursed' : 'calculated'),
            statusUpdatedAt: Number(item.statusUpdatedAt || item.paidAt || Date.now()),
            statusUpdatedDate: item.statusUpdatedDate || '',
            paidAt: Number(item.paidAt || Date.now()),
            note: item.note || '',
          }));
        // Sort newest first
        list.sort((a, b) => b.paidAt - a.paidAt);
        setLocalSalaryRecords(list);
      } else {
        const currentLocal = getLocalSalaryRecords();
        if (currentLocal.length > 0) {
          callback(currentLocal);
        } else {
          callback([]);
        }
      }
    },
    (err) => {
      console.warn("Salary records onValue error:", err);
      callback(getLocalSalaryRecords());
    }
  );

  return () => {
    salarySubscribers.delete(callback);
    unsubscribe();
  };
}

export async function saveOrUpdateSalaryRecord(
  recordData: Omit<SalaryDisbursementRecord, 'id'>,
  id?: string
): Promise<string> {
  const currentList = getLocalSalaryRecords();
  const recId = id || `sal_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  // If this record ID was previously deleted, unmark it
  unmarkDeletedSalaryId(recId);

  const newRecord: SalaryDisbursementRecord = {
    ...recordData,
    id: recId,
  };

  const existingIndex = currentList.findIndex((r) => r.id === recId);
  let nextList: SalaryDisbursementRecord[];
  if (existingIndex >= 0) {
    nextList = currentList.map((r) => (r.id === recId ? newRecord : r));
  } else {
    nextList = [newRecord, ...currentList];
  }
  setLocalSalaryRecords(nextList);

  if (db) {
    await safeFirebaseAction(set(ref(db, `salaryRecords/${recId}`), cleanForFirebase(newRecord)));
  }

  return recId;
}

/**
 * Updates or creates salary progress status (হিসাব চলমান, হিসাব সম্পূর্ণ, প্রস্তুত, প্রদান সম্পূর্ণ)
 * along with status update date and audit history.
 */
export async function updateSalaryProgressStatus(
  employee: Employee,
  month: string,
  year: number,
  progressStatus: SalaryProgressStatus,
  statusUpdatedDate: string,
  note?: string,
  calculatedData?: Partial<SalaryDisbursementRecord>
): Promise<string> {
  const currentList = getLocalSalaryRecords();
  const existing = currentList.find(
    (r) =>
      (r.employeeId === employee.id || r.workerId === employee.workerId) &&
      r.month === month &&
      r.year === year
  );

  const recId = existing?.id || `sal_${employee.id}_${month}_${year}`;
  const netPayable = calculatedData?.netPayable ?? existing?.netPayable ?? Number(employee.salary || 0);

  const newRecord: SalaryDisbursementRecord = {
    id: recId,
    employeeId: employee.id,
    employeeName: employee.name,
    workerId: employee.workerId,
    designation: employee.designation,
    department: employee.department || '',
    month,
    year,
    salary: Number(employee.salary || 0),
    presentDays: calculatedData?.presentDays ?? existing?.presentDays ?? 26,
    totalDays: calculatedData?.totalDays ?? existing?.totalDays ?? 26,
    absentDays: calculatedData?.absentDays ?? existing?.absentDays ?? 0,
    lateDays: calculatedData?.lateDays ?? existing?.lateDays ?? 0,
    absentPenaltyDays: calculatedData?.absentPenaltyDays ?? existing?.absentPenaltyDays ?? 0,
    latePenaltyDays: calculatedData?.latePenaltyDays ?? existing?.latePenaltyDays ?? 0,
    effectivePresentDays: calculatedData?.effectivePresentDays ?? existing?.effectivePresentDays ?? 26,
    presentSalary: calculatedData?.presentSalary ?? existing?.presentSalary ?? Number(employee.salary || 0),
    otHours: calculatedData?.otHours ?? existing?.otHours ?? 0,
    otRate: calculatedData?.otRate ?? existing?.otRate ?? Number(employee.otRate || 0),
    otPay: calculatedData?.otPay ?? existing?.otPay ?? 0,
    bonus: calculatedData?.bonus ?? existing?.bonus ?? 0,
    advance: calculatedData?.advance ?? existing?.advance ?? 0,
    deduction: calculatedData?.deduction ?? existing?.deduction ?? 0,
    deductionReason: calculatedData?.deductionReason ?? existing?.deductionReason ?? '',
    netPayable,
    paidAmount: progressStatus === 'disbursed' ? netPayable : (existing?.paidAmount || 0),
    dueAmount: progressStatus === 'disbursed' ? 0 : netPayable,
    paymentMethod: existing?.paymentMethod || 'cash',
    paymentStatus: progressStatus === 'disbursed' ? 'paid' : (existing?.paymentStatus || 'pending'),
    progressStatus,
    statusUpdatedAt: Date.now(),
    statusUpdatedDate,
    paidAt: existing?.paidAt || Date.now(),
    note: note !== undefined ? note : (existing?.note || ''),
  };

  return await saveOrUpdateSalaryRecord(newRecord, recId);
}

export async function deleteSalaryRecordById(id: string): Promise<void> {
  recordDeletedSalaryIds([id]);
  const currentList = getLocalSalaryRecords();
  const nextList = currentList.filter((r) => r.id !== id);
  setLocalSalaryRecords(nextList);

  if (db) {
    await safeFirebaseAction(remove(ref(db, `salaryRecords/${id}`)));
  }
}

export async function deleteSalaryRecordsBatch(ids: string[]): Promise<void> {
  if (!ids || ids.length === 0) return;
  recordDeletedSalaryIds(ids);
  const currentList = getLocalSalaryRecords();
  const idSet = new Set(ids);
  const nextList = currentList.filter((r) => !idSet.has(r.id));
  setLocalSalaryRecords(nextList);

  if (db) {
    const updates: Record<string, null> = {};
    ids.forEach((id) => {
      updates[`salaryRecords/${id}`] = null;
    });
    await safeFirebaseAction(update(ref(db), updates));
  }
}

/**
 * Delete salary records matching month and/or year
 */
export async function deleteSalaryRecordsByMonthYear(
  month?: string,
  year?: number | string
): Promise<number> {
  const currentList = getLocalSalaryRecords();
  const toDelete = currentList.filter((r) => {
    if (month && month !== 'all' && r.month !== month) return false;
    if (year && String(year) !== 'all' && String(r.year) !== String(year)) return false;
    return true;
  });

  const ids = toDelete.map((r) => r.id);
  if (ids.length > 0) {
    await deleteSalaryRecordsBatch(ids);
  }
  return ids.length;
}

/**
 * Permanently delete all salary disbursement records
 */
export async function deleteAllSalaryRecords(): Promise<number> {
  const currentList = getLocalSalaryRecords();
  const ids = currentList.map((r) => r.id);
  if (ids.length > 0) {
    await deleteSalaryRecordsBatch(ids);
  }
  return ids.length;
}

let inMemoryAttendanceList: AttendanceRecord[] = [];

/* ================= ATTENDANCE RECORDS & SHIFT SETTINGS ================= */
export function getLocalAttendanceRecords(): AttendanceRecord[] {
  const deletedAttIds = getDeletedAttendanceIds();
  if (inMemoryAttendanceList.length > 0) {
    return inMemoryAttendanceList.filter((r) => !deletedAttIds.has(r.id));
  }
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_ATTENDANCE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const filtered = parsed.filter((r) => !deletedAttIds.has(r.id));
        if (filtered.length > 0) {
          inMemoryAttendanceList = filtered;
          return filtered;
        }
      }
    }
    const hasSeeded = localStorage.getItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY);
    if (hasSeeded || deletedAttIds.size > 0) {
      // User has already deleted records or already initialized before
      return [];
    }
    // Seed initial realistic attendance records only on the very first launch
    localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY, 'true');
    const initialRecords = generateInitialAttendanceRecords(DEFAULT_SHIFT_SETTINGS);
    inMemoryAttendanceList = initialRecords;
    localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_KEY, JSON.stringify(initialRecords));
    return initialRecords;
  } catch (e) {
    return inMemoryAttendanceList || [];
  }
}

export function deduplicateAttendanceRecords(records: AttendanceRecord[]): AttendanceRecord[] {
  const map = new Map<string, AttendanceRecord>();
  records.forEach((r) => {
    // Unique key per worker per day
    const key = `${r.employeeId || r.workerId}_${r.date}`;
    const existing = map.get(key);
    if (!existing || (r.updatedAt || 0) >= (existing.updatedAt || 0)) {
      map.set(key, r);
    }
  });
  return Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
}

export function setLocalAttendanceRecords(records: AttendanceRecord[]) {
  const cleanList = deduplicateAttendanceRecords(records);
  inMemoryAttendanceList = cleanList;
  try {
    localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_KEY, JSON.stringify(cleanList));
  } catch (e) {
    console.error("Local storage error for attendance:", e);
  }
  // Dispatch to all active listeners
  notifyAttendanceSubscribers(cleanList);
}

export function subscribeAttendanceRecords(
  callback: (records: AttendanceRecord[]) => void
): () => void {
  attendanceSubscribers.add(callback);
  const initial = getLocalAttendanceRecords();
  callback(initial);

  if (!db) {
    return () => {
      attendanceSubscribers.delete(callback);
    };
  }

  const attRef = ref(db, 'attendanceRecords');
  const unsubscribe = onValue(
    attRef,
    (snapshot) => {
      const val = snapshot.val();
      const deletedAttIds = getDeletedAttendanceIds();
      if (val && typeof val === 'object') {
        const remoteList: AttendanceRecord[] = Object.entries(val)
          .filter(([key]) => !deletedAttIds.has(key))
          .map(([key, item]: [string, any]) => ({
            id: key,
            employeeId: item.employeeId || '',
            workerId: item.workerId || '',
            employeeName: item.employeeName || '',
            department: item.department || '',
            date: item.date || '',
            status: item.status || 'present',
            inTime: item.inTime ?? '',
            outTime: item.outTime ?? '',
            shiftStart: item.shiftStart ?? '',
            shiftEnd: item.shiftEnd ?? '',
            isLate: Boolean(item.isLate),
            lateMinutes: Number(item.lateMinutes || 0),
            otHours: Number(item.otHours || 0),
            note: item.note ?? '',
            createdAt: Number(item.createdAt || Date.now()),
            updatedAt: Number(item.updatedAt || Date.now()),
          }));

        // Preserve any local records that haven't been deleted and haven't synced to cloud yet
        const currentLocal = getLocalAttendanceRecords();
        const remoteIdSet = new Set(remoteList.map((r) => r.id));
        const unsyncedLocal = currentLocal.filter(
          (r) => !remoteIdSet.has(r.id) && !deletedAttIds.has(r.id)
        );

        const merged = [...remoteList, ...unsyncedLocal];
        merged.sort((a, b) => b.date.localeCompare(a.date));
        setLocalAttendanceRecords(merged);

        // If there were unsynced local records, push them to Firebase so they are never lost!
        if (unsyncedLocal.length > 0) {
          unsyncedLocal.forEach((r) => {
            safeFirebaseAction(set(ref(db!, `attendanceRecords/${r.id}`), cleanForFirebase(r)));
          });
        }
      } else {
        // If Firebase is completely empty, preserve existing local records!
        const currentLocal = getLocalAttendanceRecords();
        if (currentLocal.length > 0) {
          callback(currentLocal);
          // Sync local records up to Firebase so cloud has them
          seedFirebaseAttendanceIfEmpty(currentLocal);
        } else {
          const hasSeeded = localStorage.getItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY);
          if (!hasSeeded && deletedAttIds.size === 0 && initial.length > 0) {
            localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY, 'true');
            seedFirebaseAttendanceIfEmpty(initial);
          } else {
            callback([]);
          }
        }
      }
    },
    (err) => {
      console.warn("Attendance onValue error, using local fallback:", err);
      callback(getLocalAttendanceRecords());
    }
  );

  return () => {
    attendanceSubscribers.delete(callback);
    unsubscribe();
  };
}

async function seedFirebaseAttendanceIfEmpty(records: AttendanceRecord[]) {
  if (!db || !records.length) return;

  try {
    const snap = await get(ref(db, 'attendanceRecords'));
    if (!snap.exists()) {
      const obj: Record<string, any> = {};
      records.forEach((rec) => {
        obj[rec.id] = cleanForFirebase({
          ...rec,
          inTime: rec.inTime ?? '',
          outTime: rec.outTime ?? '',
          shiftStart: rec.shiftStart ?? DEFAULT_SHIFT_SETTINGS.standardInTime,
          shiftEnd: rec.shiftEnd ?? DEFAULT_SHIFT_SETTINGS.standardOutTime,
          note: rec.note ?? '',
        });
      });
      await safeFirebaseAction(set(ref(db, 'attendanceRecords'), obj));
    }
  } catch (e) {
    console.warn("Could not seed Firebase attendance:", e);
  }
}

export async function saveOrUpdateAttendanceRecord(
  recordData: Omit<AttendanceRecord, 'id'>,
  id?: string
): Promise<string> {
  const currentList = getLocalAttendanceRecords();
  // Standard deterministic key for single employee date if not provided
  const recId = id || (recordData.employeeId && recordData.date 
    ? `att_${recordData.employeeId}_${recordData.date}`
    : `att_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`);

  // Unmark this record ID from deleted IDs so it is never filtered out
  unmarkDeletedAttendanceId(recId);

  const now = Date.now();
  const sanitizedRecord: AttendanceRecord = {
    ...recordData,
    id: recId,
    inTime: recordData.inTime ?? '',
    outTime: recordData.outTime ?? '',
    shiftStart: recordData.shiftStart ?? DEFAULT_SHIFT_SETTINGS.standardInTime,
    shiftEnd: recordData.shiftEnd ?? DEFAULT_SHIFT_SETTINGS.standardOutTime,
    note: recordData.note ?? '',
    createdAt: recordData.createdAt || now,
    updatedAt: now,
  };

  const existingIndex = currentList.findIndex(
    (r) => r.id === recId || (r.employeeId === sanitizedRecord.employeeId && r.date === sanitizedRecord.date)
  );
  let nextList: AttendanceRecord[];
  if (existingIndex >= 0) {
    nextList = currentList.map((r, i) => (i === existingIndex ? sanitizedRecord : r));
  } else {
    nextList = [sanitizedRecord, ...currentList];
  }
  // Sort newest date first
  nextList.sort((a, b) => b.date.localeCompare(a.date));
  setLocalAttendanceRecords(nextList);

  if (db) {
    const payload = cleanForFirebase(sanitizedRecord);
    await safeFirebaseAction(set(ref(db, `attendanceRecords/${recId}`), payload));
  }

  return recId;
}

export async function saveBulkAttendanceRecords(records: AttendanceRecord[]): Promise<void> {
  if (!records.length) return;
  // Unmark all records from deleted attendance IDs
  records.forEach((r) => unmarkDeletedAttendanceId(r.id));

  const currentList = getLocalAttendanceRecords();
  const map = new Map<string, AttendanceRecord>();

  // Load existing
  currentList.forEach((r) => map.set(`${r.employeeId}_${r.date}`, r));
  // Overwrite/merge new
  records.forEach((r) => {
    const sanitized: AttendanceRecord = {
      ...r,
      inTime: r.inTime ?? '',
      outTime: r.outTime ?? '',
      shiftStart: r.shiftStart ?? DEFAULT_SHIFT_SETTINGS.standardInTime,
      shiftEnd: r.shiftEnd ?? DEFAULT_SHIFT_SETTINGS.standardOutTime,
      note: r.note ?? '',
    };
    map.set(`${r.employeeId}_${r.date}`, sanitized);
  });

  const nextList = Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
  setLocalAttendanceRecords(nextList);

  if (db) {
    const updates: Record<string, any> = {};
    records.forEach((r) => {
      const sanitized: AttendanceRecord = {
        ...r,
        inTime: r.inTime ?? '',
        outTime: r.outTime ?? '',
        shiftStart: r.shiftStart ?? DEFAULT_SHIFT_SETTINGS.standardInTime,
        shiftEnd: r.shiftEnd ?? DEFAULT_SHIFT_SETTINGS.standardOutTime,
        note: r.note ?? '',
      };
      updates[`attendanceRecords/${r.id}`] = cleanForFirebase(sanitized);
    });
    await safeFirebaseAction(update(ref(db), updates));
  }
}

export async function deleteAttendanceRecordById(id: string): Promise<void> {
  localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY, 'true');
  recordDeletedAttendanceIds([id]);
  const currentList = getLocalAttendanceRecords();
  const nextList = currentList.filter((r) => r.id !== id);
  setLocalAttendanceRecords(nextList);

  if (db) {
    if (nextList.length === 0) {
      await safeFirebaseAction(remove(ref(db, 'attendanceRecords')));
    } else {
      await safeFirebaseAction(remove(ref(db, `attendanceRecords/${id}`)));
    }
  }
}

export async function deleteBulkAttendanceRecords(ids: string[]): Promise<void> {
  if (!ids || ids.length === 0) return;
  localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY, 'true');
  recordDeletedAttendanceIds(ids);

  const idSet = new Set(ids);
  const currentList = getLocalAttendanceRecords();
  const nextList = currentList.filter((r) => !idSet.has(r.id));
  setLocalAttendanceRecords(nextList);

  if (db) {
    try {
      if (nextList.length === 0) {
        await safeFirebaseAction(remove(ref(db, 'attendanceRecords')));
      } else {
        const updates: Record<string, any> = {};
        ids.forEach((id) => {
          updates[id] = null;
        });
        await safeFirebaseAction(update(ref(db, 'attendanceRecords'), updates));
      }
    } catch (err) {
      console.warn("Firebase bulk delete attendance error:", err);
    }
  }
}

export async function deleteAllAttendanceRecords(): Promise<number> {
  localStorage.setItem(LOCAL_STORAGE_ATTENDANCE_SEEDED_KEY, 'true');
  const currentList = getLocalAttendanceRecords();
  const count = currentList.length;
  const allIds = currentList.map((r) => r.id);
  recordDeletedAttendanceIds(allIds);

  // Set local state to empty
  setLocalAttendanceRecords([]);

  if (db) {
    try {
      await safeFirebaseAction(remove(ref(db, 'attendanceRecords')));
    } catch (err) {
      console.warn("Firebase remove attendanceRecords error:", err);
    }
  }

  return count;
}

export async function clearAttendanceRecordsByFilter(filter: {
  date?: string;
  month?: string;
  year?: number;
  employeeId?: string;
}): Promise<number> {
  const currentList = getLocalAttendanceRecords();
  const matchingRecords = currentList.filter((rec) => {
    if (filter.employeeId && filter.employeeId !== 'all' && rec.employeeId !== filter.employeeId) return false;
    if (filter.date && rec.date !== filter.date) return false;
    if (filter.year && !rec.date.startsWith(`${filter.year}`)) return false;
    if (filter.month && filter.month !== 'all') {
      const targetPrefix = `${filter.year || new Date().getFullYear()}-${filter.month}`;
      if (!rec.date.startsWith(targetPrefix)) return false;
    }
    return true;
  });

  const ids = matchingRecords.map((r) => r.id);
  if (ids.length > 0) {
    await deleteBulkAttendanceRecords(ids);
  }
  return ids.length;
}

export async function loadShiftSettings(): Promise<ShiftSettings> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_SHIFT_KEY);
    const local = raw ? JSON.parse(raw) : DEFAULT_SHIFT_SETTINGS;
    if (db) {
      try {
        const snap = await get(ref(db, 'settings/shift'));
        if (snap.exists()) {
          const val = snap.val();
          localStorage.setItem(LOCAL_STORAGE_SHIFT_KEY, JSON.stringify(val));
          return val;
        }
      } catch (e) {}
    }
    return local;
  } catch (e) {
    return DEFAULT_SHIFT_SETTINGS;
  }
}

export async function saveShiftSettings(settings: ShiftSettings): Promise<void> {
  const updated = { ...settings, updatedAt: Date.now() };
  localStorage.setItem(LOCAL_STORAGE_SHIFT_KEY, JSON.stringify(updated));
  if (db) {
    try {
      await set(ref(db, 'settings/shift'), updated);
    } catch (e) {
      console.warn("Firebase shift settings save error:", e);
    }
  }
}

/* ================= JOB APPLICATIONS (চাকরির আবেদন ও নিয়োগ পোর্টাল) ================= */

const LOCAL_STORAGE_APPLICATIONS_KEY = 'texware_job_applications_v2';
const LOCAL_STORAGE_APP_SEEDED_KEY = 'texware_has_seeded_applications_v1';
const applicationSubscribers = new Set<(apps: JobApplication[]) => void>();

// কোনো ডেমো বা অটো আবেদন রাখা হবে না (ব্যবহারকারীর নির্দেশ অনুযায়ী ক্লিন খালি তালিকা)
const INITIAL_JOB_APPLICATIONS: JobApplication[] = [];

export function getLocalJobApplications(): JobApplication[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_APPLICATIONS_KEY);
    if (!raw) return [];
    const list: JobApplication[] = JSON.parse(raw);
    // ফিল্টার: পূর্বে থাকা কোনো ডেমো/নমুনা ডেটা (app_sample_) স্বয়ংক্রিয়ভাবে বাদ দেওয়া
    return Array.isArray(list) ? list.filter((a) => !a.id.startsWith('app_sample_')) : [];
  } catch {
    return [];
  }
}

export function setLocalJobApplications(apps: JobApplication[]) {
  try {
    const cleaned = apps.filter((a) => !a.id.startsWith('app_sample_'));
    localStorage.setItem(LOCAL_STORAGE_APPLICATIONS_KEY, JSON.stringify(cleaned));
    applicationSubscribers.forEach((cb) => cb(cleaned));
  } catch (e) {
    console.warn("Could not save job applications locally:", e);
  }
}

export function subscribeJobApplications(callback: (apps: JobApplication[]) => void) {
  applicationSubscribers.add(callback);
  callback(getLocalJobApplications());

  if (!db) {
    return () => {
      applicationSubscribers.delete(callback);
    };
  }

  const appsRef = ref(db, 'job_applications');
  const unsubscribe = onValue(
    appsRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        const list: JobApplication[] = Object.keys(val)
          .filter((k) => !k.startsWith('app_sample_'))
          .map((k) => ({
            ...val[k],
            id: k,
          }));
        // Sort descending by creation date
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setLocalJobApplications(list);
      } else {
        const currentLocal = getLocalJobApplications();
        callback(currentLocal);
      }
    },
    (err) => {
      console.warn("Firebase job_applications error, using local fallback:", err);
      callback(getLocalJobApplications());
    }
  );

  return () => {
    applicationSubscribers.delete(callback);
    unsubscribe();
  };
}

/**
 * Submits a new job application from the public online portal
 */
export async function submitJobApplication(
  data: Omit<JobApplication, 'id' | 'createdAt' | 'status' | 'applicationNo'>
): Promise<{ id: string; applicationNo: string }> {
  const now = Date.now();
  const currentList = getLocalJobApplications();
  const yearSuffix = new Date().getFullYear().toString().slice(-2);
  const count = currentList.length + 1;
  const applicationNo = `TW-APP-${yearSuffix}-${String(count).padStart(3, '0')}`;

  let newId = `app_${now}_${Math.random().toString(36).substring(2, 6)}`;

  const newApp: JobApplication = {
    ...data,
    id: newId,
    applicationNo,
    status: 'pending',
    createdAt: now,
    updatedAt: now,
  };

  const updatedList = [newApp, ...currentList];
  setLocalJobApplications(updatedList);

  if (db) {
    try {
      const newRef = push(ref(db, 'job_applications'));
      newId = newRef.key || newId;
      newApp.id = newId;
      await set(newRef, cleanForFirebase({
        ...newApp,
        id: newId,
      }));
    } catch (e) {
      console.warn("Firebase submitJobApplication error, saved locally:", e);
    }
  }

  return { id: newId, applicationNo };
}

/**
 * Rejects a job application with specific reason
 */
export async function rejectJobApplication(
  id: string,
  rejectionReason: string,
  rejectionNote?: string
): Promise<void> {
  const now = Date.now();
  const currentList = getLocalJobApplications();
  const updatedList = currentList.map((app) => {
    if (app.id === id) {
      return {
        ...app,
        status: 'rejected' as JobApplicationStatus,
        rejectionReason: rejectionReason.trim(),
        rejectionNote: rejectionNote?.trim() || '',
        rejectedAt: now,
        updatedAt: now,
      };
    }
    return app;
  });

  setLocalJobApplications(updatedList);

  if (db) {
    try {
      await update(ref(db, `job_applications/${id}`), {
        status: 'rejected',
        rejectionReason: rejectionReason.trim(),
        rejectionNote: rejectionNote?.trim() || '',
        rejectedAt: now,
        updatedAt: now,
      });
    } catch (e) {
      console.warn("Firebase rejectJobApplication error:", e);
    }
  }
}

/**
 * Approves a job application and automatically adds the applicant to the active employee list!
 */
export async function approveJobApplication(
  appId: string,
  employeeData: Omit<Employee, 'id'>
): Promise<{ employeeId: string; workerId: string }> {
  const now = Date.now();

  // 1. Add / Save to Employee list in database
  const createdEmpId = await saveOrUpdateEmployee(employeeData);

  // 2. Update Application status to 'approved'
  const currentList = getLocalJobApplications();
  const updatedList = currentList.map((app) => {
    if (app.id === appId) {
      return {
        ...app,
        status: 'approved' as JobApplicationStatus,
        approvedWorkerId: employeeData.workerId,
        approvedSalary: employeeData.salary,
        approvedAt: now,
        updatedAt: now,
      };
    }
    return app;
  });

  setLocalJobApplications(updatedList);

  if (db) {
    try {
      await update(ref(db, `job_applications/${appId}`), {
        status: 'approved',
        approvedWorkerId: employeeData.workerId,
        approvedSalary: employeeData.salary,
        approvedAt: now,
        updatedAt: now,
      });
    } catch (e) {
      console.warn("Firebase approveJobApplication error:", e);
    }
  }

  return { employeeId: createdEmpId, workerId: employeeData.workerId };
}

/**
 * Deletes a job application
 */
export async function deleteJobApplication(id: string): Promise<void> {
  const currentList = getLocalJobApplications();
  const updatedList = currentList.filter((a) => a.id !== id);
  setLocalJobApplications(updatedList);

  if (db) {
    try {
      await remove(ref(db, `job_applications/${id}`));
    } catch (e) {
      console.warn("Firebase deleteJobApplication error:", e);
    }
  }
}

/* ================= WORKER NOTICES & NOTIFICATION SYSTEM (শ্রমিক নোটিশ বোর্ড) ================= */

const LOCAL_STORAGE_NOTICES_KEY = 'texware_worker_notices_v2';
const LOCAL_STORAGE_DELETED_NOTICES_KEY = 'texware_deleted_notices_v2';

const INITIAL_WORKER_NOTICES: WorkerNotice[] = [
  {
    id: 'notice_default_1',
    title: 'কারখানা সাধারণ নোটিশ: সাপ্তাহিক ছুটি ও ওটি নিয়মাবলী',
    message: 'সকল শ্রমিক ভাই ও বোনদের সদয় অবগতির জন্য জানানো যাচ্ছে যে, প্রতি শুক্রবার সরকারি ও কারখানার সাপ্তাহিক ছুটি বলবৎ থাকবে। জরুরি প্রয়োজনে শুক্রবারে কাজ করলে তা কোনো সাধারণ হাজিরা দিন হিসেবে যোগ হবে না, সম্পূর্ণ সময় বিশেষ ওভারটাইম (OT) হিসেবে গণ্য হবে। শুক্রবার দুপুর ১:০০টা থেকে ২:০০টা পর্যন্ত ১ ঘণ্টা নামাজের বিরতি বাদ দেওয়া হবে।',
    targetType: 'all',
    category: 'holiday',
    priority: 'normal',
    createdBy: 'কারখানা এইচআর ও প্রশাসন',
    createdAt: Date.now() - 86400000 * 2,
    publishedDate: new Date().toISOString().split('T')[0],
    readBy: [],
  },
  {
    id: 'notice_default_2',
    title: 'বেতন প্রস্তুতি ও হাজিরা সংক্রান্ত নির্দেশনা',
    message: 'চলতি মাসের হাজিরা ও ওভারটাইম অডিট সম্পন্ন হলে অ্যাডমিন কর্তৃক "হিসাব সম্পূর্ণ" ও "বেতন দেওয়ার জন্য প্রস্তুত" স্ট্যাটাস দেওয়া হবে। শ্রমিকরা তাদের ব্যক্তিগত প্রোফাইলে লগইন করে বেতন বিবরণী ও পে-স্লিপ দেখতে ও প্রিন্ট করতে পারবেন।',
    targetType: 'all',
    category: 'salary',
    priority: 'important',
    createdBy: 'এইচআর শাখা',
    createdAt: Date.now() - 86400000,
    publishedDate: new Date().toISOString().split('T')[0],
    readBy: [],
  }
];

function getDeletedNoticeIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DELETED_NOTICES_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

function recordDeletedNoticeId(id: string) {
  try {
    const set = getDeletedNoticeIds();
    set.add(id);
    localStorage.setItem(LOCAL_STORAGE_DELETED_NOTICES_KEY, JSON.stringify(Array.from(set)));
  } catch (e) {
    console.warn("Could not save deleted notice ID:", e);
  }
}

export function getLocalWorkerNotices(): WorkerNotice[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_NOTICES_KEY);
    const deleted = getDeletedNoticeIds();
    if (raw) {
      const parsed: WorkerNotice[] = JSON.parse(raw);
      return parsed.filter((n) => !deleted.has(n.id));
    }
  } catch (e) {
    console.warn("Error reading local worker notices:", e);
  }
  return INITIAL_WORKER_NOTICES;
}

const noticeSubscribers = new Set<(notices: WorkerNotice[]) => void>();

export function setLocalWorkerNotices(notices: WorkerNotice[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_NOTICES_KEY, JSON.stringify(notices));
  } catch (e) {
    console.warn("Error saving local worker notices:", e);
  }
  noticeSubscribers.forEach((cb) => {
    try {
      cb(notices);
    } catch (err) {
      console.warn("Notice subscriber error:", err);
    }
  });
}

export function subscribeWorkerNotices(
  callback: (notices: WorkerNotice[]) => void
): () => void {
  noticeSubscribers.add(callback);
  const initial = getLocalWorkerNotices();
  callback(initial);

  if (!db) {
    return () => {
      noticeSubscribers.delete(callback);
    };
  }

  const noticesRef = ref(db, 'worker_notices');
  const unsubscribe = onValue(
    noticesRef,
    (snapshot) => {
      const val = snapshot.val();
      const deleted = getDeletedNoticeIds();
      if (val && typeof val === 'object') {
        const list: WorkerNotice[] = Object.entries(val)
          .filter(([key]) => !deleted.has(key))
          .map(([key, item]: [string, any]) => ({
            id: key,
            title: item.title || '',
            message: item.message || '',
            targetType: item.targetType || 'all',
            targetEmployeeId: item.targetEmployeeId || '',
            targetWorkerId: item.targetWorkerId || '',
            targetEmployeeName: item.targetEmployeeName || '',
            category: item.category || 'general',
            priority: item.priority || 'normal',
            createdBy: item.createdBy || 'কারখানা প্রশাসন',
            createdAt: Number(item.createdAt || Date.now()),
            publishedDate: item.publishedDate || new Date().toISOString().split('T')[0],
            readBy: Array.isArray(item.readBy) ? item.readBy : [],
            confirmations: Array.isArray(item.confirmations) ? item.confirmations : [],
          }));
        list.sort((a, b) => b.createdAt - a.createdAt);
        setLocalWorkerNotices(list);
      } else {
        const local = getLocalWorkerNotices();
        if (local.length > 0) {
          callback(local);
        } else {
          callback(INITIAL_WORKER_NOTICES);
        }
      }
    },
    (err) => {
      console.warn("Worker notices onValue error:", err);
      callback(getLocalWorkerNotices());
    }
  );

  return () => {
    noticeSubscribers.delete(callback);
    unsubscribe();
  };
}

export async function saveOrUpdateWorkerNotice(
  noticeData: Omit<WorkerNotice, 'id'>,
  id?: string
): Promise<string> {
  const currentList = getLocalWorkerNotices();
  const noticeId = id || `notice_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  const newNotice: WorkerNotice = {
    ...noticeData,
    id: noticeId,
  };

  const existingIndex = currentList.findIndex((n) => n.id === noticeId);
  let nextList: WorkerNotice[];
  if (existingIndex >= 0) {
    nextList = currentList.map((n) => (n.id === noticeId ? newNotice : n));
  } else {
    nextList = [newNotice, ...currentList];
  }

  setLocalWorkerNotices(nextList);

  if (db) {
    await safeFirebaseAction(set(ref(db, `worker_notices/${noticeId}`), cleanForFirebase(newNotice)));
  }

  return noticeId;
}

export async function deleteWorkerNoticeById(id: string): Promise<void> {
  recordDeletedNoticeId(id);
  const currentList = getLocalWorkerNotices();
  const nextList = currentList.filter((n) => n.id !== id);
  setLocalWorkerNotices(nextList);

  if (db) {
    await safeFirebaseAction(remove(ref(db, `worker_notices/${id}`)));
  }
}

export async function markNoticeAsRead(noticeId: string, employeeId: string): Promise<void> {
  if (!noticeId || !employeeId) return;
  const currentList = getLocalWorkerNotices();
  const target = currentList.find((n) => n.id === noticeId);
  if (!target) return;
  const readBy = new Set(target.readBy || []);
  if (readBy.has(employeeId)) return;
  readBy.add(employeeId);

  const updatedNotice: WorkerNotice = {
    ...target,
    readBy: Array.from(readBy),
  };

  const nextList = currentList.map((n) => (n.id === noticeId ? updatedNotice : n));
  setLocalWorkerNotices(nextList);

  if (db) {
    await safeFirebaseAction(update(ref(db, `worker_notices/${noticeId}`), {
      readBy: Array.from(readBy),
    }));
  }
}

export const markWorkerNoticeAsRead = markNoticeAsRead;

export async function confirmWorkerNotice(
  noticeId: string,
  employee: { id: string; workerId?: string; name: string }
): Promise<void> {
  if (!noticeId || !employee?.id) return;
  const currentList = getLocalWorkerNotices();
  const target = currentList.find((n) => n.id === noticeId);
  if (!target) return;

  const readBy = new Set(target.readBy || []);
  readBy.add(employee.id);

  const existingConfirmations = Array.isArray(target.confirmations) ? target.confirmations : [];
  let nextConfirmations = existingConfirmations;
  if (!existingConfirmations.some((c) => c.employeeId === employee.id)) {
    nextConfirmations = [
      ...existingConfirmations,
      {
        employeeId: employee.id,
        workerId: employee.workerId || '',
        workerName: employee.name,
        confirmedAt: Date.now(),
      },
    ];
  }

  const updatedNotice: WorkerNotice = {
    ...target,
    readBy: Array.from(readBy),
    confirmations: nextConfirmations,
  };

  const nextList = currentList.map((n) => (n.id === noticeId ? updatedNotice : n));
  setLocalWorkerNotices(nextList);

  if (db) {
    await safeFirebaseAction(
      update(
        ref(db, `worker_notices/${noticeId}`),
        cleanForFirebase({
          readBy: Array.from(readBy),
          confirmations: nextConfirmations,
        })
      )
    );
  }
}

/* ================= WORKER PROFILE BLOCK / UNBLOCK ================= */
export async function blockEmployeeProfile(
  id: string,
  reason: string
): Promise<void> {
  const currentList = getLocalEmployees();
  const now = Date.now();
  const trimmedReason = reason.trim() || 'কারখানা প্রশাসন কর্তৃক সাময়িকভাবে অ্যাকাউন্ট ব্লক করা হয়েছে।';
  const updatedList = currentList.map((e) => {
    if (e.id === id) {
      return {
        ...e,
        isBlocked: true,
        blockReason: trimmedReason,
        blockedAt: now,
        updatedAt: now,
      };
    }
    return e;
  });
  setLocalEmployees(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `employees/${id}`), {
          isBlocked: true,
          blockReason: trimmedReason,
          blockedAt: now,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase blockEmployeeProfile error:", e);
    }
  }
}

export async function unblockEmployeeProfile(id: string): Promise<void> {
  const currentList = getLocalEmployees();
  const now = Date.now();
  const updatedList = currentList.map((e) => {
    if (e.id === id) {
      return {
        ...e,
        isBlocked: false,
        blockReason: '',
        blockedAt: undefined,
        updatedAt: now,
      };
    }
    return e;
  });
  setLocalEmployees(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `employees/${id}`), {
          isBlocked: false,
          blockReason: '',
          blockedAt: null,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase unblockEmployeeProfile error:", e);
    }
  }
}

/* ================= WORKER PORTAL LINK MANAGEMENT ================= */
export async function regenerateWorkerPortalLink(
  id: string,
  customToken?: string
): Promise<string> {
  const currentList = getLocalEmployees();
  const now = Date.now();
  const token =
    customToken?.trim() ||
    `w_${now.toString(36)}_${Math.random().toString(36).substring(2, 8)}`;
  const updatedList = currentList.map((e) => {
    if (e.id === id) {
      return {
        ...e,
        portalToken: token,
        portalLinkEnabled: true,
        portalLinkChangedAt: now,
        updatedAt: now,
      };
    }
    return e;
  });
  setLocalEmployees(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `employees/${id}`), {
          portalToken: token,
          portalLinkEnabled: true,
          portalLinkChangedAt: now,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase regenerateWorkerPortalLink error:", e);
    }
  }
  return token;
}

export async function toggleWorkerPortalLink(
  id: string,
  enabled: boolean
): Promise<void> {
  const currentList = getLocalEmployees();
  const now = Date.now();
  const updatedList = currentList.map((e) => {
    if (e.id === id) {
      return {
        ...e,
        portalLinkEnabled: enabled,
        updatedAt: now,
      };
    }
    return e;
  });
  setLocalEmployees(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `employees/${id}`), {
          portalLinkEnabled: enabled,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase toggleWorkerPortalLink error:", e);
    }
  }
}

/* ================= CLEAR ALL DEMO EMPLOYEES ================= */
export async function clearAllDemoEmployees(): Promise<number> {
  const currentList = getLocalEmployees();
  const demoWorkers = currentList.filter(
    (e) =>
      e.id.startsWith('emp_init_') ||
      ['TW-101', 'TW-102', 'TW-103', 'TW-104'].includes(e.workerId)
  );

  if (demoWorkers.length === 0) return 0;

  for (const emp of demoWorkers) {
    await deleteEmployeeById(emp.id);
  }
  return demoWorkers.length;
}

/* ================= INVESTMENTS PERSISTENCE & RTDB ================= */
const LOCAL_STORAGE_INVESTMENTS_KEY = 'texware_investments_v1';
const investmentSubscribers = new Set<(investments: InvestmentRecord[]) => void>();

function notifyInvestmentSubscribers(list: InvestmentRecord[]) {
  investmentSubscribers.forEach((cb) => {
    try {
      cb(list);
    } catch (e) {
      console.error("Investment subscriber error:", e);
    }
  });
}

export function getLocalInvestments(): InvestmentRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_INVESTMENTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      }
    }
    return [];
  } catch {
    return [];
  }
}

export function setLocalInvestments(investments: InvestmentRecord[]) {
  const sorted = [...investments].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  try {
    localStorage.setItem(LOCAL_STORAGE_INVESTMENTS_KEY, JSON.stringify(sorted));
  } catch (e) {
    console.error("Local storage error for investments:", e);
  }
  notifyInvestmentSubscribers(sorted);
}

export function subscribeInvestments(callback: (investments: InvestmentRecord[]) => void): () => void {
  investmentSubscribers.add(callback);
  callback(getLocalInvestments());

  if (db) {
    const investmentsRef = ref(db, 'investments');
    const unsub = onValue(
      investmentsRef,
      (snapshot) => {
        const val = snapshot.val();
        if (val) {
          const list: InvestmentRecord[] = Object.keys(val).map((k) => ({
            ...val[k],
            id: k,
          }));
          list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
          setLocalInvestments(list);
        } else {
          setLocalInvestments(getLocalInvestments());
        }
      },
      (err) => {
        console.warn("Investments onValue error, using local fallback:", err);
        callback(getLocalInvestments());
      }
    );

    return () => {
      investmentSubscribers.delete(callback);
      unsub();
    };
  }

  return () => {
    investmentSubscribers.delete(callback);
  };
}

export async function saveOrUpdateInvestment(
  data: Omit<InvestmentRecord, 'id' | 'createdAt' | 'updatedAt'>,
  id?: string
): Promise<string> {
  const currentList = getLocalInvestments();
  const now = Date.now();
  const recordId = id || `inv_${now}_${Math.random().toString(36).substring(2, 6)}`;

  const record: InvestmentRecord = {
    ...data,
    id: recordId,
    createdAt: (id && currentList.find((x) => x.id === id)?.createdAt) || now,
    updatedAt: now,
  };

  const nextList = id
    ? currentList.map((item) => (item.id === id ? record : item))
    : [record, ...currentList];

  setLocalInvestments(nextList);

  if (db) {
    try {
      await safeFirebaseAction(
        set(ref(db, `investments/${recordId}`), cleanForFirebase(record))
      );
    } catch (e) {
      console.warn("Firebase save investment error:", e);
    }
  }

  return recordId;
}

export async function deleteInvestmentById(id: string): Promise<void> {
  const currentList = getLocalInvestments();
  const nextList = currentList.filter((item) => item.id !== id);
  setLocalInvestments(nextList);

  if (db) {
    try {
      await safeFirebaseAction(remove(ref(db, `investments/${id}`)));
    } catch (e) {
      console.warn("Firebase delete investment error:", e);
    }
  }
}

/* ================= INVESTOR BLOCK / UNBLOCK & CREDENTIALS ================= */
export async function blockInvestorProfile(
  id: string,
  reason: string
): Promise<void> {
  const currentList = getLocalInvestments();
  const now = Date.now();
  const trimmedReason = reason.trim() || 'কারখানা প্রশাসন কর্তৃক সাময়িকভাবে অ্যাকাউন্ট ব্লক করা হয়েছে।';
  const updatedList = currentList.map((inv) => {
    if (inv.id === id) {
      return {
        ...inv,
        isBlocked: true,
        blockReason: trimmedReason,
        blockedAt: now,
        updatedAt: now,
      };
    }
    return inv;
  });
  setLocalInvestments(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `investments/${id}`), {
          isBlocked: true,
          blockReason: trimmedReason,
          blockedAt: now,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase blockInvestorProfile error:", e);
    }
  }
}

export async function unblockInvestorProfile(id: string): Promise<void> {
  const currentList = getLocalInvestments();
  const now = Date.now();
  const updatedList = currentList.map((inv) => {
    if (inv.id === id) {
      return {
        ...inv,
        isBlocked: false,
        blockReason: '',
        blockedAt: undefined,
        updatedAt: now,
      };
    }
    return inv;
  });
  setLocalInvestments(updatedList);
  if (db) {
    try {
      await safeFirebaseAction(
        update(ref(db, `investments/${id}`), {
          isBlocked: false,
          blockReason: '',
          blockedAt: null,
          updatedAt: now,
        })
      );
    } catch (e) {
      console.warn("Firebase unblockInvestorProfile error:", e);
    }
  }
}

export async function updateInvestorCredentials(
  id: string,
  mobile: string,
  password?: string
): Promise<void> {
  const currentList = getLocalInvestments();
  const now = Date.now();
  const updatedList = currentList.map((inv) => {
    if (inv.id === id) {
      return {
        ...inv,
        investorMobile: mobile.trim() || inv.investorMobile,
        portalPassword: password !== undefined ? password.trim() : inv.portalPassword,
        updatedAt: now,
      };
    }
    return inv;
  });
  setLocalInvestments(updatedList);
  if (db) {
    try {
      const payload: Record<string, any> = {
        investorMobile: mobile.trim(),
        updatedAt: now,
      };
      if (password !== undefined) {
        payload.portalPassword = password.trim();
      }
      await safeFirebaseAction(update(ref(db, `investments/${id}`), payload));
    } catch (e) {
      console.warn("Firebase updateInvestorCredentials error:", e);
    }
  }
}

/* ================= INVESTMENT WITHDRAWALS (টাকা উত্তোলন ভাউচার ও রসিদ) ================= */
const LOCAL_STORAGE_WITHDRAWALS_KEY = 'texware_invest_withdrawals_v1';
const withdrawalSubscribers = new Set<(list: InvestmentWithdrawalRecord[]) => void>();

function notifyWithdrawalSubscribers(list: InvestmentWithdrawalRecord[]) {
  withdrawalSubscribers.forEach((cb) => {
    try {
      cb(list);
    } catch (e) {
      console.error("Withdrawal subscriber error:", e);
    }
  });
}

export function getLocalWithdrawals(): InvestmentWithdrawalRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_WITHDRAWALS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      }
    }
    return [];
  } catch {
    return [];
  }
}

export function setLocalWithdrawals(withdrawals: InvestmentWithdrawalRecord[]) {
  const sorted = [...withdrawals].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  try {
    localStorage.setItem(LOCAL_STORAGE_WITHDRAWALS_KEY, JSON.stringify(sorted));
  } catch (e) {
    console.error("Local storage error for withdrawals:", e);
  }
  notifyWithdrawalSubscribers(sorted);
}

export function subscribeWithdrawals(
  callback: (withdrawals: InvestmentWithdrawalRecord[]) => void
): () => void {
  withdrawalSubscribers.add(callback);
  callback(getLocalWithdrawals());

  if (db) {
    const wthRef = ref(db, 'investment_withdrawals');
    const unsub = onValue(
      wthRef,
      (snapshot) => {
        const val = snapshot.val();
        if (val) {
          const list: InvestmentWithdrawalRecord[] = Object.keys(val).map((k) => ({
            ...val[k],
            id: k,
          }));
          list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
          setLocalWithdrawals(list);
        } else {
          setLocalWithdrawals(getLocalWithdrawals());
        }
      },
      (err) => {
        console.warn("Withdrawals onValue error, using local fallback:", err);
        callback(getLocalWithdrawals());
      }
    );

    return () => {
      withdrawalSubscribers.delete(callback);
      unsub();
    };
  }

  return () => {
    withdrawalSubscribers.delete(callback);
  };
}

export async function saveOrUpdateWithdrawal(
  data: Omit<InvestmentWithdrawalRecord, 'id' | 'createdAt' | 'updatedAt'>,
  id?: string
): Promise<string> {
  const currentList = getLocalWithdrawals();
  const now = Date.now();
  const recordId = id || `wth_${now}_${Math.random().toString(36).substring(2, 6)}`;

  const record: InvestmentWithdrawalRecord = {
    ...data,
    id: recordId,
    voucherNo: data.voucherNo || `WTH-VOUCHER-${new Date().getFullYear()}-${String(currentList.length + 1).padStart(3, '0')}`,
    createdAt: (id && currentList.find((x) => x.id === id)?.createdAt) || now,
    updatedAt: now,
  };

  const nextList = id
    ? currentList.map((item) => (item.id === id ? record : item))
    : [record, ...currentList];

  setLocalWithdrawals(nextList);

  if (db) {
    try {
      await safeFirebaseAction(
        set(ref(db, `investment_withdrawals/${recordId}`), cleanForFirebase(record))
      );
    } catch (e) {
      console.warn("Firebase save withdrawal error:", e);
    }
  }

  return recordId;
}

export async function deleteWithdrawalById(id: string): Promise<void> {
  const currentList = getLocalWithdrawals();
  const nextList = currentList.filter((item) => item.id !== id);
  setLocalWithdrawals(nextList);

  if (db) {
    try {
      await safeFirebaseAction(remove(ref(db, `investment_withdrawals/${id}`)));
    } catch (e) {
      console.warn("Firebase delete withdrawal error:", e);
    }
  }
}
