/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Employee } from './types';
import { subscribeEmployees, subscribeJobApplications } from './lib/firebase';
import { initTelegramWebApp } from './lib/telegram';
import { Header, AppMode } from './components/Header';
import { UserSalaryApp } from './components/UserSalaryApp';
import { AdminPanel, AdminTab } from './components/AdminPanel';
import { JobApplicationForm } from './components/JobApplicationForm';
import { WorkerPortal } from './components/WorkerPortal';
import { InvestmentHub } from './components/InvestmentHub';
import { InvestorPortal } from './components/InvestorPortal';
import { ResignationModal } from './components/ResignationModal';
import { ResignationLetterModal } from './components/ResignationLetterModal';
import { SuspensionNoticeModal } from './components/SuspensionNoticeModal';
import { TerminationNoticeModal } from './components/TerminationNoticeModal';
import { Toast } from './components/Toast';

export default function App() {
  const [currentTab, setCurrentTab] = useState<AppMode>('user');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [pendingApplicationsCount, setPendingApplicationsCount] = useState<number>(0);
  const [urlWorkerId, setUrlWorkerId] = useState<string>('');
  const [urlMobile, setUrlMobile] = useState<string>('');
  const [urlToken, setUrlToken] = useState<string>('');
  const [resignationModalEmp, setResignationModalEmp] = useState<Employee | null>(null);
  const [resignationLetterEmp, setResignationLetterEmp] = useState<Employee | null>(null);
  const [suspensionNoticeEmp, setSuspensionNoticeEmp] = useState<Employee | null>(null);
  const [terminationNoticeEmp, setTerminationNoticeEmp] = useState<Employee | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Subscribe to Firebase RTDB and synchronized local storage & Init Telegram
  useEffect(() => {
    initTelegramWebApp();
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const mode = params.get('mode');
      const tab = params.get('tab');
      const admin = params.get('admin');
      const wid = params.get('workerId') || params.get('id') || params.get('investorId') || params.get('agreementNo') || '';
      const mob = params.get('mobile') || params.get('investorMobile') || '';
      const tok = params.get('token') || params.get('key') || '';
      if (wid) setUrlWorkerId(wid);
      if (mob) setUrlMobile(mob);
      if (tok) setUrlToken(tok);

      if (mode === 'investor' || tab === 'investor') {
        setCurrentTab('investor');
      } else if (mode === 'worker' || tab === 'worker') {
        setCurrentTab('worker');
      } else if (mode === 'apply' || tab === 'apply') {
        setCurrentTab('apply');
      } else if (mode === 'applications' || tab === 'applications') {
        setCurrentTab('applications');
      } else if (mode === 'investment' || tab === 'investment') {
        setCurrentTab('investment');
      } else if (
        tab === 'attendance' ||
        tab === 'salaries' ||
        tab === 'password' ||
        tab === 'telegram' ||
        tab === 'sms' ||
        tab === 'factory'
      ) {
        setCurrentTab(tab as AppMode);
      } else if (mode === 'admin' || admin === 'true' || admin === '1') {
        setCurrentTab('admin');
      }
    }
    const unsubscribeEmps = subscribeEmployees((data) => {
      setEmployees(data);
    });
    const unsubscribeApps = subscribeJobApplications((apps) => {
      const p = apps.filter((a) => a.status === 'pending').length;
      setPendingApplicationsCount(p);
    });
    return () => {
      unsubscribeEmps();
      unsubscribeApps();
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const activeEmployees = employees.filter((e) => e.status === 'active');
  const resignedEmployees = employees.filter((e) => e.status === 'resigned');
  const suspendedEmployees = employees.filter((e) => e.status === 'suspended');
  const terminatedEmployees = employees.filter((e) => e.status === 'terminated');

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-900 pb-12">
      <div className="w-full max-w-3xl mx-auto p-3 sm:p-5">
        {/* Header with quick stats & tab toggle (Hidden in Job Application Link & Investor Portal Link Mode) */}
        {currentTab !== 'apply' && currentTab !== 'investor' && (
          <Header
            currentTab={currentTab}
            onTabChange={setCurrentTab}
            activeCount={activeEmployees.length}
            resignedCount={resignedEmployees.length}
            suspendedCount={suspendedEmployees.length}
            terminatedCount={terminatedEmployees.length}
            totalCount={employees.length}
            pendingApplicationsCount={pendingApplicationsCount}
          />
        )}

        {/* Main Content Areas */}
        <main>
          {currentTab === 'investor' ? (
            <InvestorPortal
              initialInvestorId={urlWorkerId}
              initialMobile={urlMobile}
              onBackToApp={() => setCurrentTab('user')}
              showToast={showToast}
            />
          ) : currentTab === 'worker' ? (
            <WorkerPortal
              employees={employees}
              initialWorkerId={urlWorkerId}
              initialMobile={urlMobile}
              initialToken={urlToken}
              onBackToApp={() => setCurrentTab('user')}
              showToast={showToast}
            />
          ) : currentTab === 'apply' ? (
            <JobApplicationForm
              onBackToApp={() => setCurrentTab('user')}
              showToast={showToast}
              isStandalone={true}
            />
          ) : currentTab === 'investment' ? (
            <InvestmentHub
              onBackToApp={() => setCurrentTab('user')}
              showToast={showToast}
              isAdmin={true}
            />
          ) : currentTab === 'user' ? (
            <UserSalaryApp
              employees={employees}
              onOpenResignationModal={(emp) => setResignationModalEmp(emp)}
              onOpenResignationLetter={(emp) => setResignationLetterEmp(emp)}
              onOpenSuspensionNotice={(emp) => setSuspensionNoticeEmp(emp)}
              onOpenTerminationNotice={(emp) => setTerminationNoticeEmp(emp)}
              showToast={showToast}
            />
          ) : (
            <AdminPanel
              employees={employees}
              onOpenResignationModal={(emp) => setResignationModalEmp(emp)}
              onOpenResignationLetter={(emp) => setResignationLetterEmp(emp)}
              onOpenSuspensionNotice={(emp) => setSuspensionNoticeEmp(emp)}
              onOpenTerminationNotice={(emp) => setTerminationNoticeEmp(emp)}
              showToast={showToast}
              initialTab={
                currentTab === 'admin'
                  ? 'list'
                  : currentTab === 'applications'
                  ? 'applications'
                  : (currentTab as AdminTab)
              }
              onTabChange={(tab) => {
                if (
                  tab === 'attendance' ||
                  tab === 'salaries' ||
                  tab === 'password' ||
                  tab === 'telegram' ||
                  tab === 'sms' ||
                  tab === 'factory' ||
                  tab === 'applications'
                ) {
                  setCurrentTab(tab as AppMode);
                } else if (tab === 'list') {
                  setCurrentTab('admin');
                }
              }}
            />
          )}
        </main>

        {/* Global Resignation / Status Modal */}
        <ResignationModal
          employee={resignationModalEmp}
          isOpen={Boolean(resignationModalEmp)}
          onClose={() => setResignationModalEmp(null)}
          onSuccess={(msg) => showToast(msg)}
          onOpenResignationLetter={(emp) => setResignationLetterEmp(emp)}
          onOpenSuspensionNotice={(emp) => setSuspensionNoticeEmp(emp)}
          onOpenTerminationNotice={(emp) => setTerminationNoticeEmp(emp)}
        />

        {/* Global Resignation Form A4 Modal (1-Click Print & PDF) */}
        <ResignationLetterModal
          employee={resignationLetterEmp}
          isOpen={Boolean(resignationLetterEmp)}
          onClose={() => setResignationLetterEmp(null)}
          showToast={showToast}
          onEmployeeUpdated={(updated) => {
            setResignationLetterEmp(updated);
          }}
        />

        {/* Global Suspension Notice A4 Modal (1-Click Print & PDF) */}
        <SuspensionNoticeModal
          employee={suspensionNoticeEmp}
          isOpen={Boolean(suspensionNoticeEmp)}
          onClose={() => setSuspensionNoticeEmp(null)}
          showToast={showToast}
          onEmployeeUpdated={(updated) => {
            setSuspensionNoticeEmp(updated);
          }}
        />

        {/* Global Termination Notice A4 Modal (1-Click Print & PDF) */}
        <TerminationNoticeModal
          employee={terminationNoticeEmp}
          isOpen={Boolean(terminationNoticeEmp)}
          onClose={() => setTerminationNoticeEmp(null)}
          showToast={showToast}
          onEmployeeUpdated={(updated) => {
            setTerminationNoticeEmp(updated);
          }}
        />

        {/* Global Toast */}
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

        {/* Footer (Hidden in Job Application Link & Investor Portal Link Mode) */}
        {currentTab !== 'apply' && currentTab !== 'investor' && (
          <footer className="mt-8 text-center text-xs text-slate-400 space-y-1">
            <p>© টেক্স ওয়ার অ্যাপারেলস — গার্মেন্টস বেতন ও এইচআর সিস্টেম</p>
            <p className="text-[10px] text-slate-400">
              রিয়েল-টাইম ক্লাউড ডেটাবেস • POS 58mm থার্মাল পে-স্লিপ • কর্মী রিজাইন ট্র্যাকিং
            </p>
          </footer>
        )}
      </div>
    </div>
  );
}
